"use client"

import { useState, useEffect } from "react"

interface User {
  username: string
  role: string
}

const demoUsers = [
  { username: "admin", password: "admin123", role: "admin" },
  { username: "doctor", password: "doctor123", role: "doctor" },
  { username: "nurse", password: "nurse123", role: "nurse" },
  { username: "receptionist", password: "reception123", role: "receptionist" },
  { username: "pharmacist", password: "pharma123", role: "pharmacist" },
]

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)

  useEffect(() => {
    const savedUser = localStorage.getItem("hms-user")
    if (savedUser) {
      setUser(JSON.parse(savedUser))
    }
  }, [])

  const login = async (credentials: { username: string; password: string; role: string }) => {
    const foundUser = demoUsers.find(
      (u) => u.username === credentials.username && u.password === credentials.password && u.role === credentials.role,
    )

    if (foundUser) {
      const userData = { username: foundUser.username, role: foundUser.role }
      setUser(userData)
      localStorage.setItem("hms-user", JSON.stringify(userData))

      // Log audit trail
      const auditLog = {
        username: foundUser.username,
        role: foundUser.role,
        timestamp: new Date().toISOString(),
        action: "login",
        success: true,
      }

      const existingLogs = JSON.parse(localStorage.getItem("hms-audit-logs") || "[]")
      existingLogs.push(auditLog)
      localStorage.setItem("hms-audit-logs", JSON.stringify(existingLogs))

      return true
    }

    // Log failed attempt
    const auditLog = {
      username: credentials.username,
      role: credentials.role,
      timestamp: new Date().toISOString(),
      action: "login_failed",
      success: false,
    }

    const existingLogs = JSON.parse(localStorage.getItem("hms-audit-logs") || "[]")
    existingLogs.push(auditLog)
    localStorage.setItem("hms-audit-logs", JSON.stringify(existingLogs))

    return false
  }

  const logout = () => {
    if (user) {
      // Log logout
      const auditLog = {
        username: user.username,
        role: user.role,
        timestamp: new Date().toISOString(),
        action: "logout",
        success: true,
      }

      const existingLogs = JSON.parse(localStorage.getItem("hms-audit-logs") || "[]")
      existingLogs.push(auditLog)
      localStorage.setItem("hms-audit-logs", JSON.stringify(existingLogs))
    }

    setUser(null)
    localStorage.removeItem("hms-user")
  }

  return { user, login, logout }
}
