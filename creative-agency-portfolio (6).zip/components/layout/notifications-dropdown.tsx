"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Bell, X, Check, Calendar, Users, DollarSign, TestTube, AlertTriangle, Info } from "lucide-react"

interface Notification {
  id: string
  type: "appointment" | "patient" | "billing" | "lab" | "system" | "alert"
  title: string
  message: string
  timestamp: string | Date // ← was Date only
  read: boolean
  priority: "high" | "medium" | "low"
}

export function NotificationsDropdown() {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [isOpen, setIsOpen] = useState(false)

  useEffect(() => {
    // Load notifications from localStorage or generate sample data
    const savedNotifications = localStorage.getItem("hms-notifications")
    if (savedNotifications) {
      const parsed: Notification[] = JSON.parse(savedNotifications).map((n) => ({
        ...n,
        timestamp: new Date(n.timestamp), // ← convert string → Date
      }))
      setNotifications(parsed)
    } else {
      // Generate sample notifications
      const sampleNotifications: Notification[] = [
        {
          id: "1",
          type: "appointment",
          title: "Upcoming Appointment",
          message: "Dr. Smith has an appointment with John Doe in 30 minutes",
          timestamp: new Date(Date.now() - 5 * 60 * 1000),
          read: false,
          priority: "high",
        },
        {
          id: "2",
          type: "patient",
          title: "New Patient Registration",
          message: "Sarah Johnson has been registered as a new patient",
          timestamp: new Date(Date.now() - 15 * 60 * 1000),
          read: false,
          priority: "medium",
        },
        {
          id: "3",
          type: "billing",
          title: "Payment Received",
          message: "Payment of $250.00 received from Michael Brown",
          timestamp: new Date(Date.now() - 30 * 60 * 1000),
          read: true,
          priority: "low",
        },
        {
          id: "4",
          type: "lab",
          title: "Lab Results Ready",
          message: "Blood test results are ready for Emma Wilson",
          timestamp: new Date(Date.now() - 45 * 60 * 1000),
          read: false,
          priority: "medium",
        },
        {
          id: "5",
          type: "system",
          title: "System Backup Complete",
          message: "Daily system backup completed successfully",
          timestamp: new Date(Date.now() - 60 * 60 * 1000),
          read: true,
          priority: "low",
        },
        {
          id: "6",
          type: "alert",
          title: "Low Medicine Stock",
          message: "Paracetamol stock is running low (5 units remaining)",
          timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
          read: false,
          priority: "high",
        },
      ]
      setNotifications(sampleNotifications)
      localStorage.setItem("hms-notifications", JSON.stringify(sampleNotifications))
    }
  }, [])

  const unreadCount = notifications.filter((n) => !n.read).length

  const markAsRead = (id: string) => {
    const updatedNotifications = notifications.map((notification) =>
      notification.id === id ? { ...notification, read: true } : notification,
    )
    setNotifications(updatedNotifications)
    localStorage.setItem("hms-notifications", JSON.stringify(updatedNotifications))
  }

  const markAllAsRead = () => {
    const updatedNotifications = notifications.map((notification) => ({ ...notification, read: true }))
    setNotifications(updatedNotifications)
    localStorage.setItem("hms-notifications", JSON.stringify(updatedNotifications))
  }

  const deleteNotification = (id: string) => {
    const updatedNotifications = notifications.filter((notification) => notification.id !== id)
    setNotifications(updatedNotifications)
    localStorage.setItem("hms-notifications", JSON.stringify(updatedNotifications))
  }

  const getIcon = (type: string) => {
    switch (type) {
      case "appointment":
        return <Calendar className="h-4 w-4 text-blue-600" />
      case "patient":
        return <Users className="h-4 w-4 text-green-600" />
      case "billing":
        return <DollarSign className="h-4 w-4 text-orange-600" />
      case "lab":
        return <TestTube className="h-4 w-4 text-purple-600" />
      case "alert":
        return <AlertTriangle className="h-4 w-4 text-red-600" />
      case "system":
        return <Info className="h-4 w-4 text-gray-600" />
      default:
        return <Bell className="h-4 w-4 text-gray-600" />
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "border-l-red-500"
      case "medium":
        return "border-l-yellow-500"
      case "low":
        return "border-l-green-500"
      default:
        return "border-l-gray-300"
    }
  }

  const formatTime = (ts: string | Date) => {
    const dateObj = ts instanceof Date ? ts : new Date(ts)
    if (isNaN(dateObj.getTime())) return ""
    const diffMs = Date.now() - dateObj.getTime()
    const minutes = Math.floor(diffMs / 60000)
    const hours = Math.floor(diffMs / 3600000)
    const days = Math.floor(diffMs / 86400000)

    if (minutes < 1) return "Just now"
    if (minutes < 60) return `${minutes}m ago`
    if (hours < 24) return `${hours}h ago`
    return `${days}d ago`
  }

  return (
    <Popover open={isOpen} onOpenChange={setIsOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative h-9 w-9 p-0">
          <Bell className="h-5 w-5 text-gray-600 dark:text-gray-400" />
          {unreadCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 text-xs bg-red-500 hover:bg-red-500 flex items-center justify-center">
              {unreadCount > 9 ? "9+" : unreadCount}
            </Badge>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80 p-0 bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700" align="end">
        <Card className="border-0 shadow-none">
          <CardHeader className="pb-3 bg-gray-50 dark:bg-gray-900 border-b border-gray-200 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white">Notifications</CardTitle>
              {unreadCount > 0 && (
                <Button variant="ghost" size="sm" onClick={markAllAsRead} className="text-xs h-7 px-2">
                  <Check className="h-3 w-3 mr-1" />
                  Mark all read
                </Button>
              )}
            </div>
            {unreadCount > 0 && (
              <p className="text-sm text-gray-600 dark:text-gray-400">{unreadCount} unread notifications</p>
            )}
          </CardHeader>
          <CardContent className="p-0">
            <ScrollArea className="h-96">
              {notifications.length > 0 ? (
                <div className="divide-y divide-gray-100 dark:divide-gray-700">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors border-l-4 ${getPriorityColor(
                        notification.priority,
                      )} ${!notification.read ? "bg-blue-50 dark:bg-blue-900/20" : ""}`}
                    >
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0 mt-1">{getIcon(notification.type)}</div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <p
                                className={`text-sm font-medium ${
                                  !notification.read
                                    ? "text-gray-900 dark:text-white"
                                    : "text-gray-700 dark:text-gray-300"
                                }`}
                              >
                                {notification.title}
                              </p>
                              <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{notification.message}</p>
                              <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                                {formatTime(notification.timestamp)}
                              </p>
                            </div>
                            <div className="flex items-center space-x-1 ml-2">
                              {!notification.read && (
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => markAsRead(notification.id)}
                                  className="h-6 w-6 p-0 hover:bg-gray-200 dark:hover:bg-gray-600"
                                  title="Mark as read"
                                >
                                  <Check className="h-3 w-3" />
                                </Button>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => deleteNotification(notification.id)}
                                className="h-6 w-6 p-0 hover:bg-red-100 dark:hover:bg-red-900/30 text-red-600 dark:text-red-400"
                                title="Delete notification"
                              >
                                <X className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-8 text-center">
                  <Bell className="h-12 w-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-500 dark:text-gray-400">No notifications</p>
                </div>
              )}
            </ScrollArea>
          </CardContent>
        </Card>
      </PopoverContent>
    </Popover>
  )
}
