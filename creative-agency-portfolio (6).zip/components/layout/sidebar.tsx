"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import {
  LayoutDashboard,
  Users,
  UserCheck,
  Calendar,
  TestTube,
  Pill,
  Bed,
  CreditCard,
  Building2,
  FileText,
  Settings,
  LogOut,
  Activity,
  Package,
} from "lucide-react"

interface SidebarProps {
  activeTab: string
  setActiveTab: (tab: string) => void
  userRole: string
  onLogout: () => void
}

export function Sidebar({ activeTab, setActiveTab, userRole, onLogout }: SidebarProps) {
  const menuItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: LayoutDashboard,
      roles: ["admin", "doctor", "nurse", "receptionist", "pharmacist", "lab-tech", "accountant"],
    },
    { id: "patients", label: "Patients", icon: Users, roles: ["admin", "doctor", "nurse", "receptionist"] },
    { id: "doctors", label: "Doctors", icon: UserCheck, roles: ["admin", "receptionist"] },
    { id: "appointments", label: "Appointments", icon: Calendar, roles: ["admin", "doctor", "nurse", "receptionist"] },
    { id: "laboratory", label: "Laboratory", icon: TestTube, roles: ["admin", "doctor", "nurse", "lab-tech"] },
    { id: "pharmacy", label: "Pharmacy", icon: Pill, roles: ["admin", "doctor", "pharmacist"] },
    { id: "beds", label: "Bed Management", icon: Bed, roles: ["admin", "nurse", "receptionist"] },
    { id: "billing", label: "Billing", icon: CreditCard, roles: ["admin", "receptionist", "accountant"] },
    { id: "departments", label: "Departments", icon: Building2, roles: ["admin"] },
    { id: "assets", label: "Assets", icon: Package, roles: ["admin", "nurse"] },
    { id: "reports", label: "Reports", icon: FileText, roles: ["admin", "doctor", "accountant"] },
    { id: "settings", label: "Settings", icon: Settings, roles: ["admin"] },
    { id: "settings", label: "Logs", icon: Settings, roles: ["admin"] },
  ]

  const filteredMenuItems = menuItems.filter((item) => item.roles.includes(userRole.toLowerCase()))

  return (
    <div className="w-64 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700 flex flex-col transition-colors">
      <div className="p-6 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center space-x-3">
          <div className="h-10 w-10 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
            <Activity className="h-6 w-6 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">HMS</h2>
            <p className="text-xs text-gray-500 dark:text-gray-400 capitalize">{userRole}</p>
          </div>
        </div>
      </div>

      <ScrollArea className="flex-1 px-3 py-4">
        <nav className="space-y-1">
          {filteredMenuItems.map((item) => {
            const IconComponent = item.icon
            const isActive = activeTab === item.id

            return (
              <Button
                key={item.id}
                variant={isActive ? "secondary" : "ghost"}
                className={`w-full justify-start h-10 px-3 ${
                  isActive
                    ? "bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300 border-r-2 border-blue-600"
                    : "text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                }`}
                onClick={() => setActiveTab(item.id)}
              >
                <IconComponent className="mr-3 h-4 w-4" />
                {item.label}
                {item.id === "assets" && (
                  <Badge variant="secondary" className="ml-auto text-xs">
                    New
                  </Badge>
                )}
              </Button>
            )
          })}
        </nav>
      </ScrollArea>

      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <Button
          variant="ghost"
          className="w-full justify-start text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20"
          onClick={onLogout}
        >
          <LogOut className="mr-3 h-4 w-4" />
          Logout
        </Button>
      </div>
    </div>
  )
}
