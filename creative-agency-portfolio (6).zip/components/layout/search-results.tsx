"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Users,
  UserCheck,
  Calendar,
  TestTube,
  Pill,
  Bed,
  Search,
  Filter,
  X,
  ChevronDown,
  ChevronUp,
  MapPin,
  Clock,
  DollarSign,
} from "lucide-react"

interface SearchResultsProps {
  query: string
  isOpen: boolean
  onClose: () => void
  onNavigate: (section: string, id?: string) => void
}

interface SearchFilters {
  type: string
  status: string
  department: string
  priority: string
  dateFrom: string
  dateTo: string
}

export function SearchResults({ query, isOpen, onClose, onNavigate }: SearchResultsProps) {
  const [filters, setFilters] = useState<SearchFilters>({
    type: "",
    status: "",
    department: "",
    priority: "",
    dateFrom: "",
    dateTo: "",
  })
  const [showFilters, setShowFilters] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const searchData = useMemo(() => {
    if (query.length < 1) return []

    setIsLoading(true)

    // Get all data from localStorage
    const patients = JSON.parse(localStorage.getItem("hms-patients") || "[]")
    const doctors = JSON.parse(localStorage.getItem("hms-doctors") || "[]")
    const appointments = JSON.parse(localStorage.getItem("hms-appointments") || "[]")
    const labTests = JSON.parse(localStorage.getItem("hms-lab-tests") || "[]")
    const medicines = JSON.parse(localStorage.getItem("hms-medicines") || "[]")
    const beds = JSON.parse(localStorage.getItem("hms-beds") || "[]")
    const bills = JSON.parse(localStorage.getItem("hms-bills") || "[]")

    const results: any[] = []
    const searchTerm = query.toLowerCase()

    // Search patients
    patients.forEach((patient: any) => {
      if (
        patient.firstName?.toLowerCase().includes(searchTerm) ||
        patient.lastName?.toLowerCase().includes(searchTerm) ||
        patient.patientId?.toLowerCase().includes(searchTerm) ||
        patient.email?.toLowerCase().includes(searchTerm) ||
        patient.phone?.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          id: patient.id,
          type: "patient",
          title: `${patient.firstName} ${patient.lastName}`,
          subtitle: `ID: ${patient.patientId} | ${patient.email}`,
          status: patient.status || "Active",
          department: patient.department || "General",
          priority: patient.priority || "Normal",
          date: patient.createdAt || patient.registrationDate,
          section: "patients",
          icon: <Users className="h-4 w-4" />,
        })
      }
    })

    // Search doctors
    doctors.forEach((doctor: any) => {
      if (
        doctor.firstName?.toLowerCase().includes(searchTerm) ||
        doctor.lastName?.toLowerCase().includes(searchTerm) ||
        doctor.doctorId?.toLowerCase().includes(searchTerm) ||
        doctor.specialization?.toLowerCase().includes(searchTerm) ||
        doctor.email?.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          id: doctor.id,
          type: "doctor",
          title: `Dr. ${doctor.firstName} ${doctor.lastName}`,
          subtitle: `${doctor.specialization} | ID: ${doctor.doctorId}`,
          status: doctor.status || "Active",
          department: doctor.department || doctor.specialization || "General",
          priority: "Normal",
          date: doctor.createdAt,
          section: "doctors",
          icon: <UserCheck className="h-4 w-4" />,
        })
      }
    })

    // Search appointments
    appointments.forEach((appointment: any) => {
      if (
        appointment.patientName?.toLowerCase().includes(searchTerm) ||
        appointment.doctorName?.toLowerCase().includes(searchTerm) ||
        appointment.appointmentId?.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          id: appointment.id,
          type: "appointment",
          title: `Appointment - ${appointment.patientName}`,
          subtitle: `Dr. ${appointment.doctorName} | ${appointment.date} ${appointment.time}`,
          status: appointment.status || "Scheduled",
          department: appointment.department || "General",
          priority: appointment.priority || "Normal",
          date: appointment.createdAt || appointment.date,
          section: "appointments",
          icon: <Calendar className="h-4 w-4" />,
        })
      }
    })

    // Search lab tests
    labTests.forEach((test: any) => {
      if (
        test.testName?.toLowerCase().includes(searchTerm) ||
        test.patientName?.toLowerCase().includes(searchTerm) ||
        test.testId?.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          id: test.id,
          type: "lab",
          title: `${test.testName}`,
          subtitle: `Patient: ${test.patientName} | ID: ${test.testId}`,
          status: test.status || "Pending",
          department: "Laboratory",
          priority: test.priority || "Normal",
          date: test.createdAt || test.testDate,
          section: "laboratory",
          icon: <TestTube className="h-4 w-4" />,
        })
      }
    })

    // Search medicines
    medicines.forEach((medicine: any) => {
      if (
        medicine.name?.toLowerCase().includes(searchTerm) ||
        medicine.category?.toLowerCase().includes(searchTerm) ||
        medicine.manufacturer?.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          id: medicine.id,
          type: "pharmacy",
          title: medicine.name,
          subtitle: `${medicine.category} | ${medicine.manufacturer}`,
          status: medicine.stock > 0 ? "In Stock" : "Out of Stock",
          department: "Pharmacy",
          priority: medicine.stock < 10 ? "High" : "Normal",
          date: medicine.createdAt,
          section: "pharmacy",
          icon: <Pill className="h-4 w-4" />,
        })
      }
    })

    // Search beds
    beds.forEach((bed: any) => {
      if (
        bed.roomNumber?.toLowerCase().includes(searchTerm) ||
        bed.patientName?.toLowerCase().includes(searchTerm) ||
        bed.department?.toLowerCase().includes(searchTerm)
      ) {
        results.push({
          id: bed.id,
          type: "bed",
          title: `Room ${bed.roomNumber}`,
          subtitle: bed.patientName ? `Patient: ${bed.patientName}` : "Available",
          status: bed.status || "Available",
          department: bed.department || "General",
          priority: bed.status === "Occupied" ? "High" : "Normal",
          date: bed.createdAt,
          section: "beds",
          icon: <Bed className="h-4 w-4" />,
        })
      }
    })

    // Search bills
    bills.forEach((bill: any) => {
      if (bill.patientName?.toLowerCase().includes(searchTerm) || bill.billNumber?.toLowerCase().includes(searchTerm)) {
        results.push({
          id: bill.id,
          type: "bill",
          title: `Bill ${bill.billNumber}`,
          subtitle: `${bill.patientName} | $${Number.parseFloat(bill.total || 0).toFixed(2)}`,
          status: bill.status || "Pending",
          department: "Billing",
          priority: bill.status === "overdue" ? "High" : "Normal",
          date: bill.createdAt,
          section: "billing",
          icon: <DollarSign className="h-4 w-4" />,
        })
      }
    })

    setTimeout(() => setIsLoading(false), 300)
    return results
  }, [query])

  const filteredResults = useMemo(() => {
    return searchData.filter((result) => {
      if (filters.type && result.type !== filters.type) return false
      if (filters.status && result.status !== filters.status) return false
      if (filters.department && result.department !== filters.department) return false
      if (filters.priority && result.priority !== filters.priority) return false

      if (filters.dateFrom) {
        const resultDate = new Date(result.date)
        const fromDate = new Date(filters.dateFrom)
        if (resultDate < fromDate) return false
      }

      if (filters.dateTo) {
        const resultDate = new Date(result.date)
        const toDate = new Date(filters.dateTo)
        if (resultDate > toDate) return false
      }

      return true
    })
  }, [searchData, filters])

  const clearFilters = () => {
    setFilters({
      type: "",
      status: "",
      department: "",
      priority: "",
      dateFrom: "",
      dateTo: "",
    })
  }

  const activeFiltersCount = Object.values(filters).filter(Boolean).length

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case "active":
      case "completed":
      case "paid":
      case "in stock":
        return "bg-green-100 text-green-800"
      case "pending":
      case "scheduled":
        return "bg-yellow-100 text-yellow-800"
      case "cancelled":
      case "overdue":
      case "out of stock":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      default:
        return "bg-green-100 text-green-800"
    }
  }

  if (!isOpen) return null

  return (
    <Card className="absolute top-full left-0 right-0 mt-2 max-h-96 overflow-hidden shadow-lg border z-50 bg-white">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-sm font-medium">Search Results {query && `for "${query}"`}</CardTitle>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="sm" onClick={() => setShowFilters(!showFilters)} className="text-xs">
              <Filter className="h-3 w-3 mr-1" />
              Filters
              {activeFiltersCount > 0 && (
                <Badge variant="secondary" className="ml-1 h-4 w-4 p-0 text-xs">
                  {activeFiltersCount}
                </Badge>
              )}
              {showFilters ? <ChevronUp className="h-3 w-3 ml-1" /> : <ChevronDown className="h-3 w-3 ml-1" />}
            </Button>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-medium text-gray-700 mb-1 block">Type</label>
                <Select value={filters.type} onValueChange={(value) => setFilters({ ...filters, type: value })}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="All types" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All types</SelectItem>
                    <SelectItem value="patient">Patient</SelectItem>
                    <SelectItem value="doctor">Doctor</SelectItem>
                    <SelectItem value="appointment">Appointment</SelectItem>
                    <SelectItem value="lab">Lab Test</SelectItem>
                    <SelectItem value="pharmacy">Pharmacy</SelectItem>
                    <SelectItem value="bed">Bed</SelectItem>
                    <SelectItem value="bill">Bill</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-medium text-gray-700 mb-1 block">Status</label>
                <Select value={filters.status} onValueChange={(value) => setFilters({ ...filters, status: value })}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="All statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All statuses</SelectItem>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Pending">Pending</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                    <SelectItem value="Cancelled">Cancelled</SelectItem>
                    <SelectItem value="Scheduled">Scheduled</SelectItem>
                    <SelectItem value="Confirmed">Confirmed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-medium text-gray-700 mb-1 block">Department</label>
                <Select
                  value={filters.department}
                  onValueChange={(value) => setFilters({ ...filters, department: value })}
                >
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="All departments" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All departments</SelectItem>
                    <SelectItem value="General">General</SelectItem>
                    <SelectItem value="Cardiology">Cardiology</SelectItem>
                    <SelectItem value="Neurology">Neurology</SelectItem>
                    <SelectItem value="Orthopedics">Orthopedics</SelectItem>
                    <SelectItem value="Pediatrics">Pediatrics</SelectItem>
                    <SelectItem value="Laboratory">Laboratory</SelectItem>
                    <SelectItem value="Pharmacy">Pharmacy</SelectItem>
                    <SelectItem value="Billing">Billing</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-medium text-gray-700 mb-1 block">Priority</label>
                <Select value={filters.priority} onValueChange={(value) => setFilters({ ...filters, priority: value })}>
                  <SelectTrigger className="h-8 text-xs">
                    <SelectValue placeholder="All priorities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All priorities</SelectItem>
                    <SelectItem value="High">High</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Normal">Normal</SelectItem>
                    <SelectItem value="Low">Low</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-xs font-medium text-gray-700 mb-1 block">From Date</label>
                <Input
                  type="date"
                  value={filters.dateFrom}
                  onChange={(e) => setFilters({ ...filters, dateFrom: e.target.value })}
                  className="h-8 text-xs"
                />
              </div>

              <div>
                <label className="text-xs font-medium text-gray-700 mb-1 block">To Date</label>
                <Input
                  type="date"
                  value={filters.dateTo}
                  onChange={(e) => setFilters({ ...filters, dateTo: e.target.value })}
                  className="h-8 text-xs"
                />
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-xs text-gray-600">
                Showing {filteredResults.length} of {searchData.length} results
              </span>
              {activeFiltersCount > 0 && (
                <Button variant="outline" size="sm" onClick={clearFilters} className="text-xs h-7 bg-transparent">
                  Clear Filters
                </Button>
              )}
            </div>
          </div>
        )}
      </CardHeader>

      <CardContent className="p-0">
        <div className="max-h-64 overflow-y-auto">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="ml-2 text-sm text-gray-600">Searching...</span>
            </div>
          ) : filteredResults.length > 0 ? (
            <div className="space-y-1">
              {filteredResults.map((result, index) => (
                <div
                  key={index}
                  data-search-result
                  className="flex items-center justify-between p-3 hover:bg-gray-50 cursor-pointer border-b border-gray-100 last:border-b-0"
                  onClick={() => onNavigate(result.section, result.id)}
                >
                  <div className="flex items-center space-x-3 flex-1 min-w-0">
                    <div className="flex-shrink-0 text-gray-500">{result.icon}</div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{result.title}</p>
                      <p className="text-xs text-gray-600 truncate">{result.subtitle}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <div className="flex flex-col items-end space-y-1">
                      <Badge className={`text-xs ${getStatusColor(result.status)}`}>{result.status}</Badge>
                      {result.priority !== "Normal" && (
                        <Badge variant="outline" className={`text-xs ${getPriorityColor(result.priority)}`}>
                          {result.priority}
                        </Badge>
                      )}
                    </div>
                    <div className="flex flex-col items-end text-xs text-gray-500">
                      <div className="flex items-center">
                        <MapPin className="h-3 w-3 mr-1" />
                        <span>{result.department}</span>
                      </div>
                      {result.date && (
                        <div className="flex items-center mt-1">
                          <Clock className="h-3 w-3 mr-1" />
                          <span>{new Date(result.date).toLocaleDateString()}</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : query.length > 0 ? (
            <div className="flex flex-col items-center justify-center py-8">
              <Search className="h-8 w-8 text-gray-300 mb-2" />
              <p className="text-sm text-gray-500">No results found for "{query}"</p>
              <p className="text-xs text-gray-400 mt-1">Try adjusting your search terms or filters</p>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-8">
              <Search className="h-8 w-8 text-gray-300 mb-2" />
              <p className="text-sm text-gray-500">Start typing to search...</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
