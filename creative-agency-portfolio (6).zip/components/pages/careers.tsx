"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { toast } from "sonner"
import {
  Briefcase,
  MapPin,
  Clock,
  DollarSign,
  Plus,
  Upload,
  Search,
  Heart,
  Award,
  GraduationCap,
  Building2,
} from "lucide-react"

interface JobPosting {
  id: string
  title: string
  department: string
  location: string
  type: "full-time" | "part-time" | "contract" | "internship"
  experience: string
  salary: string
  description: string
  requirements: string[]
  benefits: string[]
  postedDate: Date
  deadline: Date
  status: "active" | "closed" | "draft"
}

interface JobApplication {
  id: string
  jobId: string
  applicantName: string
  email: string
  phone: string
  experience: string
  coverLetter: string
  resumeFile?: File
  appliedDate: Date
  status: "pending" | "reviewed" | "interviewed" | "hired" | "rejected"
}

export function CareersPage({ userRole }: { userRole: string }) {
  const [jobs, setJobs] = useState<JobPosting[]>([])
  const [applications, setApplications] = useState<JobApplication[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [filterDepartment, setFilterDepartment] = useState("")
  const [filterType, setFilterType] = useState("")
  const [isAddJobOpen, setIsAddJobOpen] = useState(false)
  const [selectedJob, setSelectedJob] = useState<JobPosting | null>(null)
  const [isApplyOpen, setIsApplyOpen] = useState(false)

  // New job form state
  const [newJob, setNewJob] = useState({
    title: "",
    department: "",
    location: "City General Hospital",
    type: "full-time" as const,
    experience: "",
    salary: "",
    description: "",
    requirements: "",
    benefits: "",
    deadline: "",
  })

  // Application form state
  const [applicationForm, setApplicationForm] = useState({
    applicantName: "",
    email: "",
    phone: "",
    experience: "",
    coverLetter: "",
    resumeFile: null as File | null,
  })

  useEffect(() => {
    // Load jobs from localStorage
    const savedJobs = localStorage.getItem("hms-job-postings")
    if (savedJobs) {
      const parsedJobs = JSON.parse(savedJobs).map((job: any) => ({
        ...job,
        postedDate: new Date(job.postedDate),
        deadline: new Date(job.deadline),
      }))
      setJobs(parsedJobs)
    } else {
      // Sample job postings
      const sampleJobs: JobPosting[] = [
        {
          id: "1",
          title: "Registered Nurse - ICU",
          department: "Intensive Care Unit",
          location: "City General Hospital",
          type: "full-time",
          experience: "2+ years",
          salary: "$65,000 - $80,000",
          description:
            "We are seeking a dedicated Registered Nurse to join our ICU team. The ideal candidate will provide high-quality patient care in a fast-paced critical care environment.",
          requirements: [
            "Valid RN license",
            "BLS and ACLS certification",
            "2+ years ICU experience preferred",
            "Strong communication skills",
            "Ability to work in high-stress situations",
          ],
          benefits: [
            "Competitive salary",
            "Health insurance",
            "401(k) with matching",
            "Paid time off",
            "Continuing education support",
            "Flexible scheduling",
          ],
          postedDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
          deadline: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000),
          status: "active",
        },
        {
          id: "2",
          title: "Emergency Medicine Physician",
          department: "Emergency Department",
          location: "City General Hospital",
          type: "full-time",
          experience: "Board certified",
          salary: "$280,000 - $320,000",
          description:
            "Join our dynamic Emergency Department team. We're looking for a board-certified Emergency Medicine physician to provide excellent patient care.",
          requirements: [
            "MD/DO degree",
            "Board certification in Emergency Medicine",
            "Valid medical license",
            "ACLS, PALS, ATLS certification",
            "Excellent clinical skills",
          ],
          benefits: [
            "Competitive compensation",
            "Malpractice insurance",
            "CME allowance",
            "Health benefits",
            "Retirement plan",
            "Relocation assistance",
          ],
          postedDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
          deadline: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000),
          status: "active",
        },
        {
          id: "3",
          title: "Medical Laboratory Technician",
          department: "Laboratory",
          location: "City General Hospital",
          type: "full-time",
          experience: "1+ years",
          salary: "$45,000 - $55,000",
          description:
            "We are seeking a skilled Medical Laboratory Technician to perform various laboratory tests and procedures.",
          requirements: [
            "Associate degree in Medical Laboratory Technology",
            "ASCP certification preferred",
            "1+ years laboratory experience",
            "Attention to detail",
            "Knowledge of laboratory equipment",
          ],
          benefits: [
            "Competitive salary",
            "Health insurance",
            "Paid time off",
            "Training opportunities",
            "Career advancement",
            "Employee discounts",
          ],
          postedDate: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
          deadline: new Date(Date.now() + 27 * 24 * 60 * 60 * 1000),
          status: "active",
        },
      ]
      setJobs(sampleJobs)
      localStorage.setItem("hms-job-postings", JSON.stringify(sampleJobs))
    }

    // Load applications
    const savedApplications = localStorage.getItem("hms-job-applications")
    if (savedApplications) {
      const parsedApplications = JSON.parse(savedApplications).map((app: any) => ({
        ...app,
        appliedDate: new Date(app.appliedDate),
      }))
      setApplications(parsedApplications)
    }
  }, [])

  const handleAddJob = () => {
    if (!newJob.title || !newJob.department || !newJob.description) {
      toast.error("Please fill in all required fields")
      return
    }

    const job: JobPosting = {
      id: Date.now().toString(),
      ...newJob,
      requirements: newJob.requirements.split("\n").filter((req) => req.trim()),
      benefits: newJob.benefits.split("\n").filter((benefit) => benefit.trim()),
      postedDate: new Date(),
      deadline: new Date(newJob.deadline),
      status: "active",
    }

    const updatedJobs = [...jobs, job]
    setJobs(updatedJobs)
    localStorage.setItem("hms-job-postings", JSON.stringify(updatedJobs))

    // Add notification for new job posting
    const notifications = JSON.parse(localStorage.getItem("hms-notifications") || "[]")
    notifications.unshift({
      id: Date.now().toString(),
      type: "system",
      title: "New Job Posted",
      message: `${job.title} position is now available in ${job.department}`,
      timestamp: new Date(),
      read: false,
      priority: "medium",
    })
    localStorage.setItem("hms-notifications", JSON.stringify(notifications))

    setNewJob({
      title: "",
      department: "",
      location: "City General Hospital",
      type: "full-time",
      experience: "",
      salary: "",
      description: "",
      requirements: "",
      benefits: "",
      deadline: "",
    })
    setIsAddJobOpen(false)
    toast.success("Job posting created successfully!")
  }

  const handleApply = () => {
    if (!applicationForm.applicantName || !applicationForm.email || !applicationForm.coverLetter) {
      toast.error("Please fill in all required fields")
      return
    }

    const application: JobApplication = {
      id: Date.now().toString(),
      jobId: selectedJob!.id,
      ...applicationForm,
      appliedDate: new Date(),
      status: "pending",
    }

    const updatedApplications = [...applications, application]
    setApplications(updatedApplications)
    localStorage.setItem("hms-job-applications", JSON.stringify(updatedApplications))

    setApplicationForm({
      applicantName: "",
      email: "",
      phone: "",
      experience: "",
      coverLetter: "",
      resumeFile: null,
    })
    setIsApplyOpen(false)
    setSelectedJob(null)
    toast.success("Application submitted successfully!")
  }

  const filteredJobs = jobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      job.department.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesDepartment = !filterDepartment || job.department === filterDepartment
    const matchesType = !filterType || job.type === filterType
    return matchesSearch && matchesDepartment && matchesType && job.status === "active"
  })

  const departments = [...new Set(jobs.map((job) => job.department))]
  const jobTypes = ["full-time", "part-time", "contract", "internship"]

  const getTypeColor = (type: string) => {
    switch (type) {
      case "full-time":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "part-time":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "contract":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900/20 dark:text-orange-300"
      case "internship":
        return "bg-purple-100 text-purple-800 dark:bg-purple-900/20 dark:text-purple-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const getDaysRemaining = (deadline: Date) => {
    const today = new Date()
    const diffTime = deadline.getTime() - today.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Careers</h1>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl">
            Join our team of dedicated healthcare professionals and make a difference in people's lives.
          </p>
        </div>
        {userRole === "admin" && (
          <Dialog open={isAddJobOpen} onOpenChange={setIsAddJobOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>Post New Job</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Create Job Posting</DialogTitle>
                <DialogDescription>Fill in the details to create a new job posting</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="title">Job Title *</Label>
                    <Input
                      id="title"
                      value={newJob.title}
                      onChange={(e) => setNewJob((prev) => ({ ...prev, title: e.target.value }))}
                      placeholder="e.g., Registered Nurse"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="department">Department *</Label>
                    <Input
                      id="department"
                      value={newJob.department}
                      onChange={(e) => setNewJob((prev) => ({ ...prev, department: e.target.value }))}
                      placeholder="e.g., Emergency Department"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="type">Employment Type</Label>
                    <Select
                      value={newJob.type}
                      onValueChange={(value: any) => setNewJob((prev) => ({ ...prev, type: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full-time">Full-time</SelectItem>
                        <SelectItem value="part-time">Part-time</SelectItem>
                        <SelectItem value="contract">Contract</SelectItem>
                        <SelectItem value="internship">Internship</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="experience">Experience Required</Label>
                    <Input
                      id="experience"
                      value={newJob.experience}
                      onChange={(e) => setNewJob((prev) => ({ ...prev, experience: e.target.value }))}
                      placeholder="e.g., 2+ years"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="salary">Salary Range</Label>
                    <Input
                      id="salary"
                      value={newJob.salary}
                      onChange={(e) => setNewJob((prev) => ({ ...prev, salary: e.target.value }))}
                      placeholder="e.g., $65,000 - $80,000"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="deadline">Application Deadline</Label>
                    <Input
                      id="deadline"
                      type="date"
                      value={newJob.deadline}
                      onChange={(e) => setNewJob((prev) => ({ ...prev, deadline: e.target.value }))}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Job Description *</Label>
                  <Textarea
                    id="description"
                    value={newJob.description}
                    onChange={(e) => setNewJob((prev) => ({ ...prev, description: e.target.value }))}
                    placeholder="Describe the role, responsibilities, and what you're looking for..."
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="requirements">Requirements (one per line)</Label>
                  <Textarea
                    id="requirements"
                    value={newJob.requirements}
                    onChange={(e) => setNewJob((prev) => ({ ...prev, requirements: e.target.value }))}
                    placeholder="Valid license&#10;2+ years experience&#10;Strong communication skills"
                    rows={4}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="benefits">Benefits (one per line)</Label>
                  <Textarea
                    id="benefits"
                    value={newJob.benefits}
                    onChange={(e) => setNewJob((prev) => ({ ...prev, benefits: e.target.value }))}
                    placeholder="Health insurance&#10;401(k) matching&#10;Paid time off"
                    rows={4}
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setIsAddJobOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddJob}>Create Job Posting</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Why Work With Us */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="pt-6 text-center">
            <div className="h-12 w-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            </div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Make a Difference</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Join a team dedicated to improving lives and providing exceptional healthcare to our community.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <div className="h-12 w-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <GraduationCap className="h-6 w-6 text-green-600 dark:text-green-400" />
            </div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Grow Your Career</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Access continuing education, training programs, and advancement opportunities in a supportive environment.
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <div className="h-12 w-12 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="h-6 w-6 text-purple-600 dark:text-purple-400" />
            </div>
            <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Excellent Benefits</h3>
            <p className="text-gray-600 dark:text-gray-400 text-sm">
              Comprehensive benefits package including health insurance, retirement plans, and work-life balance.
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search jobs by title or department..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              <Select value={filterDepartment} onValueChange={setFilterDepartment}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Types</SelectItem>
                  {jobTypes.map((type) => (
                    <SelectItem key={type} value={type} className="capitalize">
                      {type.replace("-", " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Job Listings */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Open Positions ({filteredJobs.length})</h2>
        </div>

        {filteredJobs.length === 0 ? (
          <Card>
            <CardContent className="pt-12 pb-12 text-center">
              <Briefcase className="h-12 w-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No jobs found</h3>
              <p className="text-gray-500 dark:text-gray-400">
                {searchQuery || filterDepartment || filterType
                  ? "Try adjusting your search criteria"
                  : "Check back later for new opportunities"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-6">
            {filteredJobs.map((job) => {
              const daysRemaining = getDaysRemaining(job.deadline)
              return (
                <Card key={job.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-xl font-semibold text-gray-900 dark:text-white">{job.title}</h3>
                          <Badge className={getTypeColor(job.type)}>{job.type.replace("-", " ")}</Badge>
                          {daysRemaining <= 7 && (
                            <Badge variant="destructive" className="text-xs">
                              {daysRemaining <= 0 ? "Expired" : `${daysRemaining} days left`}
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-gray-600 dark:text-gray-400 mb-3">
                          <div className="flex items-center space-x-1">
                            <Building2 className="h-4 w-4" />
                            <span>{job.department}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-4 w-4" />
                            <span>{job.location}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="h-4 w-4" />
                            <span>{job.experience}</span>
                          </div>
                          {job.salary && (
                            <div className="flex items-center space-x-1">
                              <DollarSign className="h-4 w-4" />
                              <span>{job.salary}</span>
                            </div>
                          )}
                        </div>
                        <p className="text-gray-600 dark:text-gray-400 mb-4 line-clamp-2">{job.description}</p>
                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-500 dark:text-gray-500">
                            Posted {formatDate(job.postedDate)} • Deadline {formatDate(job.deadline)}
                          </div>
                          <div className="flex space-x-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  View Details
                                </Button>
                              </DialogTrigger>
                              <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
                                <DialogHeader>
                                  <DialogTitle className="text-2xl">{job.title}</DialogTitle>
                                  <DialogDescription className="text-base">
                                    {job.department} • {job.location}
                                  </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-6">
                                  <div className="flex flex-wrap gap-2">
                                    <Badge className={getTypeColor(job.type)}>{job.type.replace("-", " ")}</Badge>
                                    <Badge variant="outline">{job.experience}</Badge>
                                    {job.salary && <Badge variant="outline">{job.salary}</Badge>}
                                  </div>

                                  <div>
                                    <h4 className="font-semibold text-gray-900 dark:text-white mb-2">
                                      Job Description
                                    </h4>
                                    <p className="text-gray-600 dark:text-gray-400">{job.description}</p>
                                  </div>

                                  {job.requirements.length > 0 && (
                                    <div>
                                      <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Requirements</h4>
                                      <ul className="space-y-1">
                                        {job.requirements.map((req, idx) => (
                                          <li key={idx} className="flex items-start space-x-2">
                                            <div className="h-1.5 w-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                                            <span className="text-gray-600 dark:text-gray-400 text-sm">{req}</span>
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}

                                  {job.benefits.length > 0 && (
                                    <div>
                                      <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Benefits</h4>
                                      <ul className="space-y-1">
                                        {job.benefits.map((benefit, idx) => (
                                          <li key={idx} className="flex items-start space-x-2">
                                            <div className="h-1.5 w-1.5 bg-green-600 rounded-full mt-2 flex-shrink-0" />
                                            <span className="text-gray-600 dark:text-gray-400 text-sm">{benefit}</span>
                                          </li>
                                        ))}
                                      </ul>
                                    </div>
                                  )}

                                  <div className="flex justify-between items-center pt-4 border-t">
                                    <div className="text-sm text-gray-500">
                                      Application deadline: {formatDate(job.deadline)}
                                    </div>
                                    <Button
                                      onClick={() => {
                                        setSelectedJob(job)
                                        setIsApplyOpen(true)
                                      }}
                                      disabled={daysRemaining <= 0}
                                    >
                                      {daysRemaining <= 0 ? "Application Closed" : "Apply Now"}
                                    </Button>
                                  </div>
                                </div>
                              </DialogContent>
                            </Dialog>
                            <Button
                              size="sm"
                              onClick={() => {
                                setSelectedJob(job)
                                setIsApplyOpen(true)
                              }}
                              disabled={daysRemaining <= 0}
                            >
                              {daysRemaining <= 0 ? "Closed" : "Apply"}
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </div>

      {/* Application Dialog */}
      <Dialog open={isApplyOpen} onOpenChange={setIsApplyOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Apply for {selectedJob?.title}</DialogTitle>
            <DialogDescription>
              {selectedJob?.department} • {selectedJob?.location}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="applicantName">Full Name *</Label>
                <Input
                  id="applicantName"
                  value={applicationForm.applicantName}
                  onChange={(e) => setApplicationForm((prev) => ({ ...prev, applicantName: e.target.value }))}
                  placeholder="Enter your full name"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address *</Label>
                <Input
                  id="email"
                  type="email"
                  value={applicationForm.email}
                  onChange={(e) => setApplicationForm((prev) => ({ ...prev, email: e.target.value }))}
                  placeholder="Enter your email"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input
                  id="phone"
                  type="tel"
                  value={applicationForm.phone}
                  onChange={(e) => setApplicationForm((prev) => ({ ...prev, phone: e.target.value }))}
                  placeholder="Enter your phone number"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="experience">Years of Experience</Label>
                <Input
                  id="experience"
                  value={applicationForm.experience}
                  onChange={(e) => setApplicationForm((prev) => ({ ...prev, experience: e.target.value }))}
                  placeholder="e.g., 3 years"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="resume">Resume/CV</Label>
              <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">
                  Click to upload or drag and drop your resume
                </p>
                <p className="text-xs text-gray-500">PDF, DOC, DOCX up to 10MB</p>
                <Input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={(e) =>
                    setApplicationForm((prev) => ({
                      ...prev,
                      resumeFile: e.target.files?.[0] || null,
                    }))
                  }
                  className="mt-2"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="coverLetter">Cover Letter *</Label>
              <Textarea
                id="coverLetter"
                value={applicationForm.coverLetter}
                onChange={(e) => setApplicationForm((prev) => ({ ...prev, coverLetter: e.target.value }))}
                placeholder="Tell us why you're interested in this position and what makes you a great fit..."
                rows={6}
              />
            </div>

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setIsApplyOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleApply}>Submit Application</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
