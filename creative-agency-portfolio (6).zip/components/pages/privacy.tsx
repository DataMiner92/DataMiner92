"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Lock, Eye, FileText, Users, Database } from "lucide-react"

export function PrivacyPage() {
  const sections = [
    {
      title: "Information We Collect",
      icon: Database,
      content: [
        "Personal identification information (name, address, phone number, email)",
        "Medical history and health information",
        "Insurance and billing information",
        "Emergency contact details",
        "Treatment records and test results",
        "Appointment and visit history",
      ],
    },
    {
      title: "How We Use Your Information",
      icon: FileText,
      content: [
        "Providing medical care and treatment",
        "Processing insurance claims and billing",
        "Scheduling appointments and follow-ups",
        "Communicating about your care",
        "Maintaining medical records",
        "Quality improvement and safety monitoring",
      ],
    },
    {
      title: "Information Sharing",
      icon: Users,
      content: [
        "Healthcare providers involved in your care",
        "Insurance companies for claim processing",
        "Legal authorities when required by law",
        "Emergency contacts in case of medical emergencies",
        "Third-party service providers (with proper safeguards)",
        "Public health authorities for disease prevention",
      ],
    },
    {
      title: "Data Security",
      icon: Lock,
      content: [
        "Encrypted data transmission and storage",
        "Access controls and user authentication",
        "Regular security audits and monitoring",
        "Staff training on privacy and security",
        "Secure disposal of physical records",
        "Incident response and breach notification procedures",
      ],
    },
  ]

  return (
    <div className="space-y-8">
      <div className="text-center">
        <div className="flex justify-center mb-4">
          <div className="h-16 w-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
            <Shield className="h-8 w-8 text-blue-600 dark:text-blue-400" />
          </div>
        </div>
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Privacy Policy</h1>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
          Your privacy and the security of your personal health information is our top priority.
        </p>
        <div className="flex justify-center mt-4">
          <Badge variant="secondary" className="text-sm">
            Last Updated: January 2024
          </Badge>
        </div>
      </div>

      {/* HIPAA Notice */}
      <Card className="border-blue-200 dark:border-blue-800 bg-blue-50 dark:bg-blue-900/10">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 text-blue-900 dark:text-blue-100">
            <Shield className="h-5 w-5" />
            <span>HIPAA Compliance</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-blue-800 dark:text-blue-200">
            City General Hospital is fully compliant with the Health Insurance Portability and Accountability Act
            (HIPAA). We are committed to protecting your protected health information (PHI) and maintaining the highest
            standards of privacy and security in all our operations.
          </p>
        </CardContent>
      </Card>

      {/* Main Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {sections.map((section, index) => {
          const IconComponent = section.icon
          return (
            <Card key={index}>
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  <div className="h-10 w-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                    <IconComponent className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                  </div>
                  <span>{section.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {section.content.map((item, idx) => (
                    <li key={idx} className="flex items-start space-x-2">
                      <div className="h-1.5 w-1.5 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
                      <span className="text-gray-600 dark:text-gray-400 text-sm">{item}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Patient Rights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Eye className="h-5 w-5" />
            <span>Your Rights</span>
          </CardTitle>
          <CardDescription>As a patient, you have specific rights regarding your health information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              "Access and review your medical records",
              "Request corrections to your health information",
              "Request restrictions on use or disclosure",
              "Choose how we communicate with you",
              "File a complaint about privacy practices",
              "Receive a copy of this privacy notice",
              "Request an accounting of disclosures",
              "Revoke authorization (with exceptions)",
            ].map((right, index) => (
              <div key={index} className="flex items-start space-x-3">
                <div className="h-6 w-6 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5">
                  <div className="h-2 w-2 bg-green-600 dark:bg-green-400 rounded-full" />
                </div>
                <span className="text-gray-600 dark:text-gray-400 text-sm">{right}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Contact Information */}
      <Card>
        <CardHeader>
          <CardTitle>Privacy Officer Contact</CardTitle>
          <CardDescription>For questions about this privacy policy or to exercise your rights</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Privacy Officer</h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Dr. Sarah Johnson
                <br />
                Chief Privacy Officer
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Contact Information</h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Phone: (555) 123-4567 ext. 2100
                <br />
                Email: privacy@citygeneralhospital.com
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Office Hours</h4>
              <p className="text-gray-600 dark:text-gray-400 text-sm">
                Monday - Friday: 9:00 AM - 5:00 PM
                <br />
                Response within 48 hours
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Updates Notice */}
      <Card className="border-yellow-200 dark:border-yellow-800 bg-yellow-50 dark:bg-yellow-900/10">
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <div className="h-8 w-8 bg-yellow-100 dark:bg-yellow-900/20 rounded-full flex items-center justify-center flex-shrink-0">
              <FileText className="h-4 w-4 text-yellow-600 dark:text-yellow-400" />
            </div>
            <div>
              <h3 className="font-semibold text-yellow-900 dark:text-yellow-100 mb-1">Policy Updates</h3>
              <p className="text-yellow-800 dark:text-yellow-200 text-sm">
                We may update this privacy policy from time to time. We will notify you of any material changes by
                posting the new policy on our website and providing notice as required by law. Your continued use of our
                services after such modifications constitutes acceptance of the updated policy.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
