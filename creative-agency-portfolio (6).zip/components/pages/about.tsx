"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Activity, Users, Award, Heart, Shield, Clock } from "lucide-react"

export function AboutPage() {
  const stats = [
    { label: "Years of Service", value: "25+", icon: Clock },
    { label: "Patients Served", value: "50,000+", icon: Users },
    { label: "Medical Staff", value: "200+", icon: Heart },
    { label: "Awards Won", value: "15+", icon: Award },
  ]

  const values = [
    {
      title: "Excellence in Care",
      description: "We strive to provide the highest quality medical care with compassion and expertise.",
      icon: Heart,
    },
    {
      title: "Innovation",
      description: "Embracing cutting-edge technology and modern medical practices for better outcomes.",
      icon: Activity,
    },
    {
      title: "Integrity",
      description: "Maintaining the highest ethical standards in all our medical and administrative practices.",
      icon: Shield,
    },
    {
      title: "Community Focus",
      description: "Serving our community with dedication and building lasting relationships with patients.",
      icon: Users,
    },
  ]

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">About Our Hospital</h1>
        <p className="text-xl text-gray-600 dark:text-gray-400 max-w-3xl mx-auto">
          Dedicated to providing exceptional healthcare services with compassion, innovation, and excellence since 1998.
        </p>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const IconComponent = stat.icon
          return (
            <Card key={index} className="text-center">
              <CardContent className="pt-6">
                <div className="flex justify-center mb-4">
                  <div className="h-12 w-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                    <IconComponent className="h-6 w-6 text-blue-600 dark:text-blue-400" />
                  </div>
                </div>
                <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">{stat.value}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">{stat.label}</div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Mission Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Our Mission</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
            At City General Hospital, our mission is to provide comprehensive, compassionate, and high-quality
            healthcare services to our community. We are committed to healing, comfort, and hope for every patient who
            walks through our doors.
          </p>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
            We believe in treating not just the illness, but the whole person, with dignity, respect, and understanding.
            Our dedicated team of healthcare professionals works tirelessly to ensure that every patient receives
            personalized care tailored to their unique needs.
          </p>
        </CardContent>
      </Card>

      {/* Values Section */}
      <div>
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 text-center">Our Core Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {values.map((value, index) => {
            const IconComponent = value.icon
            return (
              <Card key={index}>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <div className="h-10 w-10 bg-blue-100 dark:bg-blue-900/20 rounded-lg flex items-center justify-center">
                      <IconComponent className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                    </div>
                    <CardTitle className="text-lg">{value.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 dark:text-gray-400">{value.description}</p>
                </CardContent>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Services Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Our Services</CardTitle>
          <CardDescription>Comprehensive healthcare services under one roof</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
            {[
              "Emergency Care",
              "Surgery",
              "Cardiology",
              "Pediatrics",
              "Orthopedics",
              "Radiology",
              "Laboratory",
              "Pharmacy",
              "Maternity",
              "ICU",
              "Outpatient",
              "Rehabilitation",
            ].map((service) => (
              <Badge key={service} variant="secondary" className="justify-center py-2">
                {service}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Accreditation Section */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Accreditation & Certifications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center">
              <div className="h-16 w-16 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Award className="h-8 w-8 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="font-semibold text-gray-900 dark:text-white">JCI Accredited</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Joint Commission International</p>
            </div>
            <div className="text-center">
              <div className="h-16 w-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Shield className="h-8 w-8 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="font-semibold text-gray-900 dark:text-white">ISO 9001:2015</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">Quality Management System</p>
            </div>
            <div className="text-center">
              <div className="h-16 w-16 bg-purple-100 dark:bg-purple-900/20 rounded-full flex items-center justify-center mx-auto mb-3">
                <Heart className="h-8 w-8 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="font-semibold text-gray-900 dark:text-white">NABH Certified</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">National Accreditation Board</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
