"use client"

import { useState } from "react"
import { Sidebar } from "../layout/sidebar"
import { Header } from "../layout/header"
import { DashboardOverview } from "./dashboard-overview"
import { PatientManagement } from "./patient-management"
import { DoctorManagement } from "./doctor-management"
import { AppointmentManagement } from "./appointment-management"
import { LaboratoryManagement } from "./laboratory-management"
import { PharmacyManagement } from "./pharmacy-management"
import { BedManagement } from "./bed-management"
import { BillingManagement } from "./billing-management"
import { DepartmentManagement } from "./department-management"
import { ReportsManagement } from "./reports-management"
import { SettingsManagement } from "./settings-management"
import { AssetManagement } from "./asset-management"
import { AboutPage } from "../pages/about"
import { ContactPage } from "../pages/contact"
import { PrivacyPage } from "../pages/privacy"
import { CareersPage } from "../pages/careers"
import { AIChatWidget } from "../chat/ai-chat-widget"

interface DashboardProps {
  userRole: string
  onLogout: () => void
}

export function Dashboard({ userRole, onLogout }: DashboardProps) {
  const [activeTab, setActiveTab] = useState("dashboard")

  const handleNavigate = (section: string, id?: string) => {
    setActiveTab(section)
    // If there's an ID, we could scroll to that specific item or highlight it
    if (id) {
      console.log(`Navigating to ${section} with ID: ${id}`)
    }
  }

  const renderContent = () => {
    switch (activeTab) {
      case "dashboard":
        return <DashboardOverview userRole={userRole} onNavigate={handleNavigate} />
      case "patients":
        return <PatientManagement userRole={userRole} />
      case "doctors":
        return <DoctorManagement userRole={userRole} />
      case "appointments":
        return <AppointmentManagement userRole={userRole} />
      case "laboratory":
        return <LaboratoryManagement userRole={userRole} />
      case "pharmacy":
        return <PharmacyManagement userRole={userRole} />
      case "beds":
        return <BedManagement userRole={userRole} />
      case "billing":
        return <BillingManagement userRole={userRole} />
      case "departments":
        return <DepartmentManagement userRole={userRole} />
      case "assets":
        return <AssetManagement userRole={userRole} />
      case "reports":
        return <ReportsManagement userRole={userRole} />
      case "settings":
        return <SettingsManagement userRole={userRole} />
      case "about":
        return <AboutPage />
      case "contact":
        return <ContactPage />
      case "privacy":
        return <PrivacyPage />
      case "careers":
        return <CareersPage userRole={userRole} />
      default:
        return <DashboardOverview userRole={userRole} onNavigate={handleNavigate} />
    }
  }

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900 transition-colors">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} userRole={userRole} onLogout={onLogout} />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header userRole={userRole} onNavigate={handleNavigate} />
        <main className="flex-1 overflow-y-auto p-6 bg-gray-50 dark:bg-gray-900">
          <div className="max-w-7xl mx-auto">{renderContent()}</div>
        </main>
      </div>
      <AIChatWidget onNavigate={handleNavigate} />
    </div>
  )
}
