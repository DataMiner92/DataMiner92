"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { DollarSign, CreditCard, AlertCircle, TrendingUp, Plus, Eye, Search, Trash2 } from "lucide-react"
import { toast } from "sonner"

interface BillingManagementProps {
  userRole: string
}

interface Bill {
  id: string
  patientId: string
  patientName: string
  billNumber: string
  items: BillItem[]
  subtotal: number
  tax: number
  discount: number
  total: number
  status: "pending" | "paid" | "overdue" | "cancelled"
  paymentMethod?: string
  notes?: string
  createdAt: string
  paidAt?: string
  dueDate: string
}

interface BillItem {
  id: string
  description: string
  category: string
  quantity: number
  unitPrice: number
  total: number
}

export function BillingManagement({ userRole }: BillingManagementProps) {
  const [bills, setBills] = useState<Bill[]>([])
  const [patients, setPatients] = useState<any[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddBillOpen, setIsAddBillOpen] = useState(false)
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null)

  // Load data from localStorage
  useEffect(() => {
    const savedBills = localStorage.getItem("hms-bills")
    const savedPatients = localStorage.getItem("hms-patients")

    if (savedBills) setBills(JSON.parse(savedBills))
    if (savedPatients) setPatients(JSON.parse(savedPatients))
  }, [])

  // Save bills to localStorage and dispatch event to update dashboard
  useEffect(() => {
    localStorage.setItem("hms-bills", JSON.stringify(bills))

    // Dispatch custom event to notify other components (like dashboard) of data change
    const event = new Event("hms-data-change")
    window.dispatchEvent(event)
  }, [bills])

  const addBill = (billData: Omit<Bill, "id" | "createdAt" | "billNumber">) => {
    const billNumber = `INV-${Date.now()}`
    const newBill: Bill = {
      ...billData,
      id: Date.now().toString(),
      billNumber,
      createdAt: new Date().toISOString(),
    }
    setBills((prev) => [...prev, newBill])
    toast.success("Bill created successfully!")
  }

  const updateBillStatus = (id: string, status: Bill["status"], paymentMethod?: string) => {
    setBills((prev) =>
      prev.map((bill) =>
        bill.id === id
          ? {
              ...bill,
              status,
              paymentMethod: status === "paid" ? paymentMethod : bill.paymentMethod,
              paidAt: status === "paid" ? new Date().toISOString() : bill.paidAt,
            }
          : bill,
      ),
    )
    toast.success(`Bill ${status} successfully!`)
  }

  const deleteBill = (id: string) => {
    if (confirm("Are you sure you want to delete this bill?")) {
      setBills((prev) => prev.filter((b) => b.id !== id))
      toast.success("Bill deleted successfully!")
    }
  }

  const filteredBills = bills.filter(
    (bill) =>
      bill.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bill.billNumber.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const stats = {
    totalRevenue: bills.filter((b) => b.status === "paid").reduce((sum, bill) => sum + bill.total, 0),
    pendingAmount: bills.filter((b) => b.status === "pending").reduce((sum, bill) => sum + bill.total, 0),
    overdueAmount: bills.filter((b) => b.status === "overdue").reduce((sum, bill) => sum + bill.total, 0),
    totalBills: bills.length,
    paidBills: bills.filter((b) => b.status === "paid").length,
    pendingBills: bills.filter((b) => b.status === "pending").length,
    overdueBills: bills.filter((b) => b.status === "overdue").length,
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "paid":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "overdue":
        return "bg-red-100 text-red-800"
      case "cancelled":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Billing Management</h2>
          <p className="text-gray-600 dark:text-gray-400">Manage patient billing and payments</p>
        </div>
        <Dialog open={isAddBillOpen} onOpenChange={setIsAddBillOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Create Bill</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-4xl">
            <DialogHeader>
              <DialogTitle>Create New Bill</DialogTitle>
              <DialogDescription>Create a new bill for a patient</DialogDescription>
            </DialogHeader>
            <BillForm patients={patients} onSubmit={addBill} onClose={() => setIsAddBillOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <DollarSign className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">${stats.totalRevenue.toFixed(2)}</p>
                <p className="text-sm text-gray-600">Total Revenue</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <CreditCard className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.paidBills}</p>
                <p className="text-sm text-gray-600">Paid Bills</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <AlertCircle className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">${stats.pendingAmount.toFixed(2)}</p>
                <p className="text-sm text-gray-600">Pending Amount</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-red-100 rounded-lg">
                <TrendingUp className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">${stats.overdueAmount.toFixed(2)}</p>
                <p className="text-sm text-gray-600">Overdue Amount</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card>
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search bills by patient name or bill number..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Bills List */}
      <Card>
        <CardHeader>
          <CardTitle>Bills</CardTitle>
          <CardDescription>Manage patient bills and payments</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredBills.map((bill) => (
              <div key={bill.id} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <h4 className="font-semibold">{bill.billNumber}</h4>
                    <p className="text-sm text-gray-600">{bill.patientName}</p>
                    <p className="text-xs text-gray-500">Created: {new Date(bill.createdAt).toLocaleDateString()}</p>
                    <p className="text-xs text-gray-500">Due: {new Date(bill.dueDate).toLocaleDateString()}</p>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="text-right">
                      <p className="text-lg font-bold">${bill.total.toFixed(2)}</p>
                      <Badge className={getStatusColor(bill.status)}>{bill.status}</Badge>
                    </div>
                    <div className="flex space-x-2">
                      <Button size="sm" variant="outline" onClick={() => setSelectedBill(bill)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                      {bill.status === "pending" && (
                        <Select
                          onValueChange={(value) => {
                            if (value === "paid") {
                              const paymentMethod = prompt("Enter payment method (Cash, Card, Insurance):")
                              if (paymentMethod) {
                                updateBillStatus(bill.id, "paid", paymentMethod)
                              }
                            } else {
                              updateBillStatus(bill.id, value as Bill["status"])
                            }
                          }}
                        >
                          <SelectTrigger className="w-32">
                            <SelectValue placeholder="Actions" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="paid">Mark Paid</SelectItem>
                            <SelectItem value="overdue">Mark Overdue</SelectItem>
                            <SelectItem value="cancelled">Cancel</SelectItem>
                          </SelectContent>
                        </Select>
                      )}
                      {(userRole === "Admin" || userRole === "Receptionist") && (
                        <Button size="sm" variant="ghost" className="text-red-600" onClick={() => deleteBill(bill.id)}>
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
                <div className="text-sm text-gray-600">
                  <p>Items: {bill.items.length}</p>
                  <p>
                    Subtotal: ${bill.subtotal.toFixed(2)} | Tax: ${bill.tax.toFixed(2)} | Discount: $
                    {bill.discount.toFixed(2)}
                  </p>
                  {bill.paymentMethod && <p>Payment Method: {bill.paymentMethod}</p>}
                  {bill.paidAt && <p>Paid on: {new Date(bill.paidAt).toLocaleDateString()}</p>}
                </div>
              </div>
            ))}
          </div>
          {filteredBills.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500">No bills found. Create your first bill to get started.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bill Details Dialog */}
      <Dialog open={!!selectedBill} onOpenChange={() => setSelectedBill(null)}>
        <DialogContent className="max-w-4xl">{selectedBill && <BillDetailsView bill={selectedBill} />}</DialogContent>
      </Dialog>
    </div>
  )
}

function BillForm({
  patients,
  onSubmit,
  onClose,
}: { patients: any[]; onSubmit: (data: any) => void; onClose: () => void }) {
  const [formData, setFormData] = useState({
    patientId: "",
    patientName: "",
    items: [
      {
        id: "1",
        description: "",
        category: "",
        quantity: 1,
        unitPrice: 0,
        total: 0,
      },
    ],
    subtotal: 0,
    tax: 0,
    discount: 0,
    total: 0,
    status: "pending" as const,
    notes: "",
    dueDate: "",
  })

  const serviceCategories = [
    "Consultation",
    "Laboratory",
    "Radiology",
    "Surgery",
    "Medication",
    "Room Charges",
    "Emergency",
    "Therapy",
    "Equipment",
    "Other",
  ]

  const calculateTotals = (items: BillItem[], discount: number) => {
    const subtotal = items.reduce((sum, item) => sum + item.total, 0)
    const tax = subtotal * 0.1 // 10% tax
    const total = subtotal + tax - discount
    return { subtotal, tax, total }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
    onClose()
  }

  const handlePatientChange = (patientId: string) => {
    const patient = patients.find((p) => p.id === patientId)
    setFormData((prev) => ({
      ...prev,
      patientId,
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : "",
    }))
  }

  const addItem = () => {
    const newItem = {
      id: Date.now().toString(),
      description: "",
      category: "",
      quantity: 1,
      unitPrice: 0,
      total: 0,
    }
    setFormData((prev) => ({
      ...prev,
      items: [...prev.items, newItem],
    }))
  }

  const removeItem = (index: number) => {
    const newItems = formData.items.filter((_, i) => i !== index)
    const { subtotal, tax, total } = calculateTotals(newItems, formData.discount)
    setFormData((prev) => ({
      ...prev,
      items: newItems,
      subtotal,
      tax,
      total,
    }))
  }

  const updateItem = (index: number, field: string, value: any) => {
    const newItems = formData.items.map((item, i) => {
      if (i === index) {
        const updatedItem = { ...item, [field]: value }
        if (field === "quantity" || field === "unitPrice") {
          updatedItem.total = updatedItem.quantity * updatedItem.unitPrice
        }
        return updatedItem
      }
      return item
    })

    const { subtotal, tax, total } = calculateTotals(newItems, formData.discount)
    setFormData((prev) => ({
      ...prev,
      items: newItems,
      subtotal,
      tax,
      total,
    }))
  }

  const updateDiscount = (discount: number) => {
    const { subtotal, tax, total } = calculateTotals(formData.items, discount)
    setFormData((prev) => ({
      ...prev,
      discount,
      subtotal,
      tax,
      total,
    }))
  }

  // Set default due date to 30 days from now
  useEffect(() => {
    const dueDate = new Date()
    dueDate.setDate(dueDate.getDate() + 30)
    setFormData((prev) => ({
      ...prev,
      dueDate: dueDate.toISOString().split("T")[0],
    }))
  }, [])

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="patient">Patient *</Label>
          <Select value={formData.patientId} onValueChange={handlePatientChange} required>
            <SelectTrigger>
              <SelectValue placeholder="Select patient" />
            </SelectTrigger>
            <SelectContent>
              {patients.map((patient) => (
                <SelectItem key={patient.id} value={patient.id}>
                  {patient.firstName} {patient.lastName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="dueDate">Due Date *</Label>
          <Input
            id="dueDate"
            type="date"
            value={formData.dueDate}
            onChange={(e) => setFormData((prev) => ({ ...prev, dueDate: e.target.value }))}
            required
          />
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Bill Items *</Label>
          <Button type="button" variant="outline" size="sm" onClick={addItem}>
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>

        {formData.items.map((item, index) => (
          <div key={item.id} className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Item {index + 1}</h4>
              {formData.items.length > 1 && (
                <Button type="button" variant="ghost" size="sm" onClick={() => removeItem(index)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Description</Label>
                <Input
                  placeholder="Service/item description"
                  value={item.description}
                  onChange={(e) => updateItem(index, "description", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Category</Label>
                <Select value={item.category} onValueChange={(value) => updateItem(index, "category", value)} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {serviceCategories.map((category) => (
                      <SelectItem key={category} value={category}>
                        {category}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-4 gap-3">
              <div className="space-y-2">
                <Label>Quantity</Label>
                <Input
                  type="number"
                  min="1"
                  value={item.quantity}
                  onChange={(e) => updateItem(index, "quantity", Number.parseInt(e.target.value))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Unit Price</Label>
                <Input
                  type="number"
                  step="0.01"
                  min="0"
                  value={item.unitPrice}
                  onChange={(e) => updateItem(index, "unitPrice", Number.parseFloat(e.target.value))}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Total</Label>
                <Input value={`$${item.total.toFixed(2)}`} readOnly className="bg-gray-50" />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="border-t pt-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-3">
            <div className="space-y-2">
              <Label htmlFor="discount">Discount ($)</Label>
              <Input
                id="discount"
                type="number"
                step="0.01"
                min="0"
                value={formData.discount}
                onChange={(e) => updateDiscount(Number.parseFloat(e.target.value) || 0)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="notes">Notes</Label>
              <Textarea
                id="notes"
                placeholder="Additional notes..."
                value={formData.notes}
                onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
              />
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span className="font-medium">${formData.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Tax (10%):</span>
              <span className="font-medium">${formData.tax.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>Discount:</span>
              <span className="font-medium">-${formData.discount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-lg font-bold border-t pt-2">
              <span>Total:</span>
              <span>${formData.total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">Create Bill</Button>
      </div>
    </form>
  )
}

function BillDetailsView({ bill }: { bill: Bill }) {
  return (
    <div>
      <DialogHeader>
        <DialogTitle>Bill Details - {bill.billNumber}</DialogTitle>
        <DialogDescription>Patient: {bill.patientName}</DialogDescription>
      </DialogHeader>

      <div className="mt-6 space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium text-gray-600">Bill Number</Label>
            <p className="font-medium">{bill.billNumber}</p>
          </div>
          <div>
            <Label className="text-sm font-medium text-gray-600">Status</Label>
            <Badge
              className={`mt-1 ${bill.status === "paid" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
            >
              {bill.status}
            </Badge>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium text-gray-600">Created Date</Label>
            <p className="font-medium">{new Date(bill.createdAt).toLocaleDateString()}</p>
          </div>
          <div>
            <Label className="text-sm font-medium text-gray-600">Due Date</Label>
            <p className="font-medium">{new Date(bill.dueDate).toLocaleDateString()}</p>
          </div>
        </div>

        {bill.paidAt && (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-sm font-medium text-gray-600">Paid Date</Label>
              <p className="font-medium">{new Date(bill.paidAt).toLocaleDateString()}</p>
            </div>
            <div>
              <Label className="text-sm font-medium text-gray-600">Payment Method</Label>
              <p className="font-medium">{bill.paymentMethod || "N/A"}</p>
            </div>
          </div>
        )}

        <div>
          <Label className="text-sm font-medium text-gray-600 mb-3 block">Bill Items</Label>
          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left">Description</th>
                  <th className="px-4 py-2 text-left">Category</th>
                  <th className="px-4 py-2 text-right">Qty</th>
                  <th className="px-4 py-2 text-right">Unit Price</th>
                  <th className="px-4 py-2 text-right">Total</th>
                </tr>
              </thead>
              <tbody>
                {bill.items.map((item, index) => (
                  <tr key={index} className="border-t">
                    <td className="px-4 py-2">{item.description}</td>
                    <td className="px-4 py-2">{item.category}</td>
                    <td className="px-4 py-2 text-right">{item.quantity}</td>
                    <td className="px-4 py-2 text-right">${item.unitPrice.toFixed(2)}</td>
                    <td className="px-4 py-2 text-right">${item.total.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="border-t pt-4">
          <div className="flex justify-end">
            <div className="w-64 space-y-2">
              <div className="flex justify-between">
                <span>Subtotal:</span>
                <span>${bill.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Tax:</span>
                <span>${bill.tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span>Discount:</span>
                <span>-${bill.discount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-lg font-bold border-t pt-2">
                <span>Total:</span>
                <span>${bill.total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {bill.notes && (
          <div>
            <Label className="text-sm font-medium text-gray-600">Notes</Label>
            <p className="mt-1 text-gray-700">{bill.notes}</p>
          </div>
        )}
      </div>
    </div>
  )
}
