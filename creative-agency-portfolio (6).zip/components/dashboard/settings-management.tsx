"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "sonner"
import { Building, Bell, Shield, Database, Users, Save, Download, Upload, Globe, Lock } from "lucide-react"

interface SettingsManagementProps {
  userRole: string
}

export function SettingsManagement({ userRole }: SettingsManagementProps) {
  // Only allow admin access
  if (userRole !== "Admin") {
    return (
      <div className="flex flex-col items-center justify-center h-96">
        <Shield className="h-16 w-16 text-gray-400 mb-4" />
        <h2 className="text-2xl font-bold text-gray-700">Access Restricted</h2>
        <p className="text-gray-500 mt-2">Only administrators can access system settings.</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">System Settings</h2>
        <p className="text-gray-600 dark:text-gray-400">Configure your hospital management system</p>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="grid grid-cols-5 gap-4">
          <TabsTrigger value="general" className="flex items-center gap-2">
            <Building className="h-4 w-4" />
            <span>General</span>
          </TabsTrigger>
          <TabsTrigger value="notifications" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            <span>Notifications</span>
          </TabsTrigger>
          <TabsTrigger value="security" className="flex items-center gap-2">
            <Shield className="h-4 w-4" />
            <span>Security</span>
          </TabsTrigger>
          <TabsTrigger value="backup" className="flex items-center gap-2">
            <Database className="h-4 w-4" />
            <span>Backup & Data</span>
          </TabsTrigger>
          <TabsTrigger value="roles" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            <span>User Roles</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <GeneralSettings />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationSettings />
        </TabsContent>

        <TabsContent value="security">
          <SecuritySettings />
        </TabsContent>

        <TabsContent value="backup">
          <BackupSettings />
        </TabsContent>

        <TabsContent value="roles">
          <RoleSettings />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function GeneralSettings() {
  const [settings, setSettings] = useState({
    hospitalName: "City General Hospital",
    address: "123 Healthcare Blvd, Medical City, MC 12345",
    phone: "(555) 123-4567",
    email: "info@citygeneralhospital.com",
    website: "https://www.citygeneralhospital.com",
    timezone: "UTC-5",
    currency: "USD",
    language: "en-US",
    taxRate: "10",
    fiscalYear: "January-December",
  })

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem("hms-general-settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  const handleChange = (field: string, value: string) => {
    setSettings((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSave = () => {
    localStorage.setItem("hms-general-settings", JSON.stringify(settings))
    toast.success("General settings saved successfully!")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>General Settings</CardTitle>
        <CardDescription>Configure your hospital information and system preferences</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Building className="h-5 w-5" />
            Hospital Information
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="hospitalName">Hospital Name</Label>
              <Input
                id="hospitalName"
                value={settings.hospitalName}
                onChange={(e) => handleChange("hospitalName", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="website">Website</Label>
              <Input id="website" value={settings.website} onChange={(e) => handleChange("website", e.target.value)} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={settings.email}
                onChange={(e) => handleChange("email", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" value={settings.phone} onChange={(e) => handleChange("phone", e.target.value)} />
            </div>

            <div className="space-y-2 col-span-2">
              <Label htmlFor="address">Address</Label>
              <Textarea
                id="address"
                value={settings.address}
                onChange={(e) => handleChange("address", e.target.value)}
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Globe className="h-5 w-5" />
            System Configuration
          </h3>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="language">Language</Label>
              <Select value={settings.language} onValueChange={(value) => handleChange("language", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select language" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en-US">English (US)</SelectItem>
                  <SelectItem value="en-GB">English (UK)</SelectItem>
                  <SelectItem value="es-ES">Spanish</SelectItem>
                  <SelectItem value="fr-FR">French</SelectItem>
                  <SelectItem value="de-DE">German</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="timezone">Timezone</Label>
              <Select value={settings.timezone} onValueChange={(value) => handleChange("timezone", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select timezone" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="UTC-12">UTC-12</SelectItem>
                  <SelectItem value="UTC-11">UTC-11</SelectItem>
                  <SelectItem value="UTC-10">UTC-10</SelectItem>
                  <SelectItem value="UTC-9">UTC-9</SelectItem>
                  <SelectItem value="UTC-8">UTC-8 (PST)</SelectItem>
                  <SelectItem value="UTC-7">UTC-7 (MST)</SelectItem>
                  <SelectItem value="UTC-6">UTC-6 (CST)</SelectItem>
                  <SelectItem value="UTC-5">UTC-5 (EST)</SelectItem>
                  <SelectItem value="UTC-4">UTC-4</SelectItem>
                  <SelectItem value="UTC-3">UTC-3</SelectItem>
                  <SelectItem value="UTC-2">UTC-2</SelectItem>
                  <SelectItem value="UTC-1">UTC-1</SelectItem>
                  <SelectItem value="UTC+0">UTC+0</SelectItem>
                  <SelectItem value="UTC+1">UTC+1 (CET)</SelectItem>
                  <SelectItem value="UTC+2">UTC+2</SelectItem>
                  <SelectItem value="UTC+3">UTC+3</SelectItem>
                  <SelectItem value="UTC+4">UTC+4</SelectItem>
                  <SelectItem value="UTC+5">UTC+5</SelectItem>
                  <SelectItem value="UTC+5:30">UTC+5:30 (IST)</SelectItem>
                  <SelectItem value="UTC+6">UTC+6</SelectItem>
                  <SelectItem value="UTC+7">UTC+7</SelectItem>
                  <SelectItem value="UTC+8">UTC+8</SelectItem>
                  <SelectItem value="UTC+9">UTC+9 (JST)</SelectItem>
                  <SelectItem value="UTC+10">UTC+10</SelectItem>
                  <SelectItem value="UTC+11">UTC+11</SelectItem>
                  <SelectItem value="UTC+12">UTC+12</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="currency">Currency</Label>
              <Select value={settings.currency} onValueChange={(value) => handleChange("currency", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select currency" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="USD">USD ($)</SelectItem>
                  <SelectItem value="KES">KES (KES)</SelectItem>
                  <SelectItem value="EUR">EUR (€)</SelectItem>
                  <SelectItem value="GBP">GBP (£)</SelectItem>
                  <SelectItem value="JPY">JPY (¥)</SelectItem>
                  <SelectItem value="CAD">CAD ($)</SelectItem>
                  <SelectItem value="AUD">AUD ($)</SelectItem>
                  <SelectItem value="INR">INR (₹)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="taxRate">Default Tax Rate (%)</Label>
              <Input
                id="taxRate"
                type="number"
                min="0"
                max="100"
                value={settings.taxRate}
                onChange={(e) => handleChange("taxRate", e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fiscalYear">Fiscal Year</Label>
              <Select value={settings.fiscalYear} onValueChange={(value) => handleChange("fiscalYear", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select fiscal year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="January-December">January-December</SelectItem>
                  <SelectItem value="April-March">April-March</SelectItem>
                  <SelectItem value="July-June">July-June</SelectItem>
                  <SelectItem value="October-September">October-September</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function NotificationSettings() {
  const [settings, setSettings] = useState({
    emailNotifications: true,
    smsAlerts: false,
    criticalAlerts: true,
    appointmentReminders: true,
    billingNotifications: true,
    systemUpdates: true,
    reminderTiming: "24",
    emailFormat: "html",
    notifyPatients: true,
    notifyDoctors: true,
    notifyStaff: true,
  })

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem("hms-notification-settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  const handleToggle = (field: string, checked: boolean) => {
    setSettings((prev) => ({
      ...prev,
      [field]: checked,
    }))
  }

  const handleChange = (field: string, value: string) => {
    setSettings((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSave = () => {
    localStorage.setItem("hms-notification-settings", JSON.stringify(settings))
    toast.success("Notification settings saved successfully!")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Notification Settings</CardTitle>
        <CardDescription>Configure how and when notifications are sent</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Notification Channels</h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="emailNotifications">Email Notifications</Label>
                <p className="text-sm text-gray-500">Send notifications via email</p>
              </div>
              <Switch
                id="emailNotifications"
                checked={settings.emailNotifications}
                onCheckedChange={(checked) => handleToggle("emailNotifications", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="smsAlerts">SMS Alerts</Label>
                <p className="text-sm text-gray-500">Send urgent notifications via text message</p>
              </div>
              <Switch
                id="smsAlerts"
                checked={settings.smsAlerts}
                onCheckedChange={(checked) => handleToggle("smsAlerts", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="criticalAlerts">Critical Alerts</Label>
                <p className="text-sm text-gray-500">Emergency system notifications</p>
              </div>
              <Switch
                id="criticalAlerts"
                checked={settings.criticalAlerts}
                onCheckedChange={(checked) => handleToggle("criticalAlerts", checked)}
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Notification Types</h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="appointmentReminders">Appointment Reminders</Label>
                <p className="text-sm text-gray-500">Notify about upcoming appointments</p>
              </div>
              <Switch
                id="appointmentReminders"
                checked={settings.appointmentReminders}
                onCheckedChange={(checked) => handleToggle("appointmentReminders", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="billingNotifications">Billing Notifications</Label>
                <p className="text-sm text-gray-500">Payment and billing alerts</p>
              </div>
              <Switch
                id="billingNotifications"
                checked={settings.billingNotifications}
                onCheckedChange={(checked) => handleToggle("billingNotifications", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="systemUpdates">System Updates</Label>
                <p className="text-sm text-gray-500">Maintenance and update notifications</p>
              </div>
              <Switch
                id="systemUpdates"
                checked={settings.systemUpdates}
                onCheckedChange={(checked) => handleToggle("systemUpdates", checked)}
              />
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Configuration</h3>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="reminderTiming">Appointment Reminder Timing</Label>
              <Select value={settings.reminderTiming} onValueChange={(value) => handleChange("reminderTiming", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select timing" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 hour before</SelectItem>
                  <SelectItem value="2">2 hours before</SelectItem>
                  <SelectItem value="24">24 hours before</SelectItem>
                  <SelectItem value="48">48 hours before</SelectItem>
                  <SelectItem value="72">72 hours before</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="emailFormat">Email Format</Label>
              <Select value={settings.emailFormat} onValueChange={(value) => handleChange("emailFormat", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select format" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="html">HTML</SelectItem>
                  <SelectItem value="text">Plain Text</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-4 pt-2">
            <h4 className="font-medium">Recipient Groups</h4>

            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <Switch
                  id="notifyPatients"
                  checked={settings.notifyPatients}
                  onCheckedChange={(checked) => handleToggle("notifyPatients", checked)}
                />
                <Label htmlFor="notifyPatients">Notify Patients</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="notifyDoctors"
                  checked={settings.notifyDoctors}
                  onCheckedChange={(checked) => handleToggle("notifyDoctors", checked)}
                />
                <Label htmlFor="notifyDoctors">Notify Doctors</Label>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="notifyStaff"
                  checked={settings.notifyStaff}
                  onCheckedChange={(checked) => handleToggle("notifyStaff", checked)}
                />
                <Label htmlFor="notifyStaff">Notify Staff</Label>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function SecuritySettings() {
  const [settings, setSettings] = useState({
    twoFactorAuth: false,
    sessionTimeout: "30",
    passwordPolicy: "strong",
    maxLoginAttempts: "5",
    dataEncryption: true,
    auditLogging: true,
    passwordExpiry: "90",
    ipRestriction: false,
    allowedIPs: "",
  })

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem("hms-security-settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  const handleToggle = (field: string, checked: boolean) => {
    setSettings((prev) => ({
      ...prev,
      [field]: checked,
    }))
  }

  const handleChange = (field: string, value: string) => {
    setSettings((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSave = () => {
    localStorage.setItem("hms-security-settings", JSON.stringify(settings))
    toast.success("Security settings saved successfully!")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Security Settings</CardTitle>
        <CardDescription>Configure system security and access controls</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Authentication
          </h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="twoFactorAuth">Two-Factor Authentication</Label>
                <p className="text-sm text-gray-500">Require 2FA for all admin users</p>
              </div>
              <Switch
                id="twoFactorAuth"
                checked={settings.twoFactorAuth}
                onCheckedChange={(checked) => handleToggle("twoFactorAuth", checked)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
              <Select value={settings.sessionTimeout} onValueChange={(value) => handleChange("sessionTimeout", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select timeout" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="15">15 minutes</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                  <SelectItem value="240">4 hours</SelectItem>
                  <SelectItem value="480">8 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="passwordPolicy">Password Policy</Label>
              <Select value={settings.passwordPolicy} onValueChange={(value) => handleChange("passwordPolicy", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select policy" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="basic">Basic (8+ characters)</SelectItem>
                  <SelectItem value="strong">Strong (8+ chars, uppercase, lowercase, number)</SelectItem>
                  <SelectItem value="very-strong">
                    Very Strong (12+ chars, uppercase, lowercase, number, symbol)
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="maxLoginAttempts">Maximum Login Attempts</Label>
              <Select
                value={settings.maxLoginAttempts}
                onValueChange={(value) => handleChange("maxLoginAttempts", value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select maximum attempts" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">3 attempts</SelectItem>
                  <SelectItem value="5">5 attempts</SelectItem>
                  <SelectItem value="10">10 attempts</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="passwordExpiry">Password Expiry (days)</Label>
              <Select value={settings.passwordExpiry} onValueChange={(value) => handleChange("passwordExpiry", value)}>
                <SelectTrigger>
                  <SelectValue placeholder="Select expiry period" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30">30 days</SelectItem>
                  <SelectItem value="60">60 days</SelectItem>
                  <SelectItem value="90">90 days</SelectItem>
                  <SelectItem value="180">180 days</SelectItem>
                  <SelectItem value="365">365 days</SelectItem>
                  <SelectItem value="never">Never</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Data Protection
          </h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="dataEncryption">Data Encryption</Label>
                <p className="text-sm text-gray-500">Encrypt sensitive data at rest</p>
              </div>
              <Switch
                id="dataEncryption"
                checked={settings.dataEncryption}
                onCheckedChange={(checked) => handleToggle("dataEncryption", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="auditLogging">Audit Logging</Label>
                <p className="text-sm text-gray-500">Log all user activities</p>
              </div>
              <Switch
                id="auditLogging"
                checked={settings.auditLogging}
                onCheckedChange={(checked) => handleToggle("auditLogging", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="ipRestriction">IP Restriction</Label>
                <p className="text-sm text-gray-500">Restrict access to specific IP addresses</p>
              </div>
              <Switch
                id="ipRestriction"
                checked={settings.ipRestriction}
                onCheckedChange={(checked) => handleToggle("ipRestriction", checked)}
              />
            </div>

            {settings.ipRestriction && (
              <div className="space-y-2">
                <Label htmlFor="allowedIPs">Allowed IP Addresses</Label>
                <Textarea
                  id="allowedIPs"
                  placeholder="Enter IP addresses, one per line"
                  value={settings.allowedIPs}
                  onChange={(e) => handleChange("allowedIPs", e.target.value)}
                />
                <p className="text-xs text-gray-500">
                  Enter one IP address or range per line (e.g., 192.168.1.1 or 192.168.1.0/24)
                </p>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function BackupSettings() {
  const [settings, setSettings] = useState({
    autoBackup: true,
    backupFrequency: "daily",
    storageLocation: "local",
    retentionPeriod: "30",
    includePatientData: true,
    includeBillingData: true,
    includeSystemSettings: true,
  })

  // Load settings from localStorage
  useEffect(() => {
    const savedSettings = localStorage.getItem("hms-backup-settings")
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings))
    }
  }, [])

  const handleToggle = (field: string, checked: boolean) => {
    setSettings((prev) => ({
      ...prev,
      [field]: checked,
    }))
  }

  const handleChange = (field: string, value: string) => {
    setSettings((prev) => ({
      ...prev,
      [field]: value,
    }))
  }

  const handleSave = () => {
    localStorage.setItem("hms-backup-settings", JSON.stringify(settings))
    toast.success("Backup settings saved successfully!")
  }

  const handleBackupNow = () => {
    // Collect all data from localStorage
    const data = {
      patients: JSON.parse(localStorage.getItem("hms-patients") || "[]"),
      doctors: JSON.parse(localStorage.getItem("hms-doctors") || "[]"),
      appointments: JSON.parse(localStorage.getItem("hms-appointments") || "[]"),
      bills: JSON.parse(localStorage.getItem("hms-bills") || "[]"),
      beds: JSON.parse(localStorage.getItem("hms-beds") || "[]"),
      labTests: JSON.parse(localStorage.getItem("hms-lab-tests") || "[]"),
      medications: JSON.parse(localStorage.getItem("hms-medications") || "[]"),
      departments: JSON.parse(localStorage.getItem("hms-departments") || "[]"),
      settings: {
        general: JSON.parse(localStorage.getItem("hms-general-settings") || "{}"),
        notification: JSON.parse(localStorage.getItem("hms-notification-settings") || "{}"),
        security: JSON.parse(localStorage.getItem("hms-security-settings") || "{}"),
        backup: JSON.parse(localStorage.getItem("hms-backup-settings") || "{}"),
        roles: JSON.parse(localStorage.getItem("hms-role-settings") || "{}"),
      },
    }

    // Create a JSON file for download
    const dataStr = JSON.stringify(data, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })

    // Create download link
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `hms-backup-${new Date().toISOString().split("T")[0]}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    toast.success("Backup created successfully!")
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Backup & Data Management</CardTitle>
        <CardDescription>Configure system backups and data retention</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Database className="h-5 w-5" />
            Backup Configuration
          </h3>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="autoBackup">Automatic Backups</Label>
                <p className="text-sm text-gray-500">Schedule regular system backups</p>
              </div>
              <Switch
                id="autoBackup"
                checked={settings.autoBackup}
                onCheckedChange={(checked) => handleToggle("autoBackup", checked)}
              />
            </div>

            {settings.autoBackup && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="backupFrequency">Backup Frequency</Label>
                  <Select
                    value={settings.backupFrequency}
                    onValueChange={(value) => handleChange("backupFrequency", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select frequency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hourly">Hourly</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="storageLocation">Storage Location</Label>
                  <Select
                    value={settings.storageLocation}
                    onValueChange={(value) => handleChange("storageLocation", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="local">Local Storage</SelectItem>
                      <SelectItem value="cloud">Cloud Storage</SelectItem>
                      <SelectItem value="network">Network Drive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="retentionPeriod">Retention Period (days)</Label>
                  <Select
                    value={settings.retentionPeriod}
                    onValueChange={(value) => handleChange("retentionPeriod", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select period" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 days</SelectItem>
                      <SelectItem value="30">30 days</SelectItem>
                      <SelectItem value="90">90 days</SelectItem>
                      <SelectItem value="180">180 days</SelectItem>
                      <SelectItem value="365">365 days</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Data Selection</h3>

          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Switch
                id="includePatientData"
                checked={settings.includePatientData}
                onCheckedChange={(checked) => handleToggle("includePatientData", checked)}
              />
              <Label htmlFor="includePatientData">Include Patient Data</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="includeBillingData"
                checked={settings.includeBillingData}
                onCheckedChange={(checked) => handleToggle("includeBillingData", checked)}
              />
              <Label htmlFor="includeBillingData">Include Billing Data</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="includeSystemSettings"
                checked={settings.includeSystemSettings}
                onCheckedChange={(checked) => handleToggle("includeSystemSettings", checked)}
              />
              <Label htmlFor="includeSystemSettings">Include System Settings</Label>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-lg font-medium">Manual Backup</h3>

          <div className="flex space-x-4">
            <Button onClick={handleBackupNow} className="flex items-center gap-2">
              <Download className="h-4 w-4" />
              Backup Now
            </Button>

            <Button variant="outline" className="flex items-center gap-2 bg-transparent">
              <Upload className="h-4 w-4" />
              Restore Backup
            </Button>
          </div>
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Settings
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

function RoleSettings() {
  const [roles, setRoles] = useState([
    {
      id: "admin",
      name: "Admin",
      description: "Full system access",
      permissions: {
        dashboard: true,
        patients: true,
        doctors: true,
        appointments: true,
        laboratory: true,
        pharmacy: true,
        beds: true,
        billing: true,
        departments: true,
        reports: true,
        settings: true,
      },
      canCreate: true,
      canEdit: true,
      canDelete: true,
      canExport: true,
    },
    {
      id: "doctor",
      name: "Doctor",
      description: "Medical staff access",
      permissions: {
        dashboard: true,
        patients: true,
        doctors: false,
        appointments: true,
        laboratory: true,
        pharmacy: true,
        beds: true,
        billing: false,
        departments: true,
        reports: true,
        settings: false,
      },
      canCreate: true,
      canEdit: true,
      canDelete: false,
      canExport: true,
    },
    {
      id: "nurse",
      name: "Nurse",
      description: "Nursing staff access",
      permissions: {
        dashboard: true,
        patients: true,
        doctors: false,
        appointments: true,
        laboratory: true,
        pharmacy: true,
        beds: true,
        billing: false,
        departments: false,
        reports: false,
        settings: false,
      },
      canCreate: false,
      canEdit: true,
      canDelete: false,
      canExport: false,
    },
    {
      id: "receptionist",
      name: "Receptionist",
      description: "Front desk access",
      permissions: {
        dashboard: true,
        patients: true,
        doctors: false,
        appointments: true,
        laboratory: false,
        pharmacy: false,
        beds: true,
        billing: true,
        departments: false,
        reports: false,
        settings: false,
      },
      canCreate: true,
      canEdit: true,
      canDelete: false,
      canExport: false,
    },
    {
      id: "pharmacist",
      name: "Pharmacist",
      description: "Pharmacy access",
      permissions: {
        dashboard: true,
        patients: true,
        doctors: false,
        appointments: false,
        laboratory: false,
        pharmacy: true,
        beds: false,
        billing: false,
        departments: false,
        reports: false,
        settings: false,
      },
      canCreate: true,
      canEdit: true,
      canDelete: false,
      canExport: false,
    },
  ])

  // Load roles from localStorage
  useEffect(() => {
    const savedRoles = localStorage.getItem("hms-role-settings")
    if (savedRoles) {
      setRoles(JSON.parse(savedRoles))
    }
  }, [])

  const handleSave = () => {
    localStorage.setItem("hms-role-settings", JSON.stringify(roles))
    toast.success("Role settings saved successfully!")
  }

  const togglePermission = (roleId: string, permission: string, value: boolean) => {
    setRoles((prev) =>
      prev.map((role) =>
        role.id === roleId
          ? {
              ...role,
              permissions: {
                ...role.permissions,
                [permission]: value,
              },
            }
          : role,
      ),
    )
  }

  const toggleCapability = (roleId: string, capability: string, value: boolean) => {
    setRoles((prev) =>
      prev.map((role) =>
        role.id === roleId
          ? {
              ...role,
              [capability]: value,
            }
          : role,
      ),
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>User Roles & Permissions</CardTitle>
        <CardDescription>Configure user roles and access permissions</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium flex items-center gap-2">
            <Users className="h-5 w-5" />
            Role Management
          </h3>

          <div className="space-y-6">
            {roles.map((role) => (
              <div key={role.id} className="border rounded-lg p-4 space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="font-medium text-lg">{role.name}</h4>
                    <p className="text-sm text-gray-500">{role.description}</p>
                  </div>
                </div>

                <div>
                  <h5 className="font-medium mb-2">Module Access</h5>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {Object.entries(role.permissions).map(([key, value]) => (
                      <div key={key} className="flex items-center space-x-2">
                        <Switch
                          id={`${role.id}-${key}`}
                          checked={value as boolean}
                          onCheckedChange={(checked) => togglePermission(role.id, key, checked)}
                          disabled={role.id === "admin" && key === "dashboard"} // Admin must have dashboard access
                        />
                        <Label htmlFor={`${role.id}-${key}`} className="capitalize">
                          {key}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h5 className="font-medium mb-2">Capabilities</h5>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${role.id}-create`}
                        checked={role.canCreate}
                        onCheckedChange={(checked) => toggleCapability(role.id, "canCreate", checked)}
                        disabled={role.id === "admin"} // Admin must have all capabilities
                      />
                      <Label htmlFor={`${role.id}-create`}>Create</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${role.id}-edit`}
                        checked={role.canEdit}
                        onCheckedChange={(checked) => toggleCapability(role.id, "canEdit", checked)}
                        disabled={role.id === "admin"} // Admin must have all capabilities
                      />
                      <Label htmlFor={`${role.id}-edit`}>Edit</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${role.id}-delete`}
                        checked={role.canDelete}
                        onCheckedChange={(checked) => toggleCapability(role.id, "canDelete", checked)}
                        disabled={role.id === "admin"} // Admin must have all capabilities
                      />
                      <Label htmlFor={`${role.id}-delete`}>Delete</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        id={`${role.id}-export`}
                        checked={role.canExport}
                        onCheckedChange={(checked) => toggleCapability(role.id, "canExport", checked)}
                        disabled={role.id === "admin"} // Admin must have all capabilities
                      />
                      <Label htmlFor={`${role.id}-export`}>Export</Label>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end">
          <Button onClick={handleSave} className="flex items-center gap-2">
            <Save className="h-4 w-4" />
            Save Roles
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
