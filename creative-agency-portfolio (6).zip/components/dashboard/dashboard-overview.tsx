"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Users, UserCheck, Calendar, Activity, DollarSign, Bed, FileText, TrendingUp } from "lucide-react"

interface DashboardOverviewProps {
  userRole: string
  onNavigate: (section: string) => void
}

export function DashboardOverview({ userRole, onNavigate }: DashboardOverviewProps) {
  const [stats, setStats] = useState({
    totalPatients: 0,
    totalDoctors: 0,
    todayAppointments: 0,
    totalRevenue: 0,
    availableBeds: 0,
    occupiedBeds: 0,
    pendingBills: 0,
    paidBills: 0,
    monthlyRevenue: 0,
    monthlyTarget: 50000,
  })

  const [recentActivity, setRecentActivity] = useState<any[]>([])
  const [recentBills, setRecentBills] = useState<any[]>([])

  useEffect(() => {
    const loadDashboardData = () => {
      // Get all data from localStorage
      const patients = JSON.parse(localStorage.getItem("hms-patients") || "[]")
      const doctors = JSON.parse(localStorage.getItem("hms-doctors") || "[]")
      const appointments = JSON.parse(localStorage.getItem("hms-appointments") || "[]")
      const bills = JSON.parse(localStorage.getItem("hms-bills") || "[]")
      const beds = JSON.parse(localStorage.getItem("hms-beds") || "[]")

      console.log("Bills data:", bills) // Debug log

      // Calculate today's appointments
      const today = new Date().toISOString().split("T")[0]
      const todayAppointments = appointments.filter((apt: any) => apt.date === today).length

      // Calculate revenue from paid bills - Fixed calculation
      const paidBills = bills.filter((bill: any) => bill.status === "paid")
      const totalRevenue = paidBills.reduce((sum: number, bill: any) => {
        const amount = Number.parseFloat(bill.total || bill.amount || 0)
        return sum + amount
      }, 0)

      console.log("Paid bills:", paidBills) // Debug log
      console.log("Total revenue:", totalRevenue) // Debug log

      // Calculate pending bills
      const pendingBills = bills.filter((bill: any) => bill.status === "pending").length

      // Calculate monthly revenue (current month)
      const currentMonth = new Date().getMonth()
      const currentYear = new Date().getFullYear()
      const monthlyRevenue = paidBills
        .filter((bill: any) => {
          const billDate = new Date(bill.createdAt || bill.paidAt)
          return billDate.getMonth() === currentMonth && billDate.getFullYear() === currentYear
        })
        .reduce((sum: number, bill: any) => {
          const amount = Number.parseFloat(bill.total || bill.amount || 0)
          return sum + amount
        }, 0)

      // Calculate bed statistics
      const availableBeds = beds.filter((bed: any) => bed.status === "available" || bed.status === "Available").length
      const occupiedBeds = beds.filter((bed: any) => bed.status === "occupied" || bed.status === "Occupied").length

      setStats({
        totalPatients: patients.length,
        totalDoctors: doctors.length,
        todayAppointments,
        totalRevenue,
        availableBeds,
        occupiedBeds,
        pendingBills,
        paidBills: paidBills.length,
        monthlyRevenue,
        monthlyTarget: 50000,
      })

      // Get recent bills for display
      const recentBillsData = bills
        .sort((a: any, b: any) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5)
      setRecentBills(recentBillsData)

      // Generate recent activity
      const activities = []

      // Recent appointments
      const recentAppointments = appointments
        .sort(
          (a: any, b: any) =>
            new Date(b.createdAt || Date.now()).getTime() - new Date(a.createdAt || Date.now()).getTime(),
        )
        .slice(0, 3)

      recentAppointments.forEach((apt: any) => {
        activities.push({
          type: "appointment",
          title: `Appointment scheduled`,
          description: `${apt.patientName} with Dr. ${apt.doctorName}`,
          time: new Date(apt.createdAt || Date.now()).toLocaleTimeString(),
          status: apt.status,
        })
      })

      // Recent patients
      const recentPatients = patients
        .sort(
          (a: any, b: any) =>
            new Date(b.createdAt || Date.now()).getTime() - new Date(a.createdAt || Date.now()).getTime(),
        )
        .slice(0, 2)

      recentPatients.forEach((patient: any) => {
        activities.push({
          type: "patient",
          title: `New patient registered`,
          description: `${patient.firstName} ${patient.lastName} - ${patient.patientId}`,
          time: new Date(patient.createdAt || Date.now()).toLocaleTimeString(),
          status: "Active",
        })
      })

      // Recent paid bills
      paidBills.slice(0, 2).forEach((bill: any) => {
        activities.push({
          type: "payment",
          title: `Payment received`,
          description: `${bill.patientName} - $${Number.parseFloat(bill.total || 0).toFixed(2)}`,
          time: new Date(bill.paidAt || bill.createdAt).toLocaleTimeString(),
          status: "Paid",
        })
      })

      setRecentActivity(activities.slice(0, 6))
    }

    loadDashboardData()

    // Listen for changes in localStorage to update dashboard in real-time
    const handleStorageChange = () => {
      loadDashboardData()
    }

    window.addEventListener("storage", handleStorageChange)
    window.addEventListener("hms-data-change", handleStorageChange)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      window.removeEventListener("hms-data-change", handleStorageChange)
    }
  }, [])

  const quickActions = [
    {
      title: "Add Patient",
      description: "Register a new patient",
      icon: <Users className="h-5 w-5" />,
      action: () => onNavigate("patients"),
      color: "bg-blue-500 hover:bg-blue-600",
    },
    {
      title: "Schedule Appointment",
      description: "Book a new appointment",
      icon: <Calendar className="h-5 w-5" />,
      action: () => onNavigate("appointments"),
      color: "bg-green-500 hover:bg-green-600",
    },
    {
      title: "Add Doctor",
      description: "Register a new doctor",
      icon: <UserCheck className="h-5 w-5" />,
      action: () => onNavigate("doctors"),
      color: "bg-purple-500 hover:bg-purple-600",
    },
    {
      title: "Create Bill",
      description: "Generate patient bill",
      icon: <DollarSign className="h-5 w-5" />,
      action: () => onNavigate("billing"),
      color: "bg-orange-500 hover:bg-orange-600",
    },
  ]

  const monthlyProgress =
    stats.monthlyTarget > 0 ? Math.min((stats.monthlyRevenue / stats.monthlyTarget) * 100, 100) : 0

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400">Welcome back! Here's what's happening at your hospital.</p>
        </div>
        <div className="text-sm text-gray-500">
          {new Date().toLocaleDateString("en-US", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100">Total Patients</p>
                <p className="text-3xl font-bold">{stats.totalPatients}</p>
                <p className="text-xs text-blue-200 mt-1">
                  <TrendingUp className="w-3 h-3 inline mr-1" />
                  Active patients
                </p>
              </div>
              <Users className="h-8 w-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100">Total Doctors</p>
                <p className="text-3xl font-bold">{stats.totalDoctors}</p>
                <p className="text-xs text-green-200 mt-1">
                  <Activity className="w-3 h-3 inline mr-1" />
                  Available today
                </p>
              </div>
              <UserCheck className="h-8 w-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100">Today's Appointments</p>
                <p className="text-3xl font-bold">{stats.todayAppointments}</p>
                <p className="text-xs text-purple-200 mt-1">
                  <Calendar className="w-3 h-3 inline mr-1" />
                  Scheduled today
                </p>
              </div>
              <Calendar className="h-8 w-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100">Total Revenue</p>
                <p className="text-3xl font-bold">${stats.totalRevenue.toLocaleString()}</p>
                <p className="text-xs text-orange-200 mt-1">
                  <TrendingUp className="w-3 h-3 inline mr-1" />
                  {stats.paidBills} paid bills
                </p>
              </div>
              <DollarSign className="h-8 w-8 text-orange-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Revenue Progress and Billing Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Revenue Progress */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <DollarSign className="h-5 w-5 text-green-600" />
              <span>Monthly Revenue Target</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Progress</span>
                <span className="text-sm font-medium">{monthlyProgress.toFixed(1)}%</span>
              </div>
              <Progress value={monthlyProgress} className="h-3" />
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-2xl font-bold text-green-600">${stats.monthlyRevenue.toLocaleString()}</p>
                  <p className="text-sm text-gray-500">Current month</p>
                </div>
                <div className="text-right">
                  <p className="text-lg font-semibold text-gray-700">${stats.monthlyTarget.toLocaleString()}</p>
                  <p className="text-sm text-gray-500">Target</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Billing Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <FileText className="h-5 w-5 text-blue-600" />
              <span>Billing Summary</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-gray-600">Paid Bills</p>
                      <p className="text-xl font-bold text-green-600">{stats.paidBills}</p>
                    </div>
                  </div>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                    <div>
                      <p className="text-sm text-gray-600">Pending Bills</p>
                      <p className="text-xl font-bold text-yellow-600">{stats.pendingBills}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Bills */}
              <div>
                <h4 className="text-sm font-medium mb-2">Recent Bills</h4>
                <div className="space-y-2 max-h-32 overflow-y-auto">
                  {recentBills.length > 0 ? (
                    recentBills.map((bill: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div>
                          <p className="text-sm font-medium">{bill.patientName}</p>
                          <p className="text-xs text-gray-500">{bill.billNumber}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold">${Number.parseFloat(bill.total || 0).toFixed(2)}</p>
                          <Badge
                            variant="outline"
                            className={`text-xs ${
                              bill.status === "paid"
                                ? "bg-green-100 text-green-800"
                                : bill.status === "pending"
                                  ? "bg-yellow-100 text-yellow-800"
                                  : "bg-gray-100 text-gray-800"
                            }`}
                          >
                            {bill.status}
                          </Badge>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500 text-center py-2">No recent bills</p>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Activity className="h-5 w-5" />
            <span>Quick Actions</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                onClick={action.action}
                className={`${action.color} text-white p-6 h-auto flex flex-col items-center space-y-2 transition-all duration-200 transform hover:scale-105`}
              >
                {action.icon}
                <div className="text-center">
                  <div className="font-semibold">{action.title}</div>
                  <div className="text-xs opacity-90">{action.description}</div>
                </div>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity and Bed Status */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5" />
              <span>Recent Activity</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 max-h-80 overflow-y-auto">
              {recentActivity.length > 0 ? (
                recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                    <div className="flex-shrink-0">
                      {activity.type === "appointment" ? (
                        <Calendar className="h-5 w-5 text-blue-500" />
                      ) : activity.type === "payment" ? (
                        <DollarSign className="h-5 w-5 text-green-500" />
                      ) : (
                        <Users className="h-5 w-5 text-purple-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-gray-900">{activity.title}</p>
                      <p className="text-sm text-gray-600">{activity.description}</p>
                    </div>
                    <div className="flex flex-col items-end space-y-1">
                      <Badge variant="outline" className="text-xs">
                        {activity.status}
                      </Badge>
                      <span className="text-xs text-gray-500">{activity.time}</span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8">
                  <FileText className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No recent activity</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Bed Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Bed className="h-5 w-5" />
              <span>Bed Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-navy-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-navy-500 rounded-full"></div>
                  <span className="font-medium">Available Beds</span>
                </div>
                <span className="text-2xl font-bold text-green-600">{stats.availableBeds}</span>
              </div>
              <div className="flex items-center justify-between p-4 bg-black-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                  <span className="font-medium">Occupied Beds</span>
                </div>
                <span className="text-2xl font-bold text-black-600">{stats.occupiedBeds}</span>
              </div>
              <div className="pt-4">
                <div className="flex justify-between text-sm text-navy-600 mb-2">
                  <span>Occupancy Rate</span>
                  <span>
                    {stats.availableBeds + stats.occupiedBeds > 0
                      ? Math.round((stats.occupiedBeds / (stats.availableBeds + stats.occupiedBeds)) * 100)
                      : 0}
                    %
                  </span>
                </div>
                <div className="w-full bg-navy-200 rounded-full h-2">
                  <div
                    className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                    style={{
                      width: `${
                        stats.availableBeds + stats.occupiedBeds > 0
                          ? (stats.occupiedBeds / (stats.availableBeds + stats.occupiedBeds)) * 100
                          : 0
                      }%`,
                    }}
                  ></div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
