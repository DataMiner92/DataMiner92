"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "sonner"
import {
  Package,
  Plus,
  Search,
  Edit,
  Trash2,
  Eye,
  Truck,
  Stethoscope,
  Bed,
  Zap,
  Wrench,
  CheckCircle,
  Clock,
  DollarSign,
  Calendar,
  Download,
} from "lucide-react"

interface Asset {
  id: string
  name: string
  category: string
  model: string
  serialNumber: string
  manufacturer: string
  purchaseDate: Date
  purchasePrice: number
  currentValue: number
  location: string
  department: string
  status: "operational" | "maintenance" | "out-of-service" | "retired"
  condition: "excellent" | "good" | "fair" | "poor"
  warrantyExpiry?: Date
  lastMaintenance?: Date
  nextMaintenance?: Date
  description: string
  notes: string
}

interface AssetManagementProps {
  userRole: string
}

export function AssetManagement({ userRole }: AssetManagementProps) {
  const [assets, setAssets] = useState<Asset[]>([])
  const [searchQuery, setSearchQuery] = useState("")
  const [filterCategory, setFilterCategory] = useState("")
  const [filterStatus, setFilterStatus] = useState("")
  const [filterDepartment, setFilterDepartment] = useState("")
  const [isAddAssetOpen, setIsAddAssetOpen] = useState(false)
  const [selectedAsset, setSelectedAsset] = useState<Asset | null>(null)
  const [isEditOpen, setIsEditOpen] = useState(false)
  const [isViewOpen, setIsViewOpen] = useState(false)

  const [assetForm, setAssetForm] = useState({
    name: "",
    category: "Other",
    model: "",
    serialNumber: "",
    manufacturer: "",
    purchaseDate: "",
    purchasePrice: "",
    currentValue: "",
    location: "",
    department: "",
    status: "operational" as const,
    condition: "excellent" as const,
    warrantyExpiry: "",
    lastMaintenance: "",
    nextMaintenance: "",
    description: "",
    notes: "",
  })

  useEffect(() => {
    // Load assets from localStorage
    const savedAssets = localStorage.getItem("hms-assets")
    if (savedAssets) {
      const parsedAssets = JSON.parse(savedAssets).map((asset: any) => ({
        ...asset,
        purchaseDate: new Date(asset.purchaseDate),
        warrantyExpiry: asset.warrantyExpiry ? new Date(asset.warrantyExpiry) : undefined,
        lastMaintenance: asset.lastMaintenance ? new Date(asset.lastMaintenance) : undefined,
        nextMaintenance: asset.nextMaintenance ? new Date(asset.nextMaintenance) : undefined,
      }))
      setAssets(parsedAssets)
    } else {
      // Sample assets
      const sampleAssets: Asset[] = [
        {
          id: "1",
          name: "Ambulance Unit 1",
          category: "Vehicle",
          model: "Ford Transit 350",
          serialNumber: "AMB001",
          manufacturer: "Ford",
          purchaseDate: new Date("2022-03-15"),
          purchasePrice: 85000,
          currentValue: 75000,
          location: "Main Parking",
          department: "Emergency",
          status: "operational",
          condition: "good",
          warrantyExpiry: new Date("2025-03-15"),
          lastMaintenance: new Date("2024-01-15"),
          nextMaintenance: new Date("2024-07-15"),
          description: "Emergency response ambulance with advanced life support equipment",
          notes: "Regular maintenance scheduled every 6 months",
        },
        {
          id: "2",
          name: "MRI Scanner",
          category: "Medical Equipment",
          model: "Siemens MAGNETOM",
          serialNumber: "MRI001",
          manufacturer: "Siemens",
          purchaseDate: new Date("2021-08-20"),
          purchasePrice: 2500000,
          currentValue: 2200000,
          location: "Radiology Department",
          department: "Radiology",
          status: "operational",
          condition: "excellent",
          warrantyExpiry: new Date("2026-08-20"),
          lastMaintenance: new Date("2024-01-10"),
          nextMaintenance: new Date("2024-04-10"),
          description: "High-field MRI scanner for detailed imaging",
          notes: "Requires specialized technician for maintenance",
        },
        {
          id: "3",
          name: "Patient Monitor Set A",
          category: "Medical Equipment",
          model: "Philips IntelliVue",
          serialNumber: "PM001",
          manufacturer: "Philips",
          purchaseDate: new Date("2023-01-10"),
          purchasePrice: 15000,
          currentValue: 13500,
          location: "ICU Room 101",
          department: "ICU",
          status: "maintenance",
          condition: "good",
          warrantyExpiry: new Date("2026-01-10"),
          lastMaintenance: new Date("2024-01-05"),
          nextMaintenance: new Date("2024-04-05"),
          description: "Multi-parameter patient monitoring system",
          notes: "Currently undergoing routine calibration",
        },
        {
          id: "4",
          name: "Hospital Bed - Electric",
          category: "Furniture",
          model: "Hill-Rom P1900",
          serialNumber: "BED001",
          manufacturer: "Hill-Rom",
          purchaseDate: new Date("2022-11-05"),
          purchasePrice: 8500,
          currentValue: 7500,
          location: "Generator Room",
          department: "Facilities",
          status: "operational",
          condition: "excellent",
          warrantyExpiry: new Date("2025-11-05"),
          description: "Electric hospital bed with side rails and positioning controls",
          notes: "Recently serviced and cleaned",
        },
        {
          id: "5",
          name: "Backup Generator",
          category: "Infrastructure",
          model: "Caterpillar C32",
          serialNumber: "GEN001",
          manufacturer: "Caterpillar",
          purchaseDate: new Date("2020-06-12"),
          purchasePrice: 125000,
          currentValue: 95000,
          location: "Generator Room",
          department: "Facilities",
          status: "operational",
          condition: "good",
          lastMaintenance: new Date("2024-01-20"),
          nextMaintenance: new Date("2024-07-20"),
          description: "Emergency backup power generator for hospital operations",
          notes: "Monthly testing required, fuel level monitored daily",
        },
      ]
      setAssets(sampleAssets)
      localStorage.setItem("hms-assets", JSON.stringify(sampleAssets))
    }
  }, [])

  const handleAddAsset = () => {
    if (!assetForm.name || !assetForm.category || !assetForm.purchasePrice) {
      toast.error("Please fill in all required fields")
      return
    }

    const asset: Asset = {
      id: Date.now().toString(),
      ...assetForm,
      purchaseDate: new Date(assetForm.purchaseDate),
      purchasePrice: Number.parseFloat(assetForm.purchasePrice),
      currentValue: Number.parseFloat(assetForm.currentValue || assetForm.purchasePrice),
      warrantyExpiry: assetForm.warrantyExpiry ? new Date(assetForm.warrantyExpiry) : undefined,
      lastMaintenance: assetForm.lastMaintenance ? new Date(assetForm.lastMaintenance) : undefined,
      nextMaintenance: assetForm.nextMaintenance ? new Date(assetForm.nextMaintenance) : undefined,
    }

    const updatedAssets = [...assets, asset]
    setAssets(updatedAssets)
    localStorage.setItem("hms-assets", JSON.stringify(updatedAssets))

    resetForm()
    setIsAddAssetOpen(false)
    toast.success("Asset added successfully!")
  }

  const handleEditAsset = () => {
    if (!selectedAsset || !assetForm.name || !assetForm.category) {
      toast.error("Please fill in all required fields")
      return
    }

    const updatedAsset: Asset = {
      ...selectedAsset,
      ...assetForm,
      purchaseDate: new Date(assetForm.purchaseDate),
      purchasePrice: Number.parseFloat(assetForm.purchasePrice),
      currentValue: Number.parseFloat(assetForm.currentValue || assetForm.purchasePrice),
      warrantyExpiry: assetForm.warrantyExpiry ? new Date(assetForm.warrantyExpiry) : undefined,
      lastMaintenance: assetForm.lastMaintenance ? new Date(assetForm.lastMaintenance) : undefined,
      nextMaintenance: assetForm.nextMaintenance ? new Date(assetForm.nextMaintenance) : undefined,
    }

    const updatedAssets = assets.map((asset) => (asset.id === selectedAsset.id ? updatedAsset : asset))
    setAssets(updatedAssets)
    localStorage.setItem("hms-assets", JSON.stringify(updatedAssets))

    resetForm()
    setIsEditOpen(false)
    setSelectedAsset(null)
    toast.success("Asset updated successfully!")
  }

  const handleDeleteAsset = (assetId: string) => {
    const updatedAssets = assets.filter((asset) => asset.id !== assetId)
    setAssets(updatedAssets)
    localStorage.setItem("hms-assets", JSON.stringify(updatedAssets))
    toast.success("Asset deleted successfully!")
  }

  const resetForm = () => {
    setAssetForm({
      name: "",
      category: "Other",
      model: "",
      serialNumber: "",
      manufacturer: "",
      purchaseDate: "",
      purchasePrice: "",
      currentValue: "",
      location: "",
      department: "",
      status: "operational",
      condition: "excellent",
      warrantyExpiry: "",
      lastMaintenance: "",
      nextMaintenance: "",
      description: "",
      notes: "",
    })
  }

  const openEditDialog = (asset: Asset) => {
    setSelectedAsset(asset)
    setAssetForm({
      name: asset.name,
      category: asset.category,
      model: asset.model,
      serialNumber: asset.serialNumber,
      manufacturer: asset.manufacturer,
      purchaseDate: asset.purchaseDate.toISOString().split("T")[0],
      purchasePrice: asset.purchasePrice.toString(),
      currentValue: asset.currentValue.toString(),
      location: asset.location,
      department: asset.department,
      status: asset.status,
      condition: asset.condition,
      warrantyExpiry: asset.warrantyExpiry?.toISOString().split("T")[0] || "",
      lastMaintenance: asset.lastMaintenance?.toISOString().split("T")[0] || "",
      nextMaintenance: asset.nextMaintenance?.toISOString().split("T")[0] || "",
      description: asset.description,
      notes: asset.notes,
    })
    setIsEditOpen(true)
  }

  const filteredAssets = assets.filter((asset) => {
    const matchesSearch =
      asset.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.serialNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      asset.manufacturer.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = !filterCategory || asset.category === filterCategory
    const matchesStatus = !filterStatus || asset.status === filterStatus
    const matchesDepartment = !filterDepartment || asset.department === filterDepartment
    return matchesSearch && matchesCategory && matchesStatus && matchesDepartment
  })

  const categories = [...new Set(assets.map((asset) => asset.category))]
  const departments = [...new Set(assets.map((asset) => asset.department))]
  const statuses = ["operational", "maintenance", "out-of-service", "retired"]

  const getStatusColor = (status: string) => {
    switch (status) {
      case "operational":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "maintenance":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "out-of-service":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      case "retired":
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "excellent":
        return "bg-green-100 text-green-800 dark:bg-green-900/20 dark:text-green-300"
      case "good":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900/20 dark:text-blue-300"
      case "fair":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/20 dark:text-yellow-300"
      case "poor":
        return "bg-red-100 text-red-800 dark:bg-red-900/20 dark:text-red-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/20 dark:text-gray-300"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category.toLowerCase()) {
      case "vehicle":
        return <Truck className="h-4 w-4" />
      case "medical equipment":
        return <Stethoscope className="h-4 w-4" />
      case "furniture":
        return <Bed className="h-4 w-4" />
      case "infrastructure":
        return <Zap className="h-4 w-4" />
      default:
        return <Package className="h-4 w-4" />
    }
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
    }).format(amount)
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  const totalAssetValue = assets.reduce((sum, asset) => sum + asset.currentValue, 0)
  const operationalAssets = assets.filter((asset) => asset.status === "operational").length
  const maintenanceAssets = assets.filter((asset) => asset.status === "maintenance").length

  // Check permissions
  const canEdit = userRole === "admin"
  const canDelete = userRole === "admin"
  const canAdd = userRole === "admin"

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Asset Management</h2>
          <p className="text-gray-600 dark:text-gray-400">Track and manage hospital assets, equipment, and inventory</p>
        </div>
        {canAdd && (
          <Dialog open={isAddAssetOpen} onOpenChange={setIsAddAssetOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>Add Asset</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Asset</DialogTitle>
                <DialogDescription>Enter the details of the new asset to add to the inventory</DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Asset Name *</Label>
                  <Input
                    id="name"
                    value={assetForm.name}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., MRI Scanner"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="category">Category *</Label>
                  <Select
                    value={assetForm.category}
                    onValueChange={(value) => setAssetForm((prev) => ({ ...prev, category: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Medical Equipment">Medical Equipment</SelectItem>
                      <SelectItem value="Vehicle">Vehicle</SelectItem>
                      <SelectItem value="Furniture">Furniture</SelectItem>
                      <SelectItem value="Infrastructure">Infrastructure</SelectItem>
                      <SelectItem value="IT Equipment">IT Equipment</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="model">Model</Label>
                  <Input
                    id="model"
                    value={assetForm.model}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, model: e.target.value }))}
                    placeholder="e.g., Siemens MAGNETOM"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="serialNumber">Serial Number</Label>
                  <Input
                    id="serialNumber"
                    value={assetForm.serialNumber}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, serialNumber: e.target.value }))}
                    placeholder="e.g., MRI001"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="manufacturer">Manufacturer</Label>
                  <Input
                    id="manufacturer"
                    value={assetForm.manufacturer}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, manufacturer: e.target.value }))}
                    placeholder="e.g., Siemens"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="purchaseDate">Purchase Date</Label>
                  <Input
                    id="purchaseDate"
                    type="date"
                    value={assetForm.purchaseDate}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, purchaseDate: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="purchasePrice">Purchase Price *</Label>
                  <Input
                    id="purchasePrice"
                    type="number"
                    value={assetForm.purchasePrice}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, purchasePrice: e.target.value }))}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="currentValue">Current Value</Label>
                  <Input
                    id="currentValue"
                    type="number"
                    value={assetForm.currentValue}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, currentValue: e.target.value }))}
                    placeholder="0.00"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={assetForm.location}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, location: e.target.value }))}
                    placeholder="e.g., Radiology Department"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    value={assetForm.department}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, department: e.target.value }))}
                    placeholder="e.g., Radiology"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select
                    value={assetForm.status}
                    onValueChange={(value: any) => setAssetForm((prev) => ({ ...prev, status: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="operational">Operational</SelectItem>
                      <SelectItem value="maintenance">Maintenance</SelectItem>
                      <SelectItem value="out-of-service">Out of Service</SelectItem>
                      <SelectItem value="retired">Retired</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="condition">Condition</Label>
                  <Select
                    value={assetForm.condition}
                    onValueChange={(value: any) => setAssetForm((prev) => ({ ...prev, condition: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="excellent">Excellent</SelectItem>
                      <SelectItem value="good">Good</SelectItem>
                      <SelectItem value="fair">Fair</SelectItem>
                      <SelectItem value="poor">Poor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="warrantyExpiry">Warranty Expiry</Label>
                  <Input
                    id="warrantyExpiry"
                    type="date"
                    value={assetForm.warrantyExpiry}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, warrantyExpiry: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastMaintenance">Last Maintenance</Label>
                  <Input
                    id="lastMaintenance"
                    type="date"
                    value={assetForm.lastMaintenance}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, lastMaintenance: e.target.value }))}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="nextMaintenance">Next Maintenance</Label>
                  <Input
                    id="nextMaintenance"
                    type="date"
                    value={assetForm.nextMaintenance}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, nextMaintenance: e.target.value }))}
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={assetForm.description}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description of the asset..."
                    rows={3}
                  />
                </div>
                <div className="space-y-2 col-span-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={assetForm.notes}
                    onChange={(e) => setAssetForm((prev) => ({ ...prev, notes: e.target.value }))}
                    placeholder="Additional notes or maintenance instructions..."
                    rows={3}
                  />
                </div>
              </div>
              <div className="flex justify-end space-x-2 mt-6">
                <Button variant="outline" onClick={() => setIsAddAssetOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleAddAsset}>Add Asset</Button>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Assets</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{assets.length}</p>
              </div>
              <div className="h-12 w-12 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center">
                <Package className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Value</p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatCurrency(totalAssetValue)}</p>
              </div>
              <div className="h-12 w-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Operational</p>
                <p className="text-2xl font-bold text-green-600 dark:text-green-400">{operationalAssets}</p>
              </div>
              <div className="h-12 w-12 bg-green-100 dark:bg-green-900/20 rounded-full flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-400">In Maintenance</p>
                <p className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">{maintenanceAssets}</p>
              </div>
              <div className="h-12 w-12 bg-yellow-100 dark:bg-yellow-900/20 rounded-full flex items-center justify-center">
                <Wrench className="h-6 w-6 text-yellow-600 dark:text-yellow-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search assets by name, serial number, or manufacturer..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2">
              {/* Category filter */}
              <Select
                value={filterCategory || "all"}
                onValueChange={(value) => setFilterCategory(value === "all" ? "" : value)}
              >
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Status filter */}
              <Select
                value={filterStatus || "all"}
                onValueChange={(value) => setFilterStatus(value === "all" ? "" : value)}
              >
                <SelectTrigger className="w-40">
                  <SelectValue placeholder="All Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  {statuses.map((status) => (
                    <SelectItem key={status} value={status} className="capitalize">
                      {status.replace("-", " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Department filter */}
              <Select
                value={filterDepartment || "all"}
                onValueChange={(value) => setFilterDepartment(value === "all" ? "" : value)}
              >
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Departments" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Departments</SelectItem>
                  {departments.map((dept) => (
                    <SelectItem key={dept} value={dept}>
                      {dept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Button variant="outline" size="sm">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Assets Table */}
      <Card>
        <CardHeader>
          <CardTitle>Assets ({filteredAssets.length})</CardTitle>
          <CardDescription>Manage your hospital assets and equipment inventory</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Asset</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Condition</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Next Maintenance</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredAssets.map((asset) => (
                  <TableRow key={asset.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        <div className="h-10 w-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                          {getCategoryIcon(asset.category)}
                        </div>
                        <div>
                          <div className="font-medium text-gray-900 dark:text-white">{asset.name}</div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">{asset.serialNumber}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{asset.category}</Badge>
                    </TableCell>
                    <TableCell>
                      <div>
                        <div className="text-sm font-medium text-gray-900 dark:text-white">{asset.location}</div>
                        <div className="text-sm text-gray-500 dark:text-gray-400">{asset.department}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge className={getStatusColor(asset.status)}>{asset.status.replace("-", " ")}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={getConditionColor(asset.condition)}>{asset.condition}</Badge>
                    </TableCell>
                    <TableCell className="font-medium">{formatCurrency(asset.currentValue)}</TableCell>
                    <TableCell>
                      {asset.nextMaintenance ? (
                        <div className="flex items-center space-x-1">
                          <Calendar className="h-4 w-4 text-gray-400" />
                          <span className="text-sm">{formatDate(asset.nextMaintenance)}</span>
                        </div>
                      ) : (
                        <span className="text-gray-400">Not scheduled</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedAsset(asset)
                            setIsViewOpen(true)
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                        {canEdit && (
                          <Button variant="ghost" size="sm" onClick={() => openEditDialog(asset)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                        {canDelete && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDeleteAsset(asset.id)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Edit Asset Dialog */}
      <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Asset</DialogTitle>
            <DialogDescription>Update the asset information</DialogDescription>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-name">Asset Name *</Label>
              <Input
                id="edit-name"
                value={assetForm.name}
                onChange={(e) => setAssetForm((prev) => ({ ...prev, name: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-category">Category *</Label>
              <Select
                value={assetForm.category}
                onValueChange={(value) => setAssetForm((prev) => ({ ...prev, category: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Medical Equipment">Medical Equipment</SelectItem>
                  <SelectItem value="Vehicle">Vehicle</SelectItem>
                  <SelectItem value="Furniture">Furniture</SelectItem>
                  <SelectItem value="Infrastructure">Infrastructure</SelectItem>
                  <SelectItem value="IT Equipment">IT Equipment</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-status">Status</Label>
              <Select
                value={assetForm.status}
                onValueChange={(value: any) => setAssetForm((prev) => ({ ...prev, status: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="operational">Operational</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="out-of-service">Out of Service</SelectItem>
                  <SelectItem value="retired">Retired</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-condition">Condition</Label>
              <Select
                value={assetForm.condition}
                onValueChange={(value: any) => setAssetForm((prev) => ({ ...prev, condition: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="excellent">Excellent</SelectItem>
                  <SelectItem value="good">Good</SelectItem>
                  <SelectItem value="fair">Fair</SelectItem>
                  <SelectItem value="poor">Poor</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-currentValue">Current Value</Label>
              <Input
                id="edit-currentValue"
                type="number"
                value={assetForm.currentValue}
                onChange={(e) => setAssetForm((prev) => ({ ...prev, currentValue: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-location">Location</Label>
              <Input
                id="edit-location"
                value={assetForm.location}
                onChange={(e) => setAssetForm((prev) => ({ ...prev, location: e.target.value }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-nextMaintenance">Next Maintenance</Label>
              <Input
                id="edit-nextMaintenance"
                type="date"
                value={assetForm.nextMaintenance}
                onChange={(e) => setAssetForm((prev) => ({ ...prev, nextMaintenance: e.target.value }))}
              />
            </div>
            <div className="space-y-2 col-span-2">
              <Label htmlFor="edit-notes">Notes</Label>
              <Textarea
                id="edit-notes"
                value={assetForm.notes}
                onChange={(e) => setAssetForm((prev) => ({ ...prev, notes: e.target.value }))}
                rows={3}
              />
            </div>
          </div>
          <div className="flex justify-end space-x-2 mt-6">
            <Button variant="outline" onClick={() => setIsEditOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditAsset}>Update Asset</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* View Asset Dialog */}
      <Dialog open={isViewOpen} onOpenChange={setIsViewOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center space-x-3">
              <div className="h-10 w-10 bg-gray-100 dark:bg-gray-800 rounded-lg flex items-center justify-center">
                {selectedAsset && getCategoryIcon(selectedAsset.category)}
              </div>
              <span>{selectedAsset?.name}</span>
            </DialogTitle>
            <DialogDescription>Asset details and information</DialogDescription>
          </DialogHeader>
          {selectedAsset && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Category</Label>
                  <p className="text-gray-900 dark:text-white">{selectedAsset.category}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Serial Number</Label>
                  <p className="text-gray-900 dark:text-white">{selectedAsset.serialNumber || "N/A"}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Manufacturer</Label>
                  <p className="text-gray-900 dark:text-white">{selectedAsset.manufacturer || "N/A"}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Model</Label>
                  <p className="text-gray-900 dark:text-white">{selectedAsset.model || "N/A"}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Location</Label>
                  <p className="text-gray-900 dark:text-white">{selectedAsset.location}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Department</Label>
                  <p className="text-gray-900 dark:text-white">{selectedAsset.department}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Status</Label>
                  <Badge className={getStatusColor(selectedAsset.status)}>
                    {selectedAsset.status.replace("-", " ")}
                  </Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Condition</Label>
                  <Badge className={getConditionColor(selectedAsset.condition)}>{selectedAsset.condition}</Badge>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Purchase Date</Label>
                  <p className="text-gray-900 dark:text-white">{formatDate(selectedAsset.purchaseDate)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Purchase Price</Label>
                  <p className="text-gray-900 dark:text-white">{formatCurrency(selectedAsset.purchasePrice)}</p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Current Value</Label>
                  <p className="text-gray-900 dark:text-white font-semibold">
                    {formatCurrency(selectedAsset.currentValue)}
                  </p>
                </div>
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Warranty Expiry</Label>
                  <p className="text-gray-900 dark:text-white">
                    {selectedAsset.warrantyExpiry ? formatDate(selectedAsset.warrantyExpiry) : "N/A"}
                  </p>
                </div>
              </div>

              {selectedAsset.description && (
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Description</Label>
                  <p className="text-gray-900 dark:text-white mt-1">{selectedAsset.description}</p>
                </div>
              )}

              {(selectedAsset.lastMaintenance || selectedAsset.nextMaintenance) && (
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Maintenance Schedule</Label>
                  <div className="mt-2 space-y-2">
                    {selectedAsset.lastMaintenance && (
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="h-4 w-4 text-green-600" />
                        <span className="text-sm">Last maintenance: {formatDate(selectedAsset.lastMaintenance)}</span>
                      </div>
                    )}
                    {selectedAsset.nextMaintenance && (
                      <div className="flex items-center space-x-2">
                        <Clock className="h-4 w-4 text-blue-600" />
                        <span className="text-sm">Next maintenance: {formatDate(selectedAsset.nextMaintenance)}</span>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {selectedAsset.notes && (
                <div>
                  <Label className="text-sm font-medium text-gray-500 dark:text-gray-400">Notes</Label>
                  <p className="text-gray-900 dark:text-white mt-1">{selectedAsset.notes}</p>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
