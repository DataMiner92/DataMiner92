"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Building, Users, Activity, Plus, Edit, Trash2, UserCheck } from "lucide-react"
import { toast } from "sonner"

interface DepartmentManagementProps {
  userRole: string
}

interface Department {
  id: string
  name: string
  description: string
  headOfDepartment: string
  location: string
  budget: number
  staffCount: number
  status: "active" | "inactive"
  contactNumber: string
  email: string
  services: string[]
  createdAt: string
}

export function DepartmentManagement({ userRole }: DepartmentManagementProps) {
  const [departments, setDepartments] = useState<Department[]>([])
  const [doctors, setDoctors] = useState<any[]>([])
  const [isAddDepartmentOpen, setIsAddDepartmentOpen] = useState(false)
  const [editingDepartment, setEditingDepartment] = useState<Department | null>(null)

  // Load data from localStorage
  useEffect(() => {
    const savedDepartments = localStorage.getItem("hms-departments")
    const savedDoctors = localStorage.getItem("hms-doctors")

    if (savedDepartments) {
      setDepartments(JSON.parse(savedDepartments))
    } else {
      // Initialize with default departments
      const defaultDepartments: Department[] = [
        {
          id: "1",
          name: "Emergency Medicine",
          description: "24/7 emergency medical care",
          headOfDepartment: "Dr. Sarah Johnson",
          location: "Ground Floor, Wing A",
          budget: 500000,
          staffCount: 25,
          status: "active",
          contactNumber: "+1-555-0101",
          email: "emergency@hospital.com",
          services: ["Emergency Care", "Trauma", "Critical Care"],
          createdAt: new Date().toISOString(),
        },
        {
          id: "2",
          name: "Cardiology",
          description: "Heart and cardiovascular care",
          headOfDepartment: "Dr. Michael Brown",
          location: "2nd Floor, Wing B",
          budget: 750000,
          staffCount: 18,
          status: "active",
          contactNumber: "+1-555-0102",
          email: "cardiology@hospital.com",
          services: ["Heart Surgery", "Cardiac Catheterization", "Echocardiography"],
          createdAt: new Date().toISOString(),
        },
        {
          id: "3",
          name: "Pediatrics",
          description: "Medical care for children",
          headOfDepartment: "Dr. Emily Davis",
          location: "3rd Floor, Wing C",
          budget: 400000,
          staffCount: 22,
          status: "active",
          contactNumber: "+1-555-0103",
          email: "pediatrics@hospital.com",
          services: ["Child Care", "Vaccination", "Pediatric Surgery"],
          createdAt: new Date().toISOString(),
        },
        {
          id: "4",
          name: "Radiology",
          description: "Medical imaging and diagnostics",
          headOfDepartment: "Dr. Robert Taylor",
          location: "Basement, Wing A",
          budget: 600000,
          staffCount: 12,
          status: "active",
          contactNumber: "+1-555-0104",
          email: "radiology@hospital.com",
          services: ["X-Ray", "MRI", "CT Scan", "Ultrasound"],
          createdAt: new Date().toISOString(),
        },
      ]
      setDepartments(defaultDepartments)
      localStorage.setItem("hms-departments", JSON.stringify(defaultDepartments))
    }

    if (savedDoctors) setDoctors(JSON.parse(savedDoctors))
  }, [])

  // Save departments to localStorage
  useEffect(() => {
    localStorage.setItem("hms-departments", JSON.stringify(departments))
  }, [departments])

  const addDepartment = (departmentData: Omit<Department, "id" | "createdAt">) => {
    const newDepartment: Department = {
      ...departmentData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }
    setDepartments((prev) => [...prev, newDepartment])
    toast.success("Department added successfully!")
  }

  const updateDepartment = (updatedDepartment: Department) => {
    setDepartments((prev) => prev.map((d) => (d.id === updatedDepartment.id ? updatedDepartment : d)))
    toast.success("Department updated successfully!")
  }

  const deleteDepartment = (id: string) => {
    if (confirm("Are you sure you want to delete this department?")) {
      setDepartments((prev) => prev.filter((d) => d.id !== id))
      toast.success("Department deleted successfully!")
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "inactive":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const stats = {
    totalDepartments: departments.length,
    activeDepartments: departments.filter((d) => d.status === "active").length,
    totalStaff: departments.reduce((sum, dept) => sum + dept.staffCount, 0),
    totalBudget: departments.reduce((sum, dept) => sum + dept.budget, 0),
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Department Management</h2>
          <p className="text-gray-600 dark:text-gray-400">Manage hospital departments and staff</p>
        </div>
        {userRole === "Admin" && (
          <Dialog open={isAddDepartmentOpen} onOpenChange={setIsAddDepartmentOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>Add Department</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Department</DialogTitle>
                <DialogDescription>Create a new hospital department</DialogDescription>
              </DialogHeader>
              <DepartmentForm
                doctors={doctors}
                onSubmit={addDepartment}
                onClose={() => setIsAddDepartmentOpen(false)}
              />
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Building className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalDepartments}</p>
                <p className="text-sm text-gray-600">Total Departments</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <Activity className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.activeDepartments}</p>
                <p className="text-sm text-gray-600">Active Departments</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalStaff}</p>
                <p className="text-sm text-gray-600">Total Staff</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <Building className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">${(stats.totalBudget / 1000000).toFixed(1)}M</p>
                <p className="text-sm text-gray-600">Total Budget</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Departments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {departments.map((department) => (
          <Card key={department.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <Building className="h-5 w-5 text-blue-600" />
                    <span>{department.name}</span>
                  </CardTitle>
                  <CardDescription>{department.description}</CardDescription>
                </div>
                <Badge className={getStatusColor(department.status)}>{department.status}</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <UserCheck className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Head of Department</span>
                  </div>
                  <span className="font-medium text-sm">{department.headOfDepartment}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Staff Count</span>
                  </div>
                  <span className="font-medium">{department.staffCount}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Building className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-600">Location</span>
                  </div>
                  <span className="font-medium text-sm">{department.location}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Budget</span>
                  <span className="font-medium">${department.budget.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Contact</span>
                  <span className="font-medium text-sm">{department.contactNumber}</span>
                </div>
              </div>

              <div className="mt-4">
                <Label className="text-sm font-medium text-gray-600">Services</Label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {department.services.map((service, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {service}
                    </Badge>
                  ))}
                </div>
              </div>

              {userRole === "Admin" && (
                <div className="flex space-x-2 mt-4">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setEditingDepartment(department)
                      setIsAddDepartmentOpen(true)
                    }}
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600"
                    onClick={() => deleteDepartment(department.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Department Dialog */}
      <Dialog
        open={isAddDepartmentOpen && !!editingDepartment}
        onOpenChange={() => {
          setIsAddDepartmentOpen(false)
          setEditingDepartment(null)
        }}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Department</DialogTitle>
            <DialogDescription>Update department information</DialogDescription>
          </DialogHeader>
          {editingDepartment && (
            <DepartmentForm
              department={editingDepartment}
              doctors={doctors}
              onSubmit={updateDepartment}
              onClose={() => {
                setIsAddDepartmentOpen(false)
                setEditingDepartment(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function DepartmentForm({
  department,
  doctors,
  onSubmit,
  onClose,
}: {
  department?: Department
  doctors: any[]
  onSubmit: (data: any) => void
  onClose: () => void
}) {
  const [formData, setFormData] = useState({
    name: department?.name || "",
    description: department?.description || "",
    headOfDepartment: department?.headOfDepartment || "",
    location: department?.location || "",
    budget: department?.budget || 0,
    staffCount: department?.staffCount || 0,
    status: department?.status || ("active" as const),
    contactNumber: department?.contactNumber || "",
    email: department?.email || "",
    services: department?.services || [],
  })

  const [newService, setNewService] = useState("")

  const commonServices = [
    "Emergency Care",
    "Surgery",
    "Consultation",
    "Diagnostics",
    "Therapy",
    "Rehabilitation",
    "Preventive Care",
    "Critical Care",
    "Outpatient Services",
    "Inpatient Services",
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (department) {
      onSubmit({ ...department, ...formData })
    } else {
      onSubmit(formData)
    }
    onClose()
  }

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const addService = () => {
    if (newService.trim() && !formData.services.includes(newService.trim())) {
      setFormData((prev) => ({
        ...prev,
        services: [...prev.services, newService.trim()],
      }))
      setNewService("")
    }
  }

  const removeService = (service: string) => {
    setFormData((prev) => ({
      ...prev,
      services: prev.services.filter((s) => s !== service),
    }))
  }

  const addCommonService = (service: string) => {
    if (!formData.services.includes(service)) {
      setFormData((prev) => ({
        ...prev,
        services: [...prev.services, service],
      }))
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Department Name *</Label>
          <Input id="name" value={formData.name} onChange={(e) => handleChange("name", e.target.value)} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="status">Status *</Label>
          <Select value={formData.status} onValueChange={(value) => handleChange("status", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => handleChange("description", e.target.value)}
          required
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="headOfDepartment">Head of Department *</Label>
          <Input
            id="headOfDepartment"
            value={formData.headOfDepartment}
            onChange={(e) => handleChange("headOfDepartment", e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="location">Location *</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => handleChange("location", e.target.value)}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="staffCount">Staff Count *</Label>
          <Input
            id="staffCount"
            type="number"
            min="0"
            value={formData.staffCount}
            onChange={(e) => handleChange("staffCount", Number.parseInt(e.target.value))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="budget">Budget ($) *</Label>
          <Input
            id="budget"
            type="number"
            min="0"
            value={formData.budget}
            onChange={(e) => handleChange("budget", Number.parseInt(e.target.value))}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="contactNumber">Contact Number *</Label>
          <Input
            id="contactNumber"
            type="tel"
            value={formData.contactNumber}
            onChange={(e) => handleChange("contactNumber", e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email *</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => handleChange("email", e.target.value)}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Services</Label>
        <div className="flex space-x-2">
          <Input
            placeholder="Add new service"
            value={newService}
            onChange={(e) => setNewService(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addService())}
          />
          <Button type="button" onClick={addService}>
            Add
          </Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {commonServices.map((service) => (
            <Button
              key={service}
              type="button"
              variant="outline"
              size="sm"
              onClick={() => addCommonService(service)}
              disabled={formData.services.includes(service)}
            >
              {service}
            </Button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {formData.services.map((service) => (
            <Badge key={service} variant="secondary" className="cursor-pointer" onClick={() => removeService(service)}>
              {service} ×
            </Badge>
          ))}
        </div>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">{department ? "Update Department" : "Add Department"}</Button>
      </div>
    </form>
  )
}
