"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { TestTube, FileText, CheckCircle, AlertTriangle, Plus, Eye } from "lucide-react"
import { toast } from "sonner"

interface LaboratoryManagementProps {
  userRole: string
}

interface LabTest {
  id: string
  patientId: string
  patientName: string
  testType: string
  description: string
  status: "pending" | "in-progress" | "completed" | "cancelled"
  result?: string
  notes?: string
  orderedBy: string
  createdAt: string
  completedAt?: string
}

export function LaboratoryManagement({ userRole }: LaboratoryManagementProps) {
  const [labTests, setLabTests] = useState<LabTest[]>([])
  const [patients, setPatients] = useState<any[]>([])
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [selectedTest, setSelectedTest] = useState<LabTest | null>(null)

  // Load data from localStorage on component mount
  useEffect(() => {
    const savedLabTests = localStorage.getItem("hms-lab-tests")
    const savedPatients = localStorage.getItem("hms-patients")

    if (savedLabTests) setLabTests(JSON.parse(savedLabTests))
    if (savedPatients) setPatients(JSON.parse(savedPatients))
  }, [])

  // Save lab tests to localStorage whenever array changes
  useEffect(() => {
    localStorage.setItem("hms-lab-tests", JSON.stringify(labTests))
  }, [labTests])

  const addLabTest = (testData: Omit<LabTest, "id" | "createdAt">) => {
    const newTest: LabTest = {
      ...testData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }
    setLabTests((prev) => [...prev, newTest])
    toast.success("Lab test ordered successfully!")
  }

  const updateTestStatus = (id: string, status: LabTest["status"], result?: string) => {
    setLabTests((prev) =>
      prev.map((test) =>
        test.id === id
          ? {
              ...test,
              status,
              result: result || test.result,
              completedAt: status === "completed" ? new Date().toISOString() : test.completedAt,
            }
          : test,
      ),
    )
    toast.success(`Test ${status} successfully!`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "in-progress":
        return "bg-blue-100 text-blue-800"
      case "completed":
        return "bg-green-100 text-green-800"
      case "cancelled":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const stats = {
    pending: labTests.filter((test) => test.status === "pending").length,
    inProgress: labTests.filter((test) => test.status === "in-progress").length,
    completed: labTests.filter((test) => test.status === "completed").length,
    total: labTests.length,
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Laboratory Management</h2>
          <p className="text-gray-600 dark:text-gray-400">Manage lab tests and results</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="flex items-center space-x-2">
              <Plus className="h-4 w-4" />
              <span>Order Test</span>
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Order Lab Test</DialogTitle>
              <DialogDescription>Create a new laboratory test order</DialogDescription>
            </DialogHeader>
            <LabTestForm patients={patients} onSubmit={addLabTest} onClose={() => setIsAddDialogOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <TestTube className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.pending}</p>
                <p className="text-sm text-gray-600">Pending Tests</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.inProgress}</p>
                <p className="text-sm text-gray-600">In Progress</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.completed}</p>
                <p className="text-sm text-gray-600">Completed</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <FileText className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-sm text-gray-600">Total Tests</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Lab Tests List */}
      <Card>
        <CardHeader>
          <CardTitle>Laboratory Tests</CardTitle>
          <CardDescription>Recent laboratory test orders and results</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {labTests.map((test) => (
              <div key={test.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50">
                <div className="flex items-center space-x-3">
                  <TestTube className="h-5 w-5 text-gray-500" />
                  <div>
                    <p className="font-medium">
                      {test.testType} - {test.patientName}
                    </p>
                    <p className="text-sm text-gray-600">
                      Ordered by {test.orderedBy} • {new Date(test.createdAt).toLocaleDateString()}
                    </p>
                    <p className="text-sm text-gray-500">{test.description}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" onClick={() => setSelectedTest(test)}>
                      <Eye className="h-4 w-4" />
                    </Button>
                    {test.status === "pending" && (
                      <Button size="sm" variant="outline" onClick={() => updateTestStatus(test.id, "in-progress")}>
                        Start
                      </Button>
                    )}
                    {test.status === "in-progress" && (
                      <Button
                        size="sm"
                        onClick={() => {
                          const result = prompt("Enter test result:")
                          if (result) {
                            updateTestStatus(test.id, "completed", result)
                          }
                        }}
                      >
                        Complete
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
          {labTests.length === 0 && (
            <div className="text-center py-8">
              <p className="text-gray-500">No lab tests ordered yet. Create your first test order to get started.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Test Details Dialog */}
      <Dialog open={!!selectedTest} onOpenChange={() => setSelectedTest(null)}>
        <DialogContent className="max-w-2xl">{selectedTest && <TestDetailsView test={selectedTest} />}</DialogContent>
      </Dialog>
    </div>
  )
}

function LabTestForm({
  patients,
  onSubmit,
  onClose,
}: {
  patients: any[]
  onSubmit: (data: any) => void
  onClose: () => void
}) {
  const [formData, setFormData] = useState({
    patientId: "",
    patientName: "",
    testType: "",
    description: "",
    notes: "",
    orderedBy: "",
    status: "pending" as const,
  })

  const testTypes = [
    "Blood Test",
    "Urine Test",
    "Stool Test",
    "X-Ray",
    "MRI",
    "CT Scan",
    "Ultrasound",
    "ECG",
    "Biopsy",
    "Allergy Test",
    "Glucose Test",
    "Cholesterol Test",
  ]

  const user = JSON.parse(localStorage.getItem("hms-user") || "{}")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit({
      ...formData,
      orderedBy: user.username || "Unknown",
    })
    onClose()
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handlePatientChange = (patientId: string) => {
    const patient = patients.find((p) => p.id === patientId)
    setFormData((prev) => ({
      ...prev,
      patientId,
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : "",
    }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="patient">Patient *</Label>
        <Select value={formData.patientId} onValueChange={handlePatientChange} required>
          <SelectTrigger>
            <SelectValue placeholder="Select patient" />
          </SelectTrigger>
          <SelectContent>
            {patients.map((patient) => (
              <SelectItem key={patient.id} value={patient.id}>
                {patient.firstName} {patient.lastName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="testType">Test Type *</Label>
        <Select value={formData.testType} onValueChange={(value) => handleChange("testType", value)} required>
          <SelectTrigger>
            <SelectValue placeholder="Select test type" />
          </SelectTrigger>
          <SelectContent>
            {testTypes.map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description *</Label>
        <Textarea
          id="description"
          placeholder="Describe the test requirements..."
          value={formData.description}
          onChange={(e) => handleChange("description", e.target.value)}
          required
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Additional Notes</Label>
        <Textarea
          id="notes"
          placeholder="Any additional instructions or notes..."
          value={formData.notes}
          onChange={(e) => handleChange("notes", e.target.value)}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">Order Test</Button>
      </div>
    </form>
  )
}

function TestDetailsView({ test }: { test: LabTest }) {
  return (
    <div>
      <DialogHeader>
        <DialogTitle>Lab Test Details</DialogTitle>
        <DialogDescription>Test ID: {test.id}</DialogDescription>
      </DialogHeader>

      <div className="mt-6 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium text-gray-600">Patient</Label>
            <p className="font-medium">{test.patientName}</p>
          </div>
          <div>
            <Label className="text-sm font-medium text-gray-600">Test Type</Label>
            <p className="font-medium">{test.testType}</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium text-gray-600">Status</Label>
            <Badge
              className={`mt-1 ${test.status === "completed" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"}`}
            >
              {test.status}
            </Badge>
          </div>
          <div>
            <Label className="text-sm font-medium text-gray-600">Ordered By</Label>
            <p className="font-medium">{test.orderedBy}</p>
          </div>
        </div>

        <div>
          <Label className="text-sm font-medium text-gray-600">Description</Label>
          <p className="mt-1 text-gray-700">{test.description}</p>
        </div>

        {test.result && (
          <div>
            <Label className="text-sm font-medium text-gray-600">Result</Label>
            <p className="mt-1 text-gray-700 font-medium">{test.result}</p>
          </div>
        )}

        {test.notes && (
          <div>
            <Label className="text-sm font-medium text-gray-600">Notes</Label>
            <p className="mt-1 text-gray-700">{test.notes}</p>
          </div>
        )}

        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label className="text-sm font-medium text-gray-600">Ordered Date</Label>
            <p className="font-medium">{new Date(test.createdAt).toLocaleString()}</p>
          </div>
          {test.completedAt && (
            <div>
              <Label className="text-sm font-medium text-gray-600">Completed Date</Label>
              <p className="font-medium">{new Date(test.completedAt).toLocaleString()}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
