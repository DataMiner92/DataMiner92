"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { BarChart3, FileText, Download, Users, DollarSign, Calendar, Activity } from "lucide-react"
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
} from "recharts"

interface ReportsManagementProps {
  userRole: string
}

export function ReportsManagement({ userRole }: ReportsManagementProps) {
  const [reportType, setReportType] = useState("overview")
  const [dateRange, setDateRange] = useState("last30days")
  const [reportData, setReportData] = useState<any>({})

  // Load and process data from localStorage
  useEffect(() => {
    const patients = JSON.parse(localStorage.getItem("hms-patients") || "[]")
    const doctors = JSON.parse(localStorage.getItem("hms-doctors") || "[]")
    const appointments = JSON.parse(localStorage.getItem("hms-appointments") || "[]")
    const bills = JSON.parse(localStorage.getItem("hms-bills") || "[]")
    const labTests = JSON.parse(localStorage.getItem("hms-lab-tests") || "[]")
    const beds = JSON.parse(localStorage.getItem("hms-beds") || "[]")
    const departments = JSON.parse(localStorage.getItem("hms-departments") || "[]")

    // Process data based on date range
    const now = new Date()
    const daysBack = dateRange === "last7days" ? 7 : dateRange === "last30days" ? 30 : 90
    const startDate = new Date(now.getTime() - daysBack * 24 * 60 * 60 * 1000)

    const filteredAppointments = appointments.filter((apt: any) => new Date(apt.createdAt) >= startDate)
    const filteredBills = bills.filter((bill: any) => new Date(bill.createdAt) >= startDate)
    const filteredLabTests = labTests.filter((test: any) => new Date(test.createdAt) >= startDate)

    // Generate monthly data for charts
    const monthlyData = []
    for (let i = 5; i >= 0; i--) {
      const date = new Date(now.getFullYear(), now.getMonth() - i, 1)
      const monthStart = new Date(date.getFullYear(), date.getMonth(), 1)
      const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0)

      const monthAppointments = appointments.filter((apt: any) => {
        const aptDate = new Date(apt.createdAt)
        return aptDate >= monthStart && aptDate <= monthEnd
      })

      const monthBills = bills.filter((bill: any) => {
        const billDate = new Date(bill.createdAt)
        return billDate >= monthStart && billDate <= monthEnd
      })

      const monthPatients = patients.filter((patient: any) => {
        const patientDate = new Date(patient.createdAt)
        return patientDate >= monthStart && patientDate <= monthEnd
      })

      monthlyData.push({
        month: date.toLocaleDateString("en-US", { month: "short" }),
        appointments: monthAppointments.length,
        revenue: monthBills.reduce((sum: number, bill: any) => sum + (bill.total || 0), 0),
        patients: monthPatients.length,
      })
    }

    // Department statistics
    const departmentStats = departments.map((dept: any) => {
      const deptAppointments = appointments.filter((apt: any) => {
        const doctor = doctors.find((doc: any) => `Dr. ${doc.firstName} ${doc.lastName}` === apt.doctorName)
        return doctor?.specialization === dept.name
      })
      return {
        name: dept.name,
        appointments: deptAppointments.length,
        staff: dept.staffCount || 0,
        budget: dept.budget || 0,
      }
    })

    // Appointment status distribution
    const appointmentStatusData = [
      {
        name: "Completed",
        value: appointments.filter((apt: any) => apt.status === "completed").length,
        color: "#10B981",
      },
      {
        name: "Scheduled",
        value: appointments.filter((apt: any) => apt.status === "scheduled").length,
        color: "#3B82F6",
      },
      {
        name: "Cancelled",
        value: appointments.filter((apt: any) => apt.status === "cancelled").length,
        color: "#EF4444",
      },
      { name: "No Show", value: appointments.filter((apt: any) => apt.status === "no-show").length, color: "#6B7280" },
    ]

    // Revenue by category
    const revenueByCategory = bills.reduce((acc: any, bill: any) => {
      bill.items?.forEach((item: any) => {
        if (!acc[item.category]) {
          acc[item.category] = 0
        }
        acc[item.category] += item.total || 0
      })
      return acc
    }, {})

    const revenueCategoryData = Object.entries(revenueByCategory).map(([category, amount]) => ({
      category,
      amount: amount as number,
    }))

    setReportData({
      overview: {
        totalPatients: patients.length,
        totalDoctors: doctors.length,
        totalAppointments: appointments.length,
        totalRevenue: bills.reduce((sum: number, bill: any) => sum + (bill.total || 0), 0),
        occupancyRate:
          beds.length > 0
            ? Math.round((beds.filter((bed: any) => bed.status === "occupied").length / beds.length) * 100)
            : 0,
        pendingTests: labTests.filter((test: any) => test.status === "pending").length,
      },
      monthly: monthlyData,
      departments: departmentStats,
      appointmentStatus: appointmentStatusData,
      revenueByCategory: revenueCategoryData,
      filtered: {
        appointments: filteredAppointments.length,
        revenue: filteredBills.reduce((sum: number, bill: any) => sum + (bill.total || 0), 0),
        tests: filteredLabTests.length,
      },
    })
  }, [dateRange])

  const generateReport = (type: string) => {
    const reportContent = generateReportContent(type, reportData)
    const blob = new Blob([reportContent], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${type}-report-${new Date().toISOString().split("T")[0]}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  const generateReportContent = (type: string, data: any) => {
    const date = new Date().toLocaleDateString()
    let content = `Hospital Management System - ${type.toUpperCase()} REPORT\n`
    content += `Generated on: ${date}\n`
    content += `Date Range: ${dateRange}\n`
    content += "=" * 50 + "\n\n"

    switch (type) {
      case "patient":
        content += `PATIENT STATISTICS\n`
        content += `-----------------\n`
        content += `Total Patients: ${data.overview?.totalPatients || 0}\n`
        content += `New Patients (${dateRange}): ${data.filtered?.appointments || 0}\n\n`
        break

      case "financial":
        content += `FINANCIAL REPORT\n`
        content += `---------------\n`
        content += `Total Revenue: $${(data.overview?.totalRevenue || 0).toFixed(2)}\n`
        content += `Revenue (${dateRange}): $${(data.filtered?.revenue || 0).toFixed(2)}\n\n`
        content += `REVENUE BY CATEGORY:\n`
        data.revenueByCategory?.forEach((item: any) => {
          content += `${item.category}: $${item.amount.toFixed(2)}\n`
        })
        content += "\n"
        break

      case "department":
        content += `DEPARTMENT PERFORMANCE\n`
        content += `---------------------\n`
        data.departments?.forEach((dept: any) => {
          content += `${dept.name}:\n`
          content += `  Appointments: ${dept.appointments}\n`
          content += `  Staff: ${dept.staff}\n`
          content += `  Budget: $${dept.budget.toLocaleString()}\n\n`
        })
        break

      default:
        content += `OVERVIEW REPORT\n`
        content += `--------------\n`
        content += `Total Patients: ${data.overview?.totalPatients || 0}\n`
        content += `Total Doctors: ${data.overview?.totalDoctors || 0}\n`
        content += `Total Appointments: ${data.overview?.totalAppointments || 0}\n`
        content += `Total Revenue: $${(data.overview?.totalRevenue || 0).toFixed(2)}\n`
        content += `Bed Occupancy Rate: ${data.overview?.occupancyRate || 0}%\n`
        content += `Pending Lab Tests: ${data.overview?.pendingTests || 0}\n\n`
    }

    content += `\nReport generated by Hospital Management System\n`
    return content
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Reports & Analytics</h2>
          <p className="text-gray-600 dark:text-gray-400">Generate and view hospital reports</p>
        </div>
        <div className="flex space-x-2">
          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="last7days">Last 7 Days</SelectItem>
              <SelectItem value="last30days">Last 30 Days</SelectItem>
              <SelectItem value="last90days">Last 90 Days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={() => generateReport(reportType)} className="flex items-center space-x-2">
            <Download className="h-4 w-4" />
            <span>Download Report</span>
          </Button>
        </div>
      </div>

      {/* Report Type Selection */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { id: "overview", title: "Overview Report", description: "General hospital statistics", icon: BarChart3 },
          { id: "patient", title: "Patient Report", description: "Patient analytics and trends", icon: Users },
          {
            id: "financial",
            title: "Financial Report",
            description: "Revenue and billing analytics",
            icon: DollarSign,
          },
          {
            id: "department",
            title: "Department Report",
            description: "Department performance metrics",
            icon: Activity,
          },
        ].map((report) => (
          <Card
            key={report.id}
            className={`cursor-pointer transition-all ${reportType === report.id ? "ring-2 ring-blue-500 bg-blue-50" : "hover:shadow-md"}`}
            onClick={() => setReportType(report.id)}
          >
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <report.icon className="h-5 w-5 text-blue-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm">{report.title}</h3>
                  <p className="text-xs text-gray-600">{report.description}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Overview Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-blue-600" />
              <div>
                <p className="text-lg font-bold">{reportData.overview?.totalPatients || 0}</p>
                <p className="text-xs text-gray-600">Total Patients</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-green-600" />
              <div>
                <p className="text-lg font-bold">{reportData.overview?.totalDoctors || 0}</p>
                <p className="text-xs text-gray-600">Total Doctors</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Calendar className="h-4 w-4 text-purple-600" />
              <div>
                <p className="text-lg font-bold">{reportData.overview?.totalAppointments || 0}</p>
                <p className="text-xs text-gray-600">Appointments</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-4 w-4 text-yellow-600" />
              <div>
                <p className="text-lg font-bold">${(reportData.overview?.totalRevenue || 0).toFixed(0)}</p>
                <p className="text-xs text-gray-600">Total Revenue</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Activity className="h-4 w-4 text-red-600" />
              <div>
                <p className="text-lg font-bold">{reportData.overview?.occupancyRate || 0}%</p>
                <p className="text-xs text-gray-600">Bed Occupancy</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <FileText className="h-4 w-4 text-indigo-600" />
              <div>
                <p className="text-lg font-bold">{reportData.overview?.pendingTests || 0}</p>
                <p className="text-xs text-gray-600">Pending Tests</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Trends</CardTitle>
            <CardDescription>Appointments and revenue over time</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={reportData.monthly || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="appointments" stroke="#3B82F6" name="Appointments" />
                <Line type="monotone" dataKey="patients" stroke="#10B981" name="New Patients" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Appointment Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Appointment Status</CardTitle>
            <CardDescription>Distribution of appointment statuses</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={reportData.appointmentStatus || []}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                >
                  {(reportData.appointmentStatus || []).map((entry: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Department Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Department Performance</CardTitle>
            <CardDescription>Appointments by department</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={reportData.departments || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="appointments" fill="#3B82F6" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Revenue by Category */}
        <Card>
          <CardHeader>
            <CardTitle>Revenue by Category</CardTitle>
            <CardDescription>Revenue breakdown by service category</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={reportData.revenueByCategory || []}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="category" />
                <YAxis />
                <Tooltip formatter={(value) => [`$${value}`, "Revenue"]} />
                <Bar dataKey="amount" fill="#10B981" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Report Actions</CardTitle>
          <CardDescription>Generate specific reports quickly</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { type: "patient", title: "Patient Report", description: "Comprehensive patient statistics" },
              { type: "financial", title: "Financial Report", description: "Revenue and billing analytics" },
              { type: "department", title: "Department Report", description: "Department performance metrics" },
              { type: "overview", title: "Overview Report", description: "General hospital statistics" },
            ].map((report) => (
              <Button
                key={report.type}
                variant="outline"
                className="h-auto p-4 flex flex-col items-start space-y-2 bg-transparent"
                onClick={() => generateReport(report.type)}
              >
                <div className="flex items-center space-x-2">
                  <Download className="h-4 w-4" />
                  <span className="font-medium">{report.title}</span>
                </div>
                <p className="text-xs text-gray-600 text-left">{report.description}</p>
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
