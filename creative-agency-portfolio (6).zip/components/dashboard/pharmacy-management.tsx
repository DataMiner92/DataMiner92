"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Pill, Package, AlertTriangle, TrendingDown, Plus, Edit, Trash2, Search } from "lucide-react"
import { toast } from "sonner"

interface PharmacyManagementProps {
  userRole: string
}

interface Medication {
  id: string
  name: string
  category: string
  manufacturer: string
  batchNumber: string
  expiryDate: string
  quantity: number
  unitPrice: number
  description: string
  status: "available" | "low-stock" | "out-of-stock" | "expired"
  createdAt: string
}

interface Prescription {
  id: string
  patientId: string
  patientName: string
  doctorId: string
  doctorName: string
  medications: {
    medicationId: string
    medicationName: string
    dosage: string
    frequency: string
    duration: string
    quantity: number
  }[]
  status: "pending" | "dispensed" | "cancelled"
  notes?: string
  createdAt: string
  dispensedAt?: string
}

export function PharmacyManagement({ userRole }: PharmacyManagementProps) {
  const [medications, setMedications] = useState<Medication[]>([])
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([])
  const [patients, setPatients] = useState<any[]>([])
  const [doctors, setDoctors] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState<"inventory" | "prescriptions">("inventory")
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddMedicationOpen, setIsAddMedicationOpen] = useState(false)
  const [isAddPrescriptionOpen, setIsAddPrescriptionOpen] = useState(false)
  const [editingMedication, setEditingMedication] = useState<Medication | null>(null)

  // Load data from localStorage
  useEffect(() => {
    const savedMedications = localStorage.getItem("hms-medications")
    const savedPrescriptions = localStorage.getItem("hms-prescriptions")
    const savedPatients = localStorage.getItem("hms-patients")
    const savedDoctors = localStorage.getItem("hms-doctors")

    if (savedMedications) setMedications(JSON.parse(savedMedications))
    if (savedPrescriptions) setPrescriptions(JSON.parse(savedPrescriptions))
    if (savedPatients) setPatients(JSON.parse(savedPatients))
    if (savedDoctors) setDoctors(JSON.parse(savedDoctors))
  }, [])

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem("hms-medications", JSON.stringify(medications))
  }, [medications])

  useEffect(() => {
    localStorage.setItem("hms-prescriptions", JSON.stringify(prescriptions))
  }, [prescriptions])

  const addMedication = (medicationData: Omit<Medication, "id" | "createdAt" | "status">) => {
    const newMedication: Medication = {
      ...medicationData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      status: medicationData.quantity === 0 ? "out-of-stock" : medicationData.quantity < 10 ? "low-stock" : "available",
    }
    setMedications((prev) => [...prev, newMedication])
    toast.success("Medication added successfully!")
  }

  const updateMedication = (updatedMedication: Medication) => {
    setMedications((prev) => prev.map((m) => (m.id === updatedMedication.id ? updatedMedication : m)))
    toast.success("Medication updated successfully!")
  }

  const deleteMedication = (id: string) => {
    if (confirm("Are you sure you want to delete this medication?")) {
      setMedications((prev) => prev.filter((m) => m.id !== id))
      toast.success("Medication deleted successfully!")
    }
  }

  const addPrescription = (prescriptionData: Omit<Prescription, "id" | "createdAt">) => {
    const newPrescription: Prescription = {
      ...prescriptionData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }
    setPrescriptions((prev) => [...prev, newPrescription])
    toast.success("Prescription created successfully!")
  }

  const dispensePrescription = (id: string) => {
    setPrescriptions((prev) =>
      prev.map((p) =>
        p.id === id
          ? {
              ...p,
              status: "dispensed" as const,
              dispensedAt: new Date().toISOString(),
            }
          : p,
      ),
    )
    toast.success("Prescription dispensed successfully!")
  }

  const filteredMedications = medications.filter(
    (med) =>
      med.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      med.category.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const stats = {
    totalMedications: medications.length,
    lowStock: medications.filter((m) => m.status === "low-stock").length,
    outOfStock: medications.filter((m) => m.status === "out-of-stock").length,
    expired: medications.filter((m) => new Date(m.expiryDate) < new Date()).length,
    pendingPrescriptions: prescriptions.filter((p) => p.status === "pending").length,
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800"
      case "low-stock":
        return "bg-yellow-100 text-yellow-800"
      case "out-of-stock":
        return "bg-red-100 text-red-800"
      case "expired":
        return "bg-gray-100 text-gray-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Pharmacy Management</h2>
          <p className="text-gray-600 dark:text-gray-400">Manage medication inventory and prescriptions</p>
        </div>
        <div className="flex space-x-2">
          <Dialog open={isAddMedicationOpen} onOpenChange={setIsAddMedicationOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                <Plus className="h-4 w-4" />
                <span>Add Medication</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Add New Medication</DialogTitle>
                <DialogDescription>Add a new medication to the inventory</DialogDescription>
              </DialogHeader>
              <MedicationForm onSubmit={addMedication} onClose={() => setIsAddMedicationOpen(false)} />
            </DialogContent>
          </Dialog>
          <Dialog open={isAddPrescriptionOpen} onOpenChange={setIsAddPrescriptionOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>New Prescription</span>
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-4xl">
              <DialogHeader>
                <DialogTitle>Create Prescription</DialogTitle>
                <DialogDescription>Create a new prescription for a patient</DialogDescription>
              </DialogHeader>
              <PrescriptionForm
                patients={patients}
                doctors={doctors}
                medications={medications}
                onSubmit={addPrescription}
                onClose={() => setIsAddPrescriptionOpen(false)}
              />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Pill className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalMedications}</p>
                <p className="text-sm text-gray-600">Total Medications</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.lowStock}</p>
                <p className="text-sm text-gray-600">Low Stock</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-red-100 rounded-lg">
                <TrendingDown className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.outOfStock}</p>
                <p className="text-sm text-gray-600">Out of Stock</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-gray-100 rounded-lg">
                <Package className="h-6 w-6 text-gray-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.expired}</p>
                <p className="text-sm text-gray-600">Expired</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Package className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.pendingPrescriptions}</p>
                <p className="text-sm text-gray-600">Pending Prescriptions</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <div className="flex space-x-4 border-b">
        <button
          className={`pb-2 px-1 ${activeTab === "inventory" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"}`}
          onClick={() => setActiveTab("inventory")}
        >
          Inventory
        </button>
        <button
          className={`pb-2 px-1 ${activeTab === "prescriptions" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"}`}
          onClick={() => setActiveTab("prescriptions")}
        >
          Prescriptions
        </button>
      </div>

      {activeTab === "inventory" && (
        <div className="space-y-6">
          {/* Search */}
          <Card>
            <CardContent className="p-6">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search medications..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </CardContent>
          </Card>

          {/* Medications Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredMedications.map((medication) => (
              <Card key={medication.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-lg">{medication.name}</h3>
                      <p className="text-sm text-gray-600">{medication.category}</p>
                      <p className="text-xs text-gray-500">{medication.manufacturer}</p>
                    </div>
                    <Badge className={getStatusColor(medication.status)}>{medication.status}</Badge>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Quantity:</span>
                      <span className="font-medium">{medication.quantity}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Unit Price:</span>
                      <span className="font-medium">${medication.unitPrice}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Expiry:</span>
                      <span className="font-medium">{new Date(medication.expiryDate).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Batch:</span>
                      <span className="font-medium text-xs">{medication.batchNumber}</span>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditingMedication(medication)
                        setIsAddMedicationOpen(true)
                      }}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    {userRole === "Admin" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-red-600"
                        onClick={() => deleteMedication(medication.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {activeTab === "prescriptions" && (
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Prescriptions</CardTitle>
              <CardDescription>Manage patient prescriptions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {prescriptions.map((prescription) => (
                  <div key={prescription.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold">{prescription.patientName}</h4>
                        <p className="text-sm text-gray-600">Prescribed by {prescription.doctorName}</p>
                        <p className="text-xs text-gray-500">{new Date(prescription.createdAt).toLocaleDateString()}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          className={
                            prescription.status === "dispensed"
                              ? "bg-green-100 text-green-800"
                              : prescription.status === "pending"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-red-100 text-red-800"
                          }
                        >
                          {prescription.status}
                        </Badge>
                        {prescription.status === "pending" && (
                          <Button size="sm" onClick={() => dispensePrescription(prescription.id)}>
                            Dispense
                          </Button>
                        )}
                      </div>
                    </div>
                    <div className="space-y-2">
                      {prescription.medications.map((med, index) => (
                        <div key={index} className="bg-gray-50 p-3 rounded">
                          <p className="font-medium">{med.medicationName}</p>
                          <p className="text-sm text-gray-600">
                            {med.dosage} - {med.frequency} for {med.duration} (Qty: {med.quantity})
                          </p>
                        </div>
                      ))}
                    </div>
                    {prescription.notes && (
                      <div className="mt-3 p-3 bg-blue-50 rounded">
                        <p className="text-sm text-blue-800">{prescription.notes}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Edit Medication Dialog */}
      <Dialog
        open={isAddMedicationOpen && !!editingMedication}
        onOpenChange={() => {
          setIsAddMedicationOpen(false)
          setEditingMedication(null)
        }}
      >
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Edit Medication</DialogTitle>
            <DialogDescription>Update medication information</DialogDescription>
          </DialogHeader>
          {editingMedication && (
            <MedicationForm
              medication={editingMedication}
              onSubmit={updateMedication}
              onClose={() => {
                setIsAddMedicationOpen(false)
                setEditingMedication(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function MedicationForm({
  medication,
  onSubmit,
  onClose,
}: {
  medication?: Medication
  onSubmit: (data: any) => void
  onClose: () => void
}) {
  const [formData, setFormData] = useState({
    name: medication?.name || "",
    category: medication?.category || "",
    manufacturer: medication?.manufacturer || "",
    batchNumber: medication?.batchNumber || "",
    expiryDate: medication?.expiryDate || "",
    quantity: medication?.quantity || 0,
    unitPrice: medication?.unitPrice || 0,
    description: medication?.description || "",
  })

  const categories = [
    "Antibiotics",
    "Pain Relief",
    "Cardiovascular",
    "Diabetes",
    "Respiratory",
    "Gastrointestinal",
    "Neurological",
    "Vitamins & Supplements",
    "Topical",
    "Other",
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (medication) {
      onSubmit({ ...medication, ...formData })
    } else {
      onSubmit(formData)
    }
    onClose()
  }

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Medication Name *</Label>
          <Input id="name" value={formData.name} onChange={(e) => handleChange("name", e.target.value)} required />
        </div>
        <div className="space-y-2">
          <Label htmlFor="category">Category *</Label>
          <Select value={formData.category} onValueChange={(value) => handleChange("category", value)}>
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((cat) => (
                <SelectItem key={cat} value={cat}>
                  {cat}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="manufacturer">Manufacturer *</Label>
          <Input
            id="manufacturer"
            value={formData.manufacturer}
            onChange={(e) => handleChange("manufacturer", e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="batchNumber">Batch Number *</Label>
          <Input
            id="batchNumber"
            value={formData.batchNumber}
            onChange={(e) => handleChange("batchNumber", e.target.value)}
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <div className="space-y-2">
          <Label htmlFor="quantity">Quantity *</Label>
          <Input
            id="quantity"
            type="number"
            min="0"
            value={formData.quantity}
            onChange={(e) => handleChange("quantity", Number.parseInt(e.target.value))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="unitPrice">Unit Price *</Label>
          <Input
            id="unitPrice"
            type="number"
            step="0.01"
            min="0"
            value={formData.unitPrice}
            onChange={(e) => handleChange("unitPrice", Number.parseFloat(e.target.value))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="expiryDate">Expiry Date *</Label>
          <Input
            id="expiryDate"
            type="date"
            value={formData.expiryDate}
            onChange={(e) => handleChange("expiryDate", e.target.value)}
            required
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Medication description..."
          value={formData.description}
          onChange={(e) => handleChange("description", e.target.value)}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">{medication ? "Update Medication" : "Add Medication"}</Button>
      </div>
    </form>
  )
}

function PrescriptionForm({
  patients,
  doctors,
  medications,
  onSubmit,
  onClose,
}: {
  patients: any[]
  doctors: any[]
  medications: Medication[]
  onSubmit: (data: any) => void
  onClose: () => void
}) {
  const [formData, setFormData] = useState({
    patientId: "",
    patientName: "",
    doctorId: "",
    doctorName: "",
    medications: [
      {
        medicationId: "",
        medicationName: "",
        dosage: "",
        frequency: "",
        duration: "",
        quantity: 1,
      },
    ],
    status: "pending" as const,
    notes: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
    onClose()
  }

  const handlePatientChange = (patientId: string) => {
    const patient = patients.find((p) => p.id === patientId)
    setFormData((prev) => ({
      ...prev,
      patientId,
      patientName: patient ? `${patient.firstName} ${patient.lastName}` : "",
    }))
  }

  const handleDoctorChange = (doctorId: string) => {
    const doctor = doctors.find((d) => d.id === doctorId)
    setFormData((prev) => ({
      ...prev,
      doctorId,
      doctorName: doctor ? `Dr. ${doctor.firstName} ${doctor.lastName}` : "",
    }))
  }

  const addMedication = () => {
    setFormData((prev) => ({
      ...prev,
      medications: [
        ...prev.medications,
        {
          medicationId: "",
          medicationName: "",
          dosage: "",
          frequency: "",
          duration: "",
          quantity: 1,
        },
      ],
    }))
  }

  const removeMedication = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      medications: prev.medications.filter((_, i) => i !== index),
    }))
  }

  const updateMedication = (index: number, field: string, value: any) => {
    setFormData((prev) => ({
      ...prev,
      medications: prev.medications.map((med, i) => (i === index ? { ...med, [field]: value } : med)),
    }))
  }

  const handleMedicationSelect = (index: number, medicationId: string) => {
    const medication = medications.find((m) => m.id === medicationId)
    if (medication) {
      updateMedication(index, "medicationId", medicationId)
      updateMedication(index, "medicationName", medication.name)
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="patient">Patient *</Label>
          <Select value={formData.patientId} onValueChange={handlePatientChange} required>
            <SelectTrigger>
              <SelectValue placeholder="Select patient" />
            </SelectTrigger>
            <SelectContent>
              {patients.map((patient) => (
                <SelectItem key={patient.id} value={patient.id}>
                  {patient.firstName} {patient.lastName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="doctor">Doctor *</Label>
          <Select value={formData.doctorId} onValueChange={handleDoctorChange} required>
            <SelectTrigger>
              <SelectValue placeholder="Select doctor" />
            </SelectTrigger>
            <SelectContent>
              {doctors.map((doctor) => (
                <SelectItem key={doctor.id} value={doctor.id}>
                  Dr. {doctor.firstName} {doctor.lastName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label>Medications *</Label>
          <Button type="button" variant="outline" size="sm" onClick={addMedication}>
            <Plus className="h-4 w-4 mr-2" />
            Add Medication
          </Button>
        </div>

        {formData.medications.map((med, index) => (
          <div key={index} className="border rounded-lg p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Medication {index + 1}</h4>
              {formData.medications.length > 1 && (
                <Button type="button" variant="ghost" size="sm" onClick={() => removeMedication(index)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Medication</Label>
                <Select
                  value={med.medicationId}
                  onValueChange={(value) => handleMedicationSelect(index, value)}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select medication" />
                  </SelectTrigger>
                  <SelectContent>
                    {medications
                      .filter((m) => m.status === "available")
                      .map((medication) => (
                        <SelectItem key={medication.id} value={medication.id}>
                          {medication.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Dosage</Label>
                <Input
                  placeholder="e.g., 500mg"
                  value={med.dosage}
                  onChange={(e) => updateMedication(index, "dosage", e.target.value)}
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label>Frequency</Label>
                <Select
                  value={med.frequency}
                  onValueChange={(value) => updateMedication(index, "frequency", value)}
                  required
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Once daily">Once daily</SelectItem>
                    <SelectItem value="Twice daily">Twice daily</SelectItem>
                    <SelectItem value="Three times daily">Three times daily</SelectItem>
                    <SelectItem value="Four times daily">Four times daily</SelectItem>
                    <SelectItem value="As needed">As needed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Duration</Label>
                <Input
                  placeholder="e.g., 7 days"
                  value={med.duration}
                  onChange={(e) => updateMedication(index, "duration", e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>Quantity</Label>
                <Input
                  type="number"
                  min="1"
                  value={med.quantity}
                  onChange={(e) => updateMedication(index, "quantity", Number.parseInt(e.target.value))}
                  required
                />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          placeholder="Additional instructions..."
          value={formData.notes}
          onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">Create Prescription</Button>
      </div>
    </form>
  )
}
