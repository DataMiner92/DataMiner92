"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, AlertTriangle } from "lucide-react"

interface AuditLogsProps {
  userRole: string
}

export function AuditLogs({ userRole }: AuditLogsProps) {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Audit Logs</h2>
        <p className="text-gray-600 dark:text-gray-400">System security and activity monitoring</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest system access and security events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[
              { user: "admin", action: "Login successful", time: "2 min ago", type: "success" },
              { user: "doctor", action: "Patient record accessed", time: "5 min ago", type: "info" },
              { user: "unknown", action: "Failed login attempt", time: "10 min ago", type: "warning" },
            ].map((log, index) => (
              <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <div
                    className={`p-2 rounded-lg ${
                      log.type === "success" ? "bg-green-100" : log.type === "warning" ? "bg-yellow-100" : "bg-blue-100"
                    }`}
                  >
                    {log.type === "warning" ? (
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                    ) : (
                      <Shield className="h-4 w-4 text-blue-600" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium">{log.action}</p>
                    <p className="text-sm text-gray-600">User: {log.user}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge variant={log.type === "warning" ? "destructive" : "secondary"}>{log.type}</Badge>
                  <p className="text-sm text-gray-500">{log.time}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
