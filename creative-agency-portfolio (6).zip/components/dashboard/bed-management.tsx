"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Bed, Users, Clock, CheckCircle, Plus, UserCheck } from "lucide-react"
import { toast } from "sonner"

interface BedManagementProps {
  userRole: string
}

interface BedRecord {
  id: string
  bedNumber: string
  ward: string
  bedType: string
  status: "available" | "occupied" | "maintenance" | "reserved"
  patientId?: string
  patientName?: string
  admissionDate?: string
  expectedDischarge?: string
  notes?: string
  createdAt: string
}

interface Ward {
  id: string
  name: string
  totalBeds: number
  department: string
  description: string
}

export function BedManagement({ userRole }: BedManagementProps) {
  const [beds, setBeds] = useState<BedRecord[]>([])
  const [wards, setWards] = useState<Ward[]>([])
  const [patients, setPatients] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState<"beds" | "wards">("beds")
  const [isAddBedOpen, setIsAddBedOpen] = useState(false)
  const [isAddWardOpen, setIsAddWardOpen] = useState(false)
  const [isAssignPatientOpen, setIsAssignPatientOpen] = useState(false)
  const [selectedBed, setSelectedBed] = useState<BedRecord | null>(null)
  const [selectedWard, setSelectedWard] = useState("")

  // Load data from localStorage
  useEffect(() => {
    const savedBeds = localStorage.getItem("hms-beds")
    const savedWards = localStorage.getItem("hms-wards")
    const savedPatients = localStorage.getItem("hms-patients")

    if (savedBeds) setBeds(JSON.parse(savedBeds))
    if (savedWards) setWards(JSON.parse(savedWards))
    if (savedPatients) setPatients(JSON.parse(savedPatients))

    // Initialize default wards if none exist
    if (!savedWards) {
      const defaultWards = [
        { id: "1", name: "ICU", totalBeds: 20, department: "Critical Care", description: "Intensive Care Unit" },
        {
          id: "2",
          name: "General Ward",
          totalBeds: 50,
          department: "General Medicine",
          description: "General patient ward",
        },
        { id: "3", name: "Pediatrics", totalBeds: 30, department: "Pediatrics", description: "Children's ward" },
        { id: "4", name: "Maternity", totalBeds: 25, department: "Obstetrics", description: "Maternity ward" },
      ]
      setWards(defaultWards)
      localStorage.setItem("hms-wards", JSON.stringify(defaultWards))
    }
  }, [])

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem("hms-beds", JSON.stringify(beds))
  }, [beds])

  useEffect(() => {
    localStorage.setItem("hms-wards", JSON.stringify(wards))
  }, [wards])

  const addBed = (bedData: Omit<BedRecord, "id" | "createdAt">) => {
    const newBed: BedRecord = {
      ...bedData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }
    setBeds((prev) => [...prev, newBed])
    toast.success("Bed added successfully!")
  }

  const addWard = (wardData: Omit<Ward, "id">) => {
    const newWard: Ward = {
      ...wardData,
      id: Date.now().toString(),
    }
    setWards((prev) => [...prev, newWard])
    toast.success("Ward added successfully!")
  }

  const assignPatient = (
    bedId: string,
    patientId: string,
    admissionDate: string,
    expectedDischarge: string,
    notes: string,
  ) => {
    const patient = patients.find((p) => p.id === patientId)
    setBeds((prev) =>
      prev.map((bed) =>
        bed.id === bedId
          ? {
              ...bed,
              status: "occupied" as const,
              patientId,
              patientName: patient ? `${patient.firstName} ${patient.lastName}` : "",
              admissionDate,
              expectedDischarge,
              notes,
            }
          : bed,
      ),
    )
    toast.success("Patient assigned to bed successfully!")
  }

  const dischargeBed = (bedId: string) => {
    if (confirm("Are you sure you want to discharge this patient?")) {
      setBeds((prev) =>
        prev.map((bed) =>
          bed.id === bedId
            ? {
                ...bed,
                status: "available" as const,
                patientId: undefined,
                patientName: undefined,
                admissionDate: undefined,
                expectedDischarge: undefined,
                notes: undefined,
              }
            : bed,
        ),
      )
      toast.success("Patient discharged successfully!")
    }
  }

  const updateBedStatus = (bedId: string, status: BedRecord["status"]) => {
    setBeds((prev) => prev.map((bed) => (bed.id === bedId ? { ...bed, status } : bed)))
    toast.success(`Bed status updated to ${status}!`)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available":
        return "bg-green-100 text-green-800"
      case "occupied":
        return "bg-red-100 text-red-800"
      case "maintenance":
        return "bg-yellow-100 text-yellow-800"
      case "reserved":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredBeds = selectedWard ? beds.filter((bed) => bed.ward === selectedWard) : beds

  const stats = {
    totalBeds: beds.length,
    available: beds.filter((b) => b.status === "available").length,
    occupied: beds.filter((b) => b.status === "occupied").length,
    maintenance: beds.filter((b) => b.status === "maintenance").length,
    occupancyRate:
      beds.length > 0 ? Math.round((beds.filter((b) => b.status === "occupied").length / beds.length) * 100) : 0,
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">Bed Management</h2>
          <p className="text-gray-600 dark:text-gray-400">Monitor bed availability and patient assignments</p>
        </div>
        <div className="flex space-x-2">
          <Dialog open={isAddWardOpen} onOpenChange={setIsAddWardOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" className="flex items-center space-x-2 bg-transparent">
                <Plus className="h-4 w-4" />
                <span>Add Ward</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Ward</DialogTitle>
                <DialogDescription>Create a new hospital ward</DialogDescription>
              </DialogHeader>
              <WardForm onSubmit={addWard} onClose={() => setIsAddWardOpen(false)} />
            </DialogContent>
          </Dialog>
          <Dialog open={isAddBedOpen} onOpenChange={setIsAddBedOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center space-x-2">
                <Plus className="h-4 w-4" />
                <span>Add Bed</span>
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Bed</DialogTitle>
                <DialogDescription>Add a new bed to the hospital</DialogDescription>
              </DialogHeader>
              <BedForm wards={wards} onSubmit={addBed} onClose={() => setIsAddBedOpen(false)} />
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-blue-100 rounded-lg">
                <Bed className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.totalBeds}</p>
                <p className="text-sm text-gray-600">Total Beds</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-green-100 rounded-lg">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.available}</p>
                <p className="text-sm text-gray-600">Available</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-red-100 rounded-lg">
                <Users className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.occupied}</p>
                <p className="text-sm text-gray-600">Occupied</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-yellow-100 rounded-lg">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.maintenance}</p>
                <p className="text-sm text-gray-600">Maintenance</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <div className="p-3 bg-purple-100 rounded-lg">
                <Users className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stats.occupancyRate}%</p>
                <p className="text-sm text-gray-600">Occupancy Rate</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <div className="flex space-x-4 border-b">
        <button
          className={`pb-2 px-1 ${activeTab === "beds" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"}`}
          onClick={() => setActiveTab("beds")}
        >
          Beds
        </button>
        <button
          className={`pb-2 px-1 ${activeTab === "wards" ? "border-b-2 border-blue-600 text-blue-600" : "text-gray-600"}`}
          onClick={() => setActiveTab("wards")}
        >
          Wards
        </button>
      </div>

      {activeTab === "beds" && (
        <div className="space-y-6">
          {/* Ward Filter */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <Label>Filter by Ward:</Label>
                <Select value={selectedWard} onValueChange={setSelectedWard}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Wards" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Wards</SelectItem>
                    {wards.map((ward) => (
                      <SelectItem key={ward.id} value={ward.name}>
                        {ward.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Beds Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredBeds.map((bed) => (
              <Card key={bed.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-semibold text-lg">Bed {bed.bedNumber}</h3>
                      <p className="text-sm text-gray-600">
                        {bed.ward} - {bed.bedType}
                      </p>
                    </div>
                    <Badge className={getStatusColor(bed.status)}>{bed.status}</Badge>
                  </div>

                  {bed.status === "occupied" && bed.patientName && (
                    <div className="space-y-2 mb-4 p-3 bg-gray-50 rounded">
                      <p className="font-medium text-sm">Patient: {bed.patientName}</p>
                      <p className="text-xs text-gray-600">
                        Admitted: {bed.admissionDate ? new Date(bed.admissionDate).toLocaleDateString() : "N/A"}
                      </p>
                      <p className="text-xs text-gray-600">
                        Expected Discharge:{" "}
                        {bed.expectedDischarge ? new Date(bed.expectedDischarge).toLocaleDateString() : "N/A"}
                      </p>
                      {bed.notes && <p className="text-xs text-gray-600">Notes: {bed.notes}</p>}
                    </div>
                  )}

                  <div className="flex space-x-2">
                    {bed.status === "available" && (
                      <Button
                        size="sm"
                        onClick={() => {
                          setSelectedBed(bed)
                          setIsAssignPatientOpen(true)
                        }}
                      >
                        <UserCheck className="h-4 w-4 mr-1" />
                        Assign
                      </Button>
                    )}
                    {bed.status === "occupied" && (
                      <Button size="sm" variant="outline" onClick={() => dischargeBed(bed.id)}>
                        Discharge
                      </Button>
                    )}
                    <Select
                      value={bed.status}
                      onValueChange={(value: BedRecord["status"]) => updateBedStatus(bed.id, value)}
                    >
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="available">Available</SelectItem>
                        <SelectItem value="occupied">Occupied</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="reserved">Reserved</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {activeTab === "wards" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {wards.map((ward) => {
              const wardBeds = beds.filter((bed) => bed.ward === ward.name)
              const occupiedBeds = wardBeds.filter((bed) => bed.status === "occupied").length
              const availableBeds = wardBeds.filter((bed) => bed.status === "available").length

              return (
                <Card key={ward.id}>
                  <CardHeader>
                    <CardTitle>{ward.name}</CardTitle>
                    <CardDescription>{ward.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Department:</span>
                        <span className="font-medium">{ward.department}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Total Beds:</span>
                        <span className="font-medium">{wardBeds.length}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Available:</span>
                        <span className="font-medium text-green-600">{availableBeds}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Occupied:</span>
                        <span className="font-medium text-red-600">{occupiedBeds}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Occupancy Rate:</span>
                        <span className="font-medium">
                          {wardBeds.length > 0 ? Math.round((occupiedBeds / wardBeds.length) * 100) : 0}%
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      )}

      {/* Assign Patient Dialog */}
      <Dialog open={isAssignPatientOpen} onOpenChange={setIsAssignPatientOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Patient to Bed</DialogTitle>
            <DialogDescription>
              Assign a patient to bed {selectedBed?.bedNumber} in {selectedBed?.ward}
            </DialogDescription>
          </DialogHeader>
          {selectedBed && (
            <AssignPatientForm
              bed={selectedBed}
              patients={patients}
              onSubmit={assignPatient}
              onClose={() => {
                setIsAssignPatientOpen(false)
                setSelectedBed(null)
              }}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function BedForm({ wards, onSubmit, onClose }: { wards: Ward[]; onSubmit: (data: any) => void; onClose: () => void }) {
  const [formData, setFormData] = useState({
    bedNumber: "",
    ward: "",
    bedType: "",
    status: "available" as const,
  })

  const bedTypes = ["Standard", "ICU", "Private", "Semi-Private", "Isolation", "Pediatric", "Maternity"]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
    onClose()
  }

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="bedNumber">Bed Number *</Label>
          <Input
            id="bedNumber"
            value={formData.bedNumber}
            onChange={(e) => handleChange("bedNumber", e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="ward">Ward *</Label>
          <Select value={formData.ward} onValueChange={(value) => handleChange("ward", value)} required>
            <SelectTrigger>
              <SelectValue placeholder="Select ward" />
            </SelectTrigger>
            <SelectContent>
              {wards.map((ward) => (
                <SelectItem key={ward.id} value={ward.name}>
                  {ward.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="bedType">Bed Type *</Label>
        <Select value={formData.bedType} onValueChange={(value) => handleChange("bedType", value)} required>
          <SelectTrigger>
            <SelectValue placeholder="Select bed type" />
          </SelectTrigger>
          <SelectContent>
            {bedTypes.map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">Add Bed</Button>
      </div>
    </form>
  )
}

function WardForm({ onSubmit, onClose }: { onSubmit: (data: any) => void; onClose: () => void }) {
  const [formData, setFormData] = useState({
    name: "",
    totalBeds: 0,
    department: "",
    description: "",
  })

  const departments = [
    "Critical Care",
    "General Medicine",
    "Surgery",
    "Pediatrics",
    "Obstetrics",
    "Cardiology",
    "Neurology",
    "Orthopedics",
    "Emergency",
    "Oncology",
  ]

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(formData)
    onClose()
  }

  const handleChange = (field: string, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="name">Ward Name *</Label>
        <Input id="name" value={formData.name} onChange={(e) => handleChange("name", e.target.value)} required />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="totalBeds">Total Beds *</Label>
          <Input
            id="totalBeds"
            type="number"
            min="1"
            value={formData.totalBeds}
            onChange={(e) => handleChange("totalBeds", Number.parseInt(e.target.value))}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="department">Department *</Label>
          <Select value={formData.department} onValueChange={(value) => handleChange("department", value)} required>
            <SelectTrigger>
              <SelectValue placeholder="Select department" />
            </SelectTrigger>
            <SelectContent>
              {departments.map((dept) => (
                <SelectItem key={dept} value={dept}>
                  {dept}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          placeholder="Ward description..."
          value={formData.description}
          onChange={(e) => handleChange("description", e.target.value)}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">Add Ward</Button>
      </div>
    </form>
  )
}

function AssignPatientForm({
  bed,
  patients,
  onSubmit,
  onClose,
}: {
  bed: BedRecord
  patients: any[]
  onSubmit: (bedId: string, patientId: string, admissionDate: string, expectedDischarge: string, notes: string) => void
  onClose: () => void
}) {
  const [formData, setFormData] = useState({
    patientId: "",
    admissionDate: new Date().toISOString().split("T")[0],
    expectedDischarge: "",
    notes: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit(bed.id, formData.patientId, formData.admissionDate, formData.expectedDischarge, formData.notes)
    onClose()
  }

  const handleChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="patient">Patient *</Label>
        <Select value={formData.patientId} onValueChange={(value) => handleChange("patientId", value)} required>
          <SelectTrigger>
            <SelectValue placeholder="Select patient" />
          </SelectTrigger>
          <SelectContent>
            {patients.map((patient) => (
              <SelectItem key={patient.id} value={patient.id}>
                {patient.firstName} {patient.lastName}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="admissionDate">Admission Date *</Label>
          <Input
            id="admissionDate"
            type="date"
            value={formData.admissionDate}
            onChange={(e) => handleChange("admissionDate", e.target.value)}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="expectedDischarge">Expected Discharge</Label>
          <Input
            id="expectedDischarge"
            type="date"
            value={formData.expectedDischarge}
            onChange={(e) => handleChange("expectedDischarge", e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          placeholder="Additional notes..."
          value={formData.notes}
          onChange={(e) => handleChange("notes", e.target.value)}
        />
      </div>

      <div className="flex justify-end space-x-2">
        <Button type="button" variant="outline" onClick={onClose}>
          Cancel
        </Button>
        <Button type="submit">Assign Patient</Button>
      </div>
    </form>
  )
}
