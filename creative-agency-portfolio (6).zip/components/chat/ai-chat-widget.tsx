"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MessageCircle, Send, Minimize2, Maximize2, X, Bot, User, Sparkles } from "lucide-react"

interface Message {
  id: string
  type: "user" | "ai"
  content: string
  timestamp: Date
  actions?: Array<{
    label: string
    action: () => void
  }>
}

interface AIChatWidgetProps {
  onNavigate: (section: string) => void
}

export function AIChatWidget({ onNavigate }: AIChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [isMinimized, setIsMinimized] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    if (isOpen && !isMinimized) {
      inputRef.current?.focus()
    }
  }, [isOpen, isMinimized])

  // Initialize with welcome message
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: "1",
          type: "ai",
          content:
            "👋 Hello! I'm your HMS AI Assistant. I can help you navigate the system, answer questions about hospital management, and guide you through various tasks. How can I assist you today?",
          timestamp: new Date(),
          actions: [
            { label: "📊 View Dashboard", action: () => onNavigate("dashboard") },
            { label: "👥 Manage Patients", action: () => onNavigate("patients") },
            { label: "📅 Appointments", action: () => onNavigate("appointments") },
            { label: "💰 Billing", action: () => onNavigate("billing") },
          ],
        },
      ])
    }
  }, [])

  const generateAIResponse = (
    userMessage: string,
  ): { content: string; actions?: Array<{ label: string; action: () => void }> } => {
    const message = userMessage.toLowerCase()

    // HMS Knowledge Base - Comprehensive responses
    const responses = {
      // Patient Management
      patient: {
        keywords: ["patient", "register", "admission", "discharge", "medical record"],
        response:
          "🏥 **Patient Management Help**\n\nI can help you with:\n• **Adding new patients** - Register with personal & medical details\n• **Searching patients** - Find by name, ID, or phone\n• **Updating records** - Edit patient information\n• **Patient status** - Track admission/discharge status\n• **Medical history** - View past treatments\n\nWould you like me to guide you to the patients section?",
        actions: [
          { label: "👥 Go to Patients", action: () => onNavigate("patients") },
          { label: "📋 View Patient List", action: () => onNavigate("patients") },
        ],
      },

      // Doctor Management
      doctor: {
        keywords: ["doctor", "physician", "specialist", "schedule", "availability"],
        response:
          "👨‍⚕️ **Doctor Management Help**\n\nManage your medical staff:\n• **Add doctors** - Register new physicians with specializations\n• **Doctor profiles** - Manage contact info, experience, qualifications\n• **Schedules** - Set working hours and availability\n• **Specializations** - Track different medical specialties\n• **Performance** - Monitor doctor statistics\n\nLet me take you to the doctors section!",
        actions: [
          { label: "👨‍⚕️ Manage Doctors", action: () => onNavigate("doctors") },
          { label: "📅 View Schedules", action: () => onNavigate("doctors") },
        ],
      },

      // Appointment System
      appointment: {
        keywords: ["appointment", "booking", "schedule", "consultation", "visit"],
        response:
          "📅 **Appointment Management**\n\nStreamline your scheduling:\n• **Book appointments** - Schedule patient-doctor meetings\n• **Reschedule/Cancel** - Modify existing appointments\n• **Appointment types** - Consultation, follow-up, emergency\n• **Time slots** - Manage doctor availability\n• **Reminders** - Automated patient notifications\n• **Status tracking** - Confirmed, pending, completed\n\nReady to manage appointments?",
        actions: [
          { label: "📅 Schedule Appointment", action: () => onNavigate("appointments") },
          { label: "📋 View All Appointments", action: () => onNavigate("appointments") },
        ],
      },

      // Laboratory Management
      lab: {
        keywords: ["lab", "test", "result", "blood", "urine", "xray", "scan"],
        response:
          "🧪 **Laboratory Management**\n\nHandle all diagnostic tests:\n• **Order tests** - Request various diagnostic procedures\n• **Test results** - View and manage lab reports\n• **Sample tracking** - Monitor specimen status\n• **Equipment** - Manage lab instruments\n• **Reports** - Generate test summaries\n• **Integration** - Link results to patient records\n\nNeed help with laboratory operations?",
        actions: [
          { label: "🧪 Lab Management", action: () => onNavigate("laboratory") },
          { label: "📊 View Test Results", action: () => onNavigate("laboratory") },
        ],
      },

      // Pharmacy Management
      pharmacy: {
        keywords: ["pharmacy", "medicine", "drug", "prescription", "medication", "inventory"],
        response:
          "💊 **Pharmacy Management**\n\nManage medications efficiently:\n• **Inventory control** - Track medicine stock levels\n• **Prescriptions** - Process doctor prescriptions\n• **Drug information** - Dosage, interactions, side effects\n• **Supplier management** - Handle medicine procurement\n• **Expiry tracking** - Monitor medication expiration dates\n• **Billing integration** - Link to patient billing\n\nLet's manage your pharmacy!",
        actions: [
          { label: "💊 Pharmacy Section", action: () => onNavigate("pharmacy") },
          { label: "📦 Check Inventory", action: () => onNavigate("pharmacy") },
        ],
      },

      // Bed Management
      bed: {
        keywords: ["bed", "room", "ward", "admission", "occupancy", "discharge"],
        response:
          "🛏️ **Bed Management System**\n\nOptimize bed allocation:\n• **Room assignment** - Allocate beds to patients\n• **Occupancy tracking** - Monitor bed availability\n• **Ward management** - Organize by departments\n• **Bed types** - ICU, general, private, shared\n• **Housekeeping** - Track cleaning status\n• **Transfer patients** - Move between rooms\n\nManage your hospital beds effectively!",
        actions: [
          { label: "🛏️ Bed Management", action: () => onNavigate("beds") },
          { label: "📊 Occupancy Status", action: () => onNavigate("beds") },
        ],
      },

      // Billing System
      billing: {
        keywords: ["bill", "payment", "invoice", "charge", "insurance", "cost"],
        response:
          "💰 **Billing & Finance**\n\nHandle all financial operations:\n• **Generate bills** - Create patient invoices\n• **Payment processing** - Accept various payment methods\n• **Insurance claims** - Process insurance paperwork\n• **Cost breakdown** - Detailed service charges\n• **Payment tracking** - Monitor outstanding amounts\n• **Financial reports** - Revenue and expense analysis\n\nLet's handle your billing needs!",
        actions: [
          { label: "💰 Billing System", action: () => onNavigate("billing") },
          { label: "📊 Financial Reports", action: () => onNavigate("billing") },
        ],
      },

      // Reports & Analytics
      reports: {
        keywords: ["report", "analytics", "statistics", "data", "analysis", "dashboard"],
        response:
          "📊 **Reports & Analytics**\n\nGet insights from your data:\n• **Patient reports** - Demographics, admission trends\n• **Financial reports** - Revenue, expenses, profitability\n• **Operational reports** - Bed occupancy, staff performance\n• **Medical reports** - Treatment outcomes, diagnosis patterns\n• **Custom reports** - Build your own analytics\n• **Export options** - PDF, Excel, CSV formats\n\nGenerate comprehensive reports!",
        actions: [
          { label: "📊 View Reports", action: () => onNavigate("reports") },
          { label: "📈 Analytics Dashboard", action: () => onNavigate("dashboard") },
        ],
      },

      // System Navigation
      navigation: {
        keywords: ["navigate", "go to", "show me", "open", "section", "page"],
        response:
          "🧭 **System Navigation**\n\nI can help you navigate to any section:\n• **Dashboard** - Overview and quick stats\n• **Patients** - Patient management\n• **Doctors** - Staff management\n• **Appointments** - Scheduling system\n• **Laboratory** - Test management\n• **Pharmacy** - Medicine inventory\n• **Beds** - Room allocation\n• **Billing** - Financial operations\n• **Reports** - Analytics and insights\n• **Settings** - System configuration\n\nWhere would you like to go?",
        actions: [
          { label: "🏠 Dashboard", action: () => onNavigate("dashboard") },
          { label: "👥 Patients", action: () => onNavigate("patients") },
          { label: "👨‍⚕️ Doctors", action: () => onNavigate("doctors") },
          { label: "📅 Appointments", action: () => onNavigate("appointments") },
        ],
      },

      // Help & Support
      help: {
        keywords: ["help", "support", "how to", "tutorial", "guide", "assistance"],
        response:
          "🆘 **Help & Support**\n\nI'm here to help you with:\n• **System tutorials** - Step-by-step guides\n• **Feature explanations** - How each module works\n• **Troubleshooting** - Solve common issues\n• **Best practices** - Optimize your workflow\n• **Quick tips** - Keyboard shortcuts and tricks\n• **Training** - Learn new features\n\nWhat specific help do you need?",
        actions: [
          { label: "📚 System Guide", action: () => onNavigate("dashboard") },
          { label: "⚙️ Settings", action: () => onNavigate("settings") },
        ],
      },

      // Default/Greeting
      default: {
        keywords: ["hello", "hi", "hey", "good morning", "good afternoon", "thanks"],
        response:
          "👋 **Hello there!**\n\nI'm your HMS AI Assistant, ready to help with:\n• **Patient & Doctor Management**\n• **Appointment Scheduling**\n• **Laboratory & Pharmacy Operations**\n• **Billing & Financial Reports**\n• **System Navigation & Support**\n\nWhat would you like to do today?",
        actions: [
          { label: "📊 View Dashboard", action: () => onNavigate("dashboard") },
          { label: "👥 Manage Patients", action: () => onNavigate("patients") },
          { label: "📅 Schedule Appointment", action: () => onNavigate("appointments") },
          { label: "💰 Billing", action: () => onNavigate("billing") },
        ],
      },
    }

    // Find matching response
    for (const [key, data] of Object.entries(responses)) {
      if (data.keywords.some((keyword) => message.includes(keyword))) {
        return { content: data.response, actions: data.actions }
      }
    }

    // Fallback response
    return {
      content:
        "🤔 I understand you're asking about hospital management. I can help you with:\n\n• **Patient Management** - Registration, records, status\n• **Doctor Management** - Staff, schedules, specializations\n• **Appointments** - Booking, rescheduling, tracking\n• **Laboratory** - Tests, results, reports\n• **Pharmacy** - Inventory, prescriptions, medications\n• **Billing** - Invoices, payments, insurance\n• **Reports** - Analytics, statistics, insights\n\nCould you be more specific about what you need help with?",
      actions: [
        { label: "📊 Dashboard", action: () => onNavigate("dashboard") },
        { label: "👥 Patients", action: () => onNavigate("patients") },
        { label: "📅 Appointments", action: () => onNavigate("appointments") },
        { label: "💰 Billing", action: () => onNavigate("billing") },
      ],
    }
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate AI thinking time
    setTimeout(
      () => {
        const aiResponse = generateAIResponse(inputValue)
        const aiMessage: Message = {
          id: (Date.now() + 1).toString(),
          type: "ai",
          content: aiResponse.content,
          timestamp: new Date(),
          actions: aiResponse.actions,
        }

        setMessages((prev) => [...prev, aiMessage])
        setIsTyping(false)
      },
      1000 + Math.random() * 1000,
    ) // 1-2 seconds delay
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault()
      handleSendMessage()
    }
  }

  const quickReplies = [
    "How do I add a new patient?",
    "Schedule an appointment",
    "Check bed availability",
    "Generate a bill",
    "View lab results",
    "Manage pharmacy inventory",
  ]

  return (
    <div>
      {/* Floating Chat Button */}
      {!isOpen && (
        <Button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 h-16 w-16 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 z-50 border-2 border-white"
        >
          <div className="relative">
            <MessageCircle className="h-7 w-7 text-white" />
            <div className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full animate-pulse"></div>
          </div>
        </Button>
      )}

      {/* Chat Widget */}
      {isOpen && (
        <div className="fixed bottom-6 right-6 z-50">
          <Card
            className={`w-96 shadow-2xl border-0 bg-white/95 backdrop-blur-sm transition-all duration-300 ${
              isMinimized ? "h-16" : "h-[600px]"
            }`}
          >
            {/* Header */}
            <CardHeader className="pb-3 bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-t-lg">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div className="h-9 w-9 bg-white/20 rounded-full flex items-center justify-center">
                    <Bot className="h-5 w-5" />
                  </div>
                  <div>
                    <CardTitle className="text-lg font-semibold">HMS AI Assistant</CardTitle>
                    <p className="text-emerald-100 text-sm">Always here to help</p>
                  </div>
                </div>
                <div className="flex items-center space-x-1">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsMinimized(!isMinimized)}
                    className="text-white hover:bg-white/20 h-8 w-8 p-0"
                  >
                    {isMinimized ? <Maximize2 className="h-4 w-4" /> : <Minimize2 className="h-4 w-4" />}
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setIsOpen(false)}
                    className="text-white hover:bg-white/20 h-8 w-8 p-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>

            {/* Chat Content */}
            {!isMinimized && (
              <CardContent className="flex-1 p-0 h-[480px] flex flex-col">
                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] ${
                          message.type === "user"
                            ? "bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-l-2xl rounded-tr-2xl"
                            : "bg-white text-slate-800 rounded-r-2xl rounded-tl-2xl border border-gray-200 shadow-sm"
                        } p-4`}
                      >
                        <div className="flex items-start space-x-2">
                          {message.type === "ai" && (
                            <div className="h-7 w-7 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm">
                              <Sparkles className="h-4 w-4 text-white" />
                            </div>
                          )}
                          <div className="flex-1">
                            <div className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</div>
                            {message.actions && (
                              <div className="mt-3 flex flex-wrap gap-2">
                                {message.actions.map((action, index) => (
                                  <Button
                                    key={index}
                                    onClick={action.action}
                                    variant="outline"
                                    size="sm"
                                    className="text-xs bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100 hover:border-emerald-300"
                                  >
                                    {action.label}
                                  </Button>
                                ))}
                              </div>
                            )}
                            <div className="mt-2 text-xs opacity-60">
                              {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                            </div>
                          </div>
                          {message.type === "user" && (
                            <div className="h-7 w-7 bg-white/20 rounded-full flex items-center justify-center flex-shrink-0">
                              <User className="h-4 w-4 text-white" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}

                  {/* Typing Indicator */}
                  {isTyping && (
                    <div className="flex justify-start">
                      <div className="bg-white text-slate-800 rounded-r-2xl rounded-tl-2xl border border-gray-200 shadow-sm p-4 max-w-[80%]">
                        <div className="flex items-center space-x-2">
                          <div className="h-7 w-7 bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full flex items-center justify-center">
                            <Sparkles className="h-4 w-4 text-white" />
                          </div>
                          <div className="flex space-x-1">
                            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce"></div>
                            <div
                              className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce"
                              style={{ animationDelay: "0.1s" }}
                            ></div>
                            <div
                              className="w-2 h-2 bg-emerald-500 rounded-full animate-bounce"
                              style={{ animationDelay: "0.2s" }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Quick Replies */}
                {messages.length <= 1 && (
                  <div className="px-4 pb-2">
                    <p className="text-xs text-gray-500 mb-2">Quick questions:</p>
                    <div className="flex flex-wrap gap-1">
                      {quickReplies.slice(0, 3).map((reply, index) => (
                        <Button
                          key={index}
                          onClick={() => {
                            setInputValue(reply)
                            setTimeout(handleSendMessage, 100)
                          }}
                          variant="outline"
                          size="sm"
                          className="text-xs bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-200"
                        >
                          {reply}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Input */}
                <div className="p-4 border-t border-gray-100 bg-gray-50/50">
                  <div className="flex space-x-2">
                    <Input
                      ref={inputRef}
                      value={inputValue}
                      onChange={(e) => setInputValue(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Ask me anything about HMS..."
                      className="flex-1 bg-gray border-gray-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                    />
                    <Button
                      onClick={handleSendMessage}
                      disabled={!inputValue.trim() || isTyping}
                      className="bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-navy shadow-sm"
                    >
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            )}
          </Card>
        </div>
      )}
    </div>
  )
}
