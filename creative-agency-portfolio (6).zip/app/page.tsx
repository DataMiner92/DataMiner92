"use client"

import { useState, useEffect } from "react"
import { LoginForm } from "@/components/auth/login-form"
import { Dashboard } from "@/components/dashboard/dashboard"

export default function Home() {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [userRole, setUserRole] = useState("")
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is already logged in
    const savedUser = localStorage.getItem("hms-user")
    if (savedUser) {
      const userData = JSON.parse(savedUser)
      setIsAuthenticated(true)
      setUserRole(userData.role)
    }
    setIsLoading(false)
  }, [])

  const handleLogin = (role: string) => {
    setIsAuthenticated(true)
    setUserRole(role)
    localStorage.setItem("hms-user", JSON.stringify({ role, loginTime: new Date().toISOString() }))
  }

  const handleLogout = () => {
    setIsAuthenticated(false)
    setUserRole("")
    localStorage.removeItem("hms-user")
  }

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return <LoginForm onLogin={handleLogin} />
  }

  return <Dashboard userRole={userRole} onLogout={handleLogout} />
}
